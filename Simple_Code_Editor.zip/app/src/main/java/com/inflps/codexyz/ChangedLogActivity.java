package com.inflps.codexyz;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class ChangedLogActivity extends AppCompatActivity {
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private HorizontalScrollView hscroll1;
	private Button button1;
	private TextView textview1;
	private ScrollView vscroll2;
	private LinearLayout linear99;
	private LinearLayout linear132;
	private TextView textview2;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.changed_log);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		hscroll1 = findViewById(R.id.hscroll1);
		button1 = findViewById(R.id.button1);
		textview1 = findViewById(R.id.textview1);
		vscroll2 = findViewById(R.id.vscroll2);
		linear99 = findViewById(R.id.linear99);
		linear132 = findViewById(R.id.linear132);
		textview2 = findViewById(R.id.textview2);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
	}
	
	private void initializeLogic() {
		textview2.setText("  \n  ┏Version: 5.0.1 (10)\n  ┃• Minor interface change;\n  ┃• HTML Console enhanced and new tools;\n  ┃• App renamed (I changed for the Reason of religion);\n  ┃• Fading edges on some scrollable widgets.\n  ┃\n  ┃⚠ It is possible that you will experience some graphics errors.\n  ┃\n  ┃\n  ┃\n  ┃\n  ┣ Version: 5.0.0 (9) [Unstable Version] \n  ┃• Adaptable icon, thanks to this fact its foreground is smaller; \n  ┃• Some icons (few) have been changed; \n  ┃• Several tools such as: binary translator, text repeater and Android terminal, all beta; \n  ┃• Fast file editing available (Beta); \n  ┃• The \"Forward folder\" option (Back to the last accessed folder) is available; \n  ┃• Some code snippets have been modified or deleted due to their usefulness; \n  ┃• The new tool Reverse words; \n  ┃• Text history is available (if you deleted, or formatted in json or anything else the content of the text, it can be recovered); \n  ┃• Other experimental things; \n  ┃• Bug fixes. \n  ┃\n  ┃⚠ It is signed as Unstable Version because it is possible to crash when you first open the application due to storage permissions. However, it is good to contact us if this persists! \n  ┃⚠ It is possible that in older versions of android (below 8.1) it may not work properly!\n  ┃ \n  ┃ \n  ┃ \n  ┣ Version: 4.3.1 (8) \n  ┃ • Fixed bugs; \n  ┃ • The file size text indicator is now fixed; \n  ┃ • Fixed HTML player; \n  ┃ • Certain application tools have been modified. \n  ┃ \n  ┃ \n  ┃ \n  ┣ Version: 4.3.0 (7) \n  ┃ • Fixed bugs; \n  ┃ • By pressing back to the previous folder you return to the root of the device. \n  ┃ \n  ┃ \n  ┃ \n  ┣ Version: 4.2 (6) \n  ┃ • Fixed bugs; \n  ┃ • Pressing FAB refreshes the current folder location. \n  ┃ \n  ┃ \n  ┃ \n  ┣ Version: 4.1 (5) \n  ┃ • Fixed bugs. \n  ┃ \n  ┃ \n  ┃ \n  ┣ Version: 4.0 (4) \n  ┃ • Now it is more optimized; \n  ┃ • The layouts are weaker as well as its icon; \n  ┃ • The new dialog scheme; \n  ┃ • Now the text editor is based on SoraEditor; \n  ┃ • Swipe down to refresh the current folder is available; \n  ┃ • Bugs fixed. \n  ┃ \n  ┃ \n  ┃ \n  ┣ Version: 3.0 (3) \n  ┃ • The appearance is even darker, including the icon; \n  ┃ • The shadow in the icon has been removed; \n  ┃ • Layouts have been slightly modified; \n  ┃ • HTML Player is available; \n  ┃ • File and folder preview is based on Win11 icons. \n  ┃ \n  ┃ \n  ┃ \n  ┣ Version: 2.0 (2) \n  ┃ • New look; \n  ┃ • More tools; \n  ┃ • The preview of files and folders on this device is valid; \n  ┃ • New icon; \n  ┃ • Darker appearance; \n  ┃ • More shortcuts; \n  ┃ • Bugs fixed. \n  ┃\n  ┃\n  ┃\n  ┣ Version: 1.1 (1.1) \n  ┃ • Certain errors were immediate. \n  ┃\n  ┃\n  ┗ Version: 1.0 (1) \n    • The app was born (launched).");
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}