package com.inflps.codexyz;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import com.google.android.material.appbar.AppBarLayout;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class AppExtractorActivity extends AppCompatActivity {
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private String uri = "";
	private String appName = "";
	private boolean Check_Reload = false;
	private String menu_1 = "";
	private String menu_2 = "";
	private String menu_3 = "";
	private String ExternalStorageDir = "";
	private String App_Dir = "";
	private String finalPath = "";
	private String ver = "";
	private String not_found = "";
	private double Android_SDK = 0;
	private double count = 0;
	private double mfirstVisibleItem = 0;
	private double firstVisibleItem = 0;
	private String charSeq = "";
	private String language = "";
	private String feedback = "";
	private String queri_hint = "";
	private String search = "";
	private String prog_dia = "";
	private String rate = "";
	private String extracted = "";
	private String share_apk = "";
	private String share_load = "";
	private String extract_load = "";
	private String info_load = "";
	private double dia_pos = 0;
	private String app = "";
	
	private ArrayList<String> dialog_menu = new ArrayList<>();
	private ArrayList<String> app_pack = new ArrayList<>();
	private ArrayList<String> app_name = new ArrayList<>();
	private ArrayList<String> app_ver = new ArrayList<>();
	private ArrayList<String> app_ver_search = new ArrayList<>();
	private ArrayList<String> app_pack_search = new ArrayList<>();
	private ArrayList<String> app_name_search = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> app_list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> app_list_search = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ListView listview1;
	private ListView listview2;
	private EditText edittext1;
	private ImageView imageview25;
	
	private AlertDialog.Builder dialog;
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.app_extractor);
		initialize(_savedInstanceState);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		listview1 = findViewById(R.id.listview1);
		listview2 = findViewById(R.id.listview2);
		edittext1 = findViewById(R.id.edittext1);
		imageview25 = findViewById(R.id.imageview25);
		dialog = new AlertDialog.Builder(this);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				_DARK();
				uri = app_pack.get((int)(_position));
				appName = app_name.get((int)(_position));
				dialog.setTitle(appName);
				dialog.setAdapter(new ArrayAdapter(AppExtractorActivity.this, android.R.layout.simple_list_item_1, dialog_menu), new DialogInterface.OnClickListener() {
					 @Override public void onClick(DialogInterface dia, int _pos) {
						dia_pos = _pos;
						if (dialog_menu.get((int)(dia_pos)).equals(menu_1)) {
							new ShowInfo().execute();
						}
						if (dialog_menu.get((int)(dia_pos)).equals(menu_2)) {
							new ShareApp().execute();
						}
						if (dialog_menu.get((int)(dia_pos)).equals(menu_3)) {
							new ExtractApp().execute();
						}
					} });
				dialog.setIcon(app_icon.get((int)_position).get("icon"));
				dialog.create().show();
			}
		});
		
		listview2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				_DARK();
				uri = app_pack_search.get((int)(_position));
				appName = app_name_search.get((int)(_position));
				dialog.setTitle(appName);
				dialog.setAdapter(new ArrayAdapter(AppExtractorActivity.this, android.R.layout.simple_list_item_1, dialog_menu), new DialogInterface.OnClickListener() {
					 @Override public void onClick(DialogInterface dia, int _pos) {
						dia_pos = _pos;
						if (dialog_menu.get((int)(dia_pos)).equals(menu_1)) {
							new ShowInfo().execute();
							Check_Reload = true;
						}
						if (dialog_menu.get((int)(dia_pos)).equals(menu_2)) {
							//new ShareApp().execute();
							shareApplication();
						}
						if (dialog_menu.get((int)(dia_pos)).equals(menu_3)) {
							new ExtractApp().execute();
						}
					} });
				dialog.setIcon(app_icon_search.get((int)_position).get("icon_search"));
				dialog.create().show();
			}
		});
		
		imageview25.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().equals("")) {
					charSeq = "";
					listview1.setVisibility(View.VISIBLE);
					listview2.setVisibility(View.GONE);
				}
				else {
					charSeq = edittext1.getText().toString();
					_Sort_Appllication(charSeq);
				}
			}
		});
	}
	
	private void initializeLogic() {
		_DARK();
		setTitle("Apk Extractor");
		new LoadApplications().execute();
	}
	private class LoadApplications extends AsyncTask<Void, Void, Void> {
		private ProgressDialog progress = null;
		 @Override protected Void doInBackground(Void... params) {
			_Package_Parsing();
			return null; }
		 @Override protected void onPostExecute(Void result) {
			listview1.setAdapter(new Listview1Adapter(app_list));
			progress.dismiss();
			super.onPostExecute(result);
		}
		 @Override protected void onPreExecute() {
			_language_switch();
			_dialogAddMenu();
			
			progress = ProgressDialog.show(AppExtractorActivity.this, null, prog_dia, false);
			super.onPreExecute();
		}}
	private ArrayList<HashMap <String, android.graphics.drawable.Drawable>> app_icon = new ArrayList <> ();
	private ArrayList<HashMap <String, android.graphics.drawable.Drawable>> app_icon_search = new ArrayList <> ();
	{}
	private class ShareApp extends AsyncTask<Void, Void, Void> {
		private ProgressDialog progress = null;
		 @Override protected Void doInBackground(Void... params) {
			_extractApp(uri, appName);
			return null;
		}
		 @Override protected void onPostExecute(Void result) {
			_showToast(extracted.concat(App_Dir));
			_shareApp(finalPath);
			progress.dismiss();
			super.onPostExecute(result);
		}
		 @Override protected void onPreExecute() {
			progress = ProgressDialog.show(AppExtractorActivity.this, null, share_load, false);
			super.onPreExecute();
		}}
	{ }
	private class ExtractApp extends AsyncTask<Void, Void, Void> {
		private ProgressDialog progress = null;
		 @Override protected Void doInBackground(Void... params) {
			_extractApp(uri, appName);
			return null;
		}
		 @Override protected void onPostExecute(Void result) {
			progress.dismiss();
			_showToast(extracted.concat(App_Dir));
			super.onPostExecute(result);
		}
		 @Override protected void onPreExecute() {
			progress = ProgressDialog.show(AppExtractorActivity.this, null, extract_load, false);
			super.onPreExecute();
		}}
	{ }
	private class ShowInfo extends AsyncTask<Void, Void, Void> {
		private ProgressDialog progress = null;
		 @Override protected Void doInBackground(Void... params) {
			Intent info = new Intent();
			info.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
			info.setData(Uri.fromParts("package", uri, null));
			startActivity(info);
			return null;
		}
		 @Override protected void onPostExecute(Void result) {
			progress.dismiss();
			super.onPostExecute(result);
		}
		 @Override protected void onPreExecute() {
			progress = ProgressDialog.show(AppExtractorActivity.this, null, info_load, false);
			super.onPreExecute();
		}}
	{
					StrictMode.VmPolicy.Builder builder = 
						new StrictMode.VmPolicy.Builder(); 
						StrictMode.setVmPolicy(builder.build());
						if(Build.VERSION.SDK_INT>=24){ 
								    try{
												java.lang.reflect.Method m = 
										        StrictMode.class.getMethod(
												"disableDeathOnFileUriExposure"); 
										        m.invoke(null); 
										}
									catch(Exception e){ 
												showMessage(e.toString()); 
										} 
						}
		_onCreateOptionMenu();
	}
	
	public void _dialogAddMenu() {
		dialog_menu.clear();
		dialog_menu.add(menu_1);
		dialog_menu.add(menu_2);
		dialog_menu.add(menu_3);
	}
	
	
	public void _extractApp(final String _pack_name, final String _app_name) {
		uri = _pack_name;
		if (FileUtil.isExistFile(ExternalStorageDir)) {
			ExternalStorageDir = Environment.getExternalStorageDirectory().toString();
			FileUtil.makeDir(ExternalStorageDir + "/Codex/AppExtracted");
			App_Dir = ExternalStorageDir.concat("/Codex/AppExtracted");
		}
		else {
			FileUtil.makeDir("/storage/emulated/0/".concat("Codex/AppExtracted"));
			App_Dir = "/storage/emulated/0/".concat("Codex/AppExtracted");
		}
		android.content.pm.PackageManager pm =  getPackageManager();
		try{
			android.content.pm.PackageInfo pi = pm.getPackageInfo(uri, android.content.pm.PackageManager.GET_ACTIVITIES);
			app = pi.applicationInfo.publicSourceDir;
			ver = pi.versionName;
			finalPath = App_Dir.concat("/".concat(_app_name.concat("/".concat(ver.concat(".apk")))));
			FileUtil.copyFile(app, finalPath);
		} catch (android.content.pm.PackageManager.NameNotFoundException e) {
			_showToast(not_found);
		}
	}
	
	
	public void _showToast(final String _s) {
		if (Android_SDK < 21) {
			Toast t = Toast.makeText(this, _s, Toast.LENGTH_SHORT);
			t.setGravity(Gravity.BOTTOM | Gravity.CENTER,0,50);
			t.show();
		}
		else {
			LayoutInflater i = getLayoutInflater();
			View inflate = getLayoutInflater().inflate(R.layout.custm_t, null);
			TextView tv1 =(TextView)inflate.findViewById(R.id.tv1);
			Toast t = Toast.makeText(getApplicationContext(), "" , Toast.LENGTH_SHORT);
			t.setView(inflate);
			t.setGravity(Gravity.BOTTOM | Gravity.FILL_HORIZONTAL,0,0);
			tv1.setText(_s);
			t.show();
		}
	}
	
	
	public void _shareApp(final String _finalPath) {
		Intent shareApp = new Intent(Intent.ACTION_SEND);
		shareApp.setType("application/vbd.android.package-archive");
		shareApp.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new java.io.File(_finalPath)));
		startActivity(Intent.createChooser(shareApp, "Share APK"));
	}
	
	
	public void _Package_Parsing() {
		List<android.content.pm.PackageInfo> pack_list = getApplicationContext().getPackageManager().getInstalledPackages(0);
		for (android.content.pm.PackageInfo packageInfo : pack_list) {
			app_name.add(packageInfo.applicationInfo.loadLabel(getPackageManager()).toString());
			app_pack.add(packageInfo.packageName);
			app_ver.add(packageInfo.versionName);
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("APK", "APK");
				app_list.add(_item);
			}
			
			HashMap _itemIcon = new HashMap();
			_itemIcon.put("icon", packageInfo.applicationInfo.loadIcon(getPackageManager()));
			app_icon.add(_itemIcon);
		}
	}
	
	
	public void _Sort_Appllication(final String _charSeq) {
		listview1.setVisibility(View.GONE);
		listview2.setVisibility(View.VISIBLE);
		app_list_search.clear();
		app_name_search.clear();
		app_pack_search.clear();
		app_ver_search.clear();
		app_icon_search.clear();
		count = 0;
		for(int _repeat18 = 0; _repeat18 < (int)(app_list.size()); _repeat18++) {
			if (app_name.get((int)(count)).toLowerCase().contains(_charSeq.toLowerCase())) {
				app_name_search.add(app_name.get((int)(count)));
				app_pack_search.add(app_pack.get((int)(count)));
				app_ver_search.add(app_ver.get((int)(count)));
				{
					HashMap<String, Object> _item = new HashMap<>();
					_item.put("APK", "APK");
					app_list_search.add(_item);
				}
				
				HashMap _item_search = new HashMap();
				_item_search.put("icon_search", app_icon.get((int)(count)).get("icon"));
				app_icon_search.add(_item_search);
			}
			count++;
		}
		listview2.setAdapter(new Listview2Adapter(app_list_search));
		((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
	}
	
	
	public void _ActionBar_S_H() {
		listview1.setOnScrollListener(new AbsListView.OnScrollListener() {
			 @Override public void onScrollStateChanged(AbsListView view, int scrollState) { }
			 @Override public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				if (mfirstVisibleItem < firstVisibleItem) {
					if (getActionBar().isShowing()) {
						getActionBar().hide();
					}
				}
				if (mfirstVisibleItem > firstVisibleItem) {
					if (!getActionBar().isShowing()) {
						getActionBar().show();
					}
				}
				mfirstVisibleItem = firstVisibleItem;
			} });
	}
	
	
	public void _showInfo(final String _pack_name) {
		
	}
	
	
	public void _onCreateOptionMenu() {
		
	}
	
	
	public void _language_switch() {
		Android_SDK = Integer.parseInt(Build.VERSION.SDK);
		language = Locale.getDefault().getDisplayLanguage();
		if (language.toLowerCase().equals("igbo")) {
			menu_1 = "Show app info";
			menu_2 = "Share apk file";
			menu_3 = "Extract to folder";
			feedback = "Feedback";
			queri_hint = "search...";
			search = "Search";
			prog_dia = "Loading Applications...";
			rate = "Rate";
			extracted = "Extracted to:";
			not_found = "Apk not found";
			share_apk = "Share APK";
			share_load = "preparing archive...";
			extract_load = "extracting apk...";
			info_load = "loading info...";
		}
		else {
			menu_1 = "Show app info";
			menu_2 = "Share apk file";
			menu_3 = "Extract to folder";
			feedback = "Feedback";
			queri_hint = "search...";
			search = "Search";
			prog_dia = "Loading Applications...";
			rate = "Rate";
			extracted = "Extracted to:";
			not_found = "Apk not found";
			share_apk = "Share APK";
			share_load = "preparing archive...";
			extract_load = "extracting apk...";
			info_load = "loading info...";
		}
	}
	
	
	public void _DARK() {
		dialog = new AlertDialog.Builder(this,AlertDialog.THEME_HOLO_LIGHT);
	}
	
	
	public void _SHARE_APK() {
	}
	private void shareApplication() { 
								android.content.pm.ApplicationInfo app = 
								getApplicationContext().getApplicationInfo(); 
								String filePath = app.sourceDir;
								Intent intent = new Intent(Intent.ACTION_SEND); 
								intent.setType("*/*"); 
								java.io.File originalApk = new java.io.File(filePath); 
								try {  
											java.io.File tempFile = new java.io.File(getExternalCacheDir() + "/ExtractedApk"); 
									 		if (!tempFile.isDirectory()) 
												if (!tempFile.mkdirs()) 
												return; 
												tempFile = new java.io.File(tempFile.getPath() + "/" + 
												"export.apk");
												if (!tempFile.exists()) 
													{
															try{
																		if (!tempFile.createNewFile()) { 
																					return; }
																}
															catch (java.io.IOException e){} 
													} 
												java.io.InputStream in = new java.io.FileInputStream (originalApk);
												java.io.OutputStream out = new java.io.FileOutputStream(tempFile);
												byte[] buf = new byte[1024];
												int len; 
												while ((len = in.read(buf)) > 0) { 
																out.write(buf, 0, len); 
												} 
												in.close(); 
												out.close(); 
												intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(tempFile));
												startActivity(Intent.createChooser(intent, "Share app via"));
								} 
								catch (java.io.IOException e) 
								{ showMessage(e.toString()); 
								} 
				}
	{
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.clist_apk, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView iv_app_icon = _view.findViewById(R.id.iv_app_icon);
			final LinearLayout linear121 = _view.findViewById(R.id.linear121);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView tv_app_name = _view.findViewById(R.id.tv_app_name);
			final TextView tv_app_pack = _view.findViewById(R.id.tv_app_pack);
			final TextView tv_app_ver = _view.findViewById(R.id.tv_app_ver);
			
			tv_app_name.setText(app_name.get((int)(_position)));
			tv_app_pack.setText(app_pack.get((int)(_position)));
			tv_app_ver.setText(app_ver.get((int)(_position)));
			iv_app_icon.setImageDrawable(app_icon.get((int)_position).get("icon"));
			
			return _view;
		}
	}
	
	public class Listview2Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.clist_apk, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView iv_app_icon = _view.findViewById(R.id.iv_app_icon);
			final LinearLayout linear121 = _view.findViewById(R.id.linear121);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView tv_app_name = _view.findViewById(R.id.tv_app_name);
			final TextView tv_app_pack = _view.findViewById(R.id.tv_app_pack);
			final TextView tv_app_ver = _view.findViewById(R.id.tv_app_ver);
			
			tv_app_name.setText(app_name_search.get((int)(_position)));
			tv_app_pack.setText(app_pack_search.get((int)(_position)));
			tv_app_ver.setText(app_ver_search.get((int)(_position)));
			iv_app_icon.setImageDrawable(app_icon.get((int)_position).get("icon"));
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}