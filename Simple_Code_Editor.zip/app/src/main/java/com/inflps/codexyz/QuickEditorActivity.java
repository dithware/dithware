package com.inflps.codexyz;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class QuickEditorActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private double num = 0;
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear5;
	private ImageView imageview88;
	private TextView textview1;
	private LinearLayout linear3;
	private EditText edittext1;
	private TextView textview2;
	private LinearLayout linear125;
	private TextView textview3;
	private TextView textview4;
	private ImageView imageview90;
	private LinearLayout linear121;
	private ImageView imageview91;
	private ImageView imageview92;
	private LinearLayout linear122;
	private LinearLayout linear124;
	private LinearLayout linear126;
	private TextView textview5;
	private TextView textview6;
	
	private SharedPreferences path;
	private TimerTask t;
	private AlertDialog.Builder alert;
	private AlertDialog.Builder exit;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.quick_editor);
		initialize(_savedInstanceState);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear5 = findViewById(R.id.linear5);
		imageview88 = findViewById(R.id.imageview88);
		textview1 = findViewById(R.id.textview1);
		linear3 = findViewById(R.id.linear3);
		edittext1 = findViewById(R.id.edittext1);
		textview2 = findViewById(R.id.textview2);
		linear125 = findViewById(R.id.linear125);
		textview3 = findViewById(R.id.textview3);
		textview4 = findViewById(R.id.textview4);
		imageview90 = findViewById(R.id.imageview90);
		linear121 = findViewById(R.id.linear121);
		imageview91 = findViewById(R.id.imageview91);
		imageview92 = findViewById(R.id.imageview92);
		linear122 = findViewById(R.id.linear122);
		linear124 = findViewById(R.id.linear124);
		linear126 = findViewById(R.id.linear126);
		textview5 = findViewById(R.id.textview5);
		textview6 = findViewById(R.id.textview6);
		path = getSharedPreferences("path", Activity.MODE_PRIVATE);
		alert = new AlertDialog.Builder(this);
		exit = new AlertDialog.Builder(this);
		
		imageview88.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				onBackPressed();
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				textview6.setText(String.valueOf((long)(_charSeq.length())));
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		imageview90.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				try{
					PopupMenu popup = new PopupMenu(QuickEditorActivity.this, imageview90); Menu menu = popup.getMenu(); menu.add("Save as copy"); 
					menu.add("Save"); 
					popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { public boolean onMenuItemClick(MenuItem item) { switch (item.getTitle().toString()) { case "Save as copy":
								alert.setTitle("Please confirm this");
								alert.setMessage("This will be saved as a copy! \n".concat("The file name will be: ".concat("(Copy)_".concat(String.valueOf((long)(num)).concat("_".concat(getIntent().getStringExtra("Name").concat(".")))))));
								alert.setPositiveButton("Save", new DialogInterface.OnClickListener() {
									@Override
									public void onClick(DialogInterface _dialog, int _which) {
										FileUtil.writeFile(getIntent().getStringExtra("Path").concat("/".concat("(Copy)_".concat(String.valueOf((long)(num)).concat("_".concat(getIntent().getStringExtra("Name")))))), edittext1.getText().toString());
										SketchwareUtil.showMessage(getApplicationContext(), "Saved as a copy! ".concat(getIntent().getStringExtra("Path").concat("/(Copy)_".concat(String.valueOf((long)(num)).concat("_".concat(getIntent().getStringExtra("Name").concat(".")))))));
										num++;
									}
								});
								alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
									@Override
									public void onClick(DialogInterface _dialog, int _which) {
										
									}
								});
								_CustomDialogMaterial(alert, false);
								return true; case "Save":
								alert.setTitle("Please confirm this");
								alert.setMessage("This modified file will replace the old file! \n This cannot be recovered and you are responsible for this! \n".concat("\n \n File name:".concat(getIntent().getStringExtra("Name").concat("."))));
								alert.setPositiveButton("Save", new DialogInterface.OnClickListener() {
									@Override
									public void onClick(DialogInterface _dialog, int _which) {
										FileUtil.writeFile(getIntent().getStringExtra("Path").concat("/".concat(getIntent().getStringExtra("Name"))), edittext1.getText().toString());
										SketchwareUtil.showMessage(getApplicationContext(), "Saved as a replaced!".concat(getIntent().getStringExtra("Path").concat("/".concat(getIntent().getStringExtra("Name")))));
									}
								});
								alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
									@Override
									public void onClick(DialogInterface _dialog, int _which) {
										
									}
								});
								_CustomDialogMaterial(alert, false);
								return true; default: return false; } } }); popup.show();
				}catch(Exception e){
							 
					}
			}
		});
		
		imageview91.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
	}
	
	private void initializeLogic() {
		edittext1.setText(FileUtil.readFile(getIntent().getStringExtra("Content")));
		textview4.setText(getIntent().getStringExtra("Name"));
		textview3.setText(getIntent().getStringExtra("Path"));
		_EdittextHistory(imageview92, imageview91, edittext1);
		num = 1;
	}
	
	@Override
	public void onBackPressed() {
		exit.setTitle("Abandon the modified file?");
		exit.setMessage("Changes to the file will not be saved!");
		exit.setPositiveButton("Yes (Exit)", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finish();
			}
		});
		exit.setNegativeButton("No (Dismiss)", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		_CustomDialogMaterial(exit, true);
	}
	
	@Override
	public void onStart() {
		super.onStart();
		
	}
	public void _EdittextHistory(final View _redo, final View _undo, final TextView _et) {
		final UndoRedoFunction URF = new UndoRedoFunction(_et);
		
		//Undo View
		_undo.setOnClickListener (new View.OnClickListener() {
				@Override
				          public void onClick(View v) {
						            URF.undo();
						          }
		});
		
		//Redo View
		_redo.setOnClickListener (new View.OnClickListener() {
				@Override
				          public void onClick(View v) {
						            URF.redo();
						          }
		});
		
		//Class
	}
	public class UndoRedoFunction {
			
			private boolean mIsUndoOrRedo = false;
			private EditHistory mEditHistory;
			private EditTextChangeListener mChangeListener;
			private TextView mTextView;
		
			
			public UndoRedoFunction(TextView textView) {
						mTextView = textView;
						mEditHistory = new EditHistory();
						mChangeListener = new EditTextChangeListener();
						mTextView.addTextChangedListener(mChangeListener);
			}
		
			public void disconnect() {
						mTextView.removeTextChangedListener(mChangeListener);
			}
		//By THEBI3ST
			public void setMaxHistorySize(int maxHistorySize) {
						mEditHistory.setMaxHistorySize(maxHistorySize);
			}
		
			public void clearHistory() {
						mEditHistory.clear();
			}
		
			
			public boolean getCanUndo() {
						return (mEditHistory.mmPosition > 0);
			}
		
			public void undo() {
						EditItem edit = mEditHistory.getPrevious();
						if (edit == null) {
									return;
						}
				
						Editable text = mTextView.getEditableText();
						int start = edit.mmStart;
						int end = start + (edit.mmAfter != null ? edit.mmAfter.length() : 0);
				
						mIsUndoOrRedo = true;
						text.replace(start, end, edit.mmBefore);
						mIsUndoOrRedo = false;
				
						for (Object o : text.getSpans(0, text.length(), android.text.style.UnderlineSpan.class)) {
									text.removeSpan(o);
						}//xenondry
				
						Selection.setSelection(text, edit.mmBefore == null ? start
								: (start + edit.mmBefore.length()));
			}
		
			public boolean getCanRedo() {
						return (mEditHistory.mmPosition < mEditHistory.mmHistory.size());
			}
		
			public void redo() {
						EditItem edit = mEditHistory.getNext();
						if (edit == null) {
									return;
						}
				//JustMax
						Editable text = mTextView.getEditableText();
						int start = edit.mmStart;
						int end = start + (edit.mmBefore != null ? edit.mmBefore.length() : 0);
				
						mIsUndoOrRedo = true;
						text.replace(start, end, edit.mmAfter);
						mIsUndoOrRedo = false;
				
						for (Object o : text.getSpans(0, text.length(), android.text.style.UnderlineSpan.class)) {
									text.removeSpan(o);
						}
				
						Selection.setSelection(text, edit.mmAfter == null ? start
								: (start + edit.mmAfter.length()));
			}
		
			public void storePersistentState(android.content.SharedPreferences.Editor editor, String prefix) {
				
						editor.putString(prefix + ".hash",
								String.valueOf(mTextView.getText().toString().hashCode()));
						editor.putInt(prefix + ".maxSize", mEditHistory.mmMaxHistorySize);
						editor.putInt(prefix + ".position", mEditHistory.mmPosition);
						editor.putInt(prefix + ".size", mEditHistory.mmHistory.size());
				
						int i = 0;
						for (EditItem ei : mEditHistory.mmHistory) {
									String pre = prefix + "." + i;
						
									editor.putInt(pre + ".start", ei.mmStart);
									editor.putString(pre + ".before", ei.mmBefore.toString());
									editor.putString(pre + ".after", ei.mmAfter.toString());
						
									i++;
						}
			}
		
			public boolean restorePersistentState(SharedPreferences sp, String prefix)
					throws IllegalStateException {
				
						boolean ok = doRestorePersistentState(sp, prefix);
						if (!ok) {
									mEditHistory.clear();
						}
				
						return ok;
			}
		
			private boolean doRestorePersistentState(SharedPreferences sp, String prefix) {
				
						String hash = sp.getString(prefix + ".hash", null);
						if (hash == null) {
									return true;
						}
				
						if (Integer.valueOf(hash) != mTextView.getText().toString().hashCode()) {
									return false;
						}
				
						mEditHistory.clear();
						mEditHistory.mmMaxHistorySize = sp.getInt(prefix + ".maxSize", -1);
				
						int count = sp.getInt(prefix + ".size", -1);
						if (count == -1) {
									return false;
						}
				
						for (int i = 0; i < count; i++) {
									String pre = prefix + "." + i;
						
									int start = sp.getInt(pre + ".start", -1);
									String before = sp.getString(pre + ".before", null);
									String after = sp.getString(pre + ".after", null);
						
									if (start == -1 || before == null || after == null) {
												return false;
									}
									mEditHistory.add(new EditItem(start, before, after));
						}
				
						mEditHistory.mmPosition = sp.getInt(prefix + ".position", -1);
						if (mEditHistory.mmPosition == -1) {
									return false;
						}
				
						return true;
			}
		
			private final class EditHistory {
				
						private int mmPosition = 0;
						private int mmMaxHistorySize = -1;
						private final LinkedList<EditItem> mmHistory = new LinkedList<EditItem>();
						private void clear() {
									mmPosition = 0;
									mmHistory.clear();
						}
				
						private void add(EditItem item) {
									while (mmHistory.size() > mmPosition) {
												mmHistory.removeLast();
									}
									mmHistory.add(item);
									mmPosition++;
						
									if (mmMaxHistorySize >= 0) {
												trimHistory();
									}
						}
				
						private void setMaxHistorySize(int maxHistorySize) {
									mmMaxHistorySize = maxHistorySize;
									if (mmMaxHistorySize >= 0) {
												trimHistory();
									}
						}
				
						private void trimHistory() {
									while (mmHistory.size() > mmMaxHistorySize) {
												mmHistory.removeFirst();
												mmPosition--;
									}
						
									if (mmPosition < 0) {
												mmPosition = 0;
									}
						}
				
						private EditItem getPrevious() {
									if (mmPosition == 0) {
												return null;
									}
									mmPosition--;
									return mmHistory.get(mmPosition);
						}
				
						private EditItem getNext() {
									if (mmPosition >= mmHistory.size()) {
												return null;
									}
						
									EditItem item = mmHistory.get(mmPosition);
									mmPosition++;
									return item;
						}
			}
		
			private final class EditItem {
						private final int mmStart;
						private final CharSequence mmBefore;
						private final CharSequence mmAfter;
				
						public EditItem(int start, CharSequence before, CharSequence after) {
									mmStart = start;
									mmBefore = before;
									mmAfter = after;
						}
			}
		
			private final class EditTextChangeListener implements TextWatcher {
				
						private CharSequence mBeforeChange;
						private CharSequence mAfterChange;
				
						public void beforeTextChanged(CharSequence s, int start, int count,
								int after) {
									if (mIsUndoOrRedo) {
												return;
									}
						
									mBeforeChange = s.subSequence(start, start + count);
						}
				
						public void onTextChanged(CharSequence s, int start, int before,
								int count) {
									if (mIsUndoOrRedo) {
												return;
									}
						
									mAfterChange = s.subSequence(start, start + count);
									mEditHistory.add(new EditItem(start, mBeforeChange, mAfterChange));
						}
				
						public void afterTextChanged(Editable s) {
						}
			}
	}
	{
	}
	
	
	public void _CustomDialogMaterial(final AlertDialog.Builder _dial, final boolean _booleann) {
		
		setTheme(android.R.style.Theme_Material);
		_dial.setCancelable(_booleann);
		AlertDialog alert = _dial.show();
		alert.getWindow().getDecorView().setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, Color.parseColor("#252525")));
			alert.getWindow().getDecorView().setPadding(8,8,8,8);
		alert.show();
		
		alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#ff0000"));
			alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#ff0000"));
			alert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.parseColor("#ff0000"));
		alert.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
		alert.getWindow().getDecorView().setTranslationY(-20);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}