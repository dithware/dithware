package com.inflps.codexyz;
import io.github.rosemoe.sora.widget.CodeEditor;
import io.github.rosemoe.sora.widget.schemes.HTMLScheme;
import io.github.rosemoe.sora.widget.schemes.SchemeDarcula;
import io.github.rosemoe.sora.widget.schemes.SchemeEclipse;
import io.github.rosemoe.sora.widget.schemes.SchemeGitHub;
import io.github.rosemoe.sora.widget.schemes.SchemeNotepadXX;
import io.github.rosemoe.sora.widget.schemes.SchemeVS2019;
import io.github.rosemoe.sora.langs.EmptyLanguage;
import io.github.rosemoe.sora.langs.desc.CDescription;
import io.github.rosemoe.sora.langs.desc.CppDescription;
import io.github.rosemoe.sora.langs.desc.JavaScriptDescription;
import io.github.rosemoe.sora.langs.html.HTMLLanguage;
import io.github.rosemoe.sora.langs.java.JavaLanguage;
import io.github.rosemoe.sora.langs.python.PythonLanguage;
import io.github.rosemoe.sora.langs.universal.UniversalLanguage;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import java.io.*;
import android.content.ClipboardManager;

public class EditorActivity extends AppCompatActivity {
	
	public final int REQ_CD_FP = 101;
	public final int REQ_CD_FPI = 102;
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private FloatingActionButton _fab;
	private String import_path = "";
	private String text = "";
	private String fontName = "";
	private String typeace = "";
	private boolean tmenu = false;
	private boolean Keyboard = false;
	private String jsonData = "";
	private boolean SpeechToText = false;
	private String htmlbin = "";
	private double l = 0;
	private String hx = "";
	private double nm = 0;
	private double pis = 0;
	private double number = 0;
	private String o = "";
	private String u = "";
	
	private ArrayList<HashMap<String, Object>> Languag_list = new ArrayList<>();
	private ArrayList<String> list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private LinearLayout linear;
	private CodeEditor editor;
	private LinearLayout extra_menu_root;
	private LinearLayout linear48;
	private ImageView cut;
	private ImageView copy;
	private ImageView clear;
	private ImageView save_btn;
	private ImageView lock;
	private TextView textview20;
	private LinearLayout linear49;
	private ImageView imageview44;
	private Spinner spinner1;
	private TabLayout tablayout1;
	private LinearLayout linear58;
	private ScrollView vscroll1;
	private LinearLayout history_page;
	private LinearLayout linear2;
	private LinearLayout instruments_page;
	private LinearLayout properties_page;
	private LinearLayout output_page;
	private LinearLayout linear20;
	private LinearLayout linear21;
	private LinearLayout linear55;
	private LinearLayout linear56;
	private LinearLayout linear22;
	private LinearLayout linear23;
	private LinearLayout linear28;
	private LinearLayout linear29;
	private LinearLayout linear30;
	private LinearLayout linear31;
	private LinearLayout linear32;
	private LinearLayout linear35;
	private LinearLayout linear36;
	private LinearLayout linear40;
	private LinearLayout linear41;
	private ImageView imageview13;
	private TextView textview6;
	private ImageView imageview91;
	private TextView textview22;
	private ImageView imageview14;
	private TextView textview7;
	private LinearLayout linear25;
	private LinearLayout linear26;
	private ImageView imageview16;
	private ImageView imageview17;
	private ImageView imageview19;
	private TextView textview8;
	private Button button1;
	private ImageView imageview21;
	private TextView textview10;
	private ImageView imageview22;
	private TextView textview11;
	private ImageView imageview24;
	private TextView textview13;
	private ImageView imageview28;
	private TextView textview16;
	private LinearLayout linear42;
	private LinearLayout linear43;
	private ImageView imageview30;
	private ImageView imageview31;
	private ImageView imageview32;
	private ImageView imageview40;
	private ImageView imageview41;
	private ImageView imageview42;
	private TextView textview17;
	private LinearLayout linear44;
	private TextView textview18;
	private LinearLayout linear45;
	private Button button3;
	private EditText edittext1;
	private ImageView imageview33;
	private ImageView imageview34;
	private EditText edittext2;
	private ImageView imageview35;
	private LinearLayout linear46;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear13;
	private LinearLayout linear12;
	private LinearLayout linear14;
	private ImageView imageview1;
	private TextView textview4;
	private ImageView imageview2;
	private Switch switch1;
	private ImageView imageview3;
	private Switch switch2;
	private ImageView imageview5;
	private Switch switch4;
	private ImageView imageview6;
	private TextView textview5;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private ImageView imageview7;
	private ImageView imageview8;
	private ImageView imageview9;
	private ImageView imageview10;
	private ImageView imageview11;
	private ImageView imageview47;
	private ImageView imageview12;
	private ImageView imageview48;
	private ImageView imageview50;
	private ImageView imageview51;
	private ImageView imageview52;
	private ImageView imageview53;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private LinearLayout linear19;
	private LinearLayout linear50;
	private LinearLayout linear51;
	private LinearLayout linear52;
	private CheckBox checkbox1;
	private CheckBox checkbox2;
	private CheckBox checkbox3;
	private CheckBox checkbox4;
	private CheckBox checkbox5;
	private CheckBox checkbox6;
	private LinearLayout linear53;
	private TextView output_preview;
	private TextView output_title;
	private ImageView imageview88;
	private ImageView imageview89;
	private LinearLayout linear57;
	private ListView listview1;
	private TextView textview25;
	private ImageView imageview94;
	private ImageView imageview93;
	
	private Intent saved_intent = new Intent();
	private Intent go = new Intent();
	private SharedPreferences save;
	private AlertDialog.Builder about;
	private AlertDialog.Builder exp;
	private AlertDialog.Builder replace;
	private AlertDialog.Builder save_file;
	private AlertDialog.Builder search;
	private AlertDialog.Builder theme;
	private Intent i = new Intent();
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private TimerTask t;
	private TimerTask tt;
	private AlertDialog.Builder exit;
	private SpeechRecognizer stt;
	private Intent fpi = new Intent(Intent.ACTION_GET_CONTENT);
	private TimerTask run1;
	private Intent run = new Intent();
	private AlertDialog.Builder exitt;
	private AlertDialog.Builder saveas;
	private TimerTask ttt;
	private AlertDialog.Builder alert;
	private SharedPreferences settings;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.editor);
		initialize(_savedInstanceState);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.RECORD_AUDIO}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_fab = findViewById(R.id._fab);
		
		linear = findViewById(R.id.linear);
		editor = findViewById(R.id.editor);
		extra_menu_root = findViewById(R.id.extra_menu_root);
		linear48 = findViewById(R.id.linear48);
		cut = findViewById(R.id.cut);
		copy = findViewById(R.id.copy);
		clear = findViewById(R.id.clear);
		save_btn = findViewById(R.id.save_btn);
		lock = findViewById(R.id.lock);
		textview20 = findViewById(R.id.textview20);
		linear49 = findViewById(R.id.linear49);
		imageview44 = findViewById(R.id.imageview44);
		spinner1 = findViewById(R.id.spinner1);
		tablayout1 = findViewById(R.id.tablayout1);
		linear58 = findViewById(R.id.linear58);
		vscroll1 = findViewById(R.id.vscroll1);
		history_page = findViewById(R.id.history_page);
		linear2 = findViewById(R.id.linear2);
		instruments_page = findViewById(R.id.instruments_page);
		properties_page = findViewById(R.id.properties_page);
		output_page = findViewById(R.id.output_page);
		linear20 = findViewById(R.id.linear20);
		linear21 = findViewById(R.id.linear21);
		linear55 = findViewById(R.id.linear55);
		linear56 = findViewById(R.id.linear56);
		linear22 = findViewById(R.id.linear22);
		linear23 = findViewById(R.id.linear23);
		linear28 = findViewById(R.id.linear28);
		linear29 = findViewById(R.id.linear29);
		linear30 = findViewById(R.id.linear30);
		linear31 = findViewById(R.id.linear31);
		linear32 = findViewById(R.id.linear32);
		linear35 = findViewById(R.id.linear35);
		linear36 = findViewById(R.id.linear36);
		linear40 = findViewById(R.id.linear40);
		linear41 = findViewById(R.id.linear41);
		imageview13 = findViewById(R.id.imageview13);
		textview6 = findViewById(R.id.textview6);
		imageview91 = findViewById(R.id.imageview91);
		textview22 = findViewById(R.id.textview22);
		imageview14 = findViewById(R.id.imageview14);
		textview7 = findViewById(R.id.textview7);
		linear25 = findViewById(R.id.linear25);
		linear26 = findViewById(R.id.linear26);
		imageview16 = findViewById(R.id.imageview16);
		imageview17 = findViewById(R.id.imageview17);
		imageview19 = findViewById(R.id.imageview19);
		textview8 = findViewById(R.id.textview8);
		button1 = findViewById(R.id.button1);
		imageview21 = findViewById(R.id.imageview21);
		textview10 = findViewById(R.id.textview10);
		imageview22 = findViewById(R.id.imageview22);
		textview11 = findViewById(R.id.textview11);
		imageview24 = findViewById(R.id.imageview24);
		textview13 = findViewById(R.id.textview13);
		imageview28 = findViewById(R.id.imageview28);
		textview16 = findViewById(R.id.textview16);
		linear42 = findViewById(R.id.linear42);
		linear43 = findViewById(R.id.linear43);
		imageview30 = findViewById(R.id.imageview30);
		imageview31 = findViewById(R.id.imageview31);
		imageview32 = findViewById(R.id.imageview32);
		imageview40 = findViewById(R.id.imageview40);
		imageview41 = findViewById(R.id.imageview41);
		imageview42 = findViewById(R.id.imageview42);
		textview17 = findViewById(R.id.textview17);
		linear44 = findViewById(R.id.linear44);
		textview18 = findViewById(R.id.textview18);
		linear45 = findViewById(R.id.linear45);
		button3 = findViewById(R.id.button3);
		edittext1 = findViewById(R.id.edittext1);
		imageview33 = findViewById(R.id.imageview33);
		imageview34 = findViewById(R.id.imageview34);
		edittext2 = findViewById(R.id.edittext2);
		imageview35 = findViewById(R.id.imageview35);
		linear46 = findViewById(R.id.linear46);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		linear10 = findViewById(R.id.linear10);
		linear11 = findViewById(R.id.linear11);
		linear13 = findViewById(R.id.linear13);
		linear12 = findViewById(R.id.linear12);
		linear14 = findViewById(R.id.linear14);
		imageview1 = findViewById(R.id.imageview1);
		textview4 = findViewById(R.id.textview4);
		imageview2 = findViewById(R.id.imageview2);
		switch1 = findViewById(R.id.switch1);
		imageview3 = findViewById(R.id.imageview3);
		switch2 = findViewById(R.id.switch2);
		imageview5 = findViewById(R.id.imageview5);
		switch4 = findViewById(R.id.switch4);
		imageview6 = findViewById(R.id.imageview6);
		textview5 = findViewById(R.id.textview5);
		linear15 = findViewById(R.id.linear15);
		linear16 = findViewById(R.id.linear16);
		imageview7 = findViewById(R.id.imageview7);
		imageview8 = findViewById(R.id.imageview8);
		imageview9 = findViewById(R.id.imageview9);
		imageview10 = findViewById(R.id.imageview10);
		imageview11 = findViewById(R.id.imageview11);
		imageview47 = findViewById(R.id.imageview47);
		imageview12 = findViewById(R.id.imageview12);
		imageview48 = findViewById(R.id.imageview48);
		imageview50 = findViewById(R.id.imageview50);
		imageview51 = findViewById(R.id.imageview51);
		imageview52 = findViewById(R.id.imageview52);
		imageview53 = findViewById(R.id.imageview53);
		linear17 = findViewById(R.id.linear17);
		linear18 = findViewById(R.id.linear18);
		linear19 = findViewById(R.id.linear19);
		linear50 = findViewById(R.id.linear50);
		linear51 = findViewById(R.id.linear51);
		linear52 = findViewById(R.id.linear52);
		checkbox1 = findViewById(R.id.checkbox1);
		checkbox2 = findViewById(R.id.checkbox2);
		checkbox3 = findViewById(R.id.checkbox3);
		checkbox4 = findViewById(R.id.checkbox4);
		checkbox5 = findViewById(R.id.checkbox5);
		checkbox6 = findViewById(R.id.checkbox6);
		linear53 = findViewById(R.id.linear53);
		output_preview = findViewById(R.id.output_preview);
		output_title = findViewById(R.id.output_title);
		imageview88 = findViewById(R.id.imageview88);
		imageview89 = findViewById(R.id.imageview89);
		linear57 = findViewById(R.id.linear57);
		listview1 = findViewById(R.id.listview1);
		textview25 = findViewById(R.id.textview25);
		imageview94 = findViewById(R.id.imageview94);
		imageview93 = findViewById(R.id.imageview93);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		about = new AlertDialog.Builder(this);
		exp = new AlertDialog.Builder(this);
		replace = new AlertDialog.Builder(this);
		save_file = new AlertDialog.Builder(this);
		search = new AlertDialog.Builder(this);
		theme = new AlertDialog.Builder(this);
		fp.setType("text/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		exit = new AlertDialog.Builder(this);
		stt = SpeechRecognizer.createSpeechRecognizer(this);
		fpi.setType("image/*");
		fpi.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		exitt = new AlertDialog.Builder(this);
		saveas = new AlertDialog.Builder(this);
		alert = new AlertDialog.Builder(this);
		settings = getSharedPreferences("settings", Activity.MODE_PRIVATE);
		
		editor.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (tmenu) {
					extra_menu_root.setVisibility(View.GONE);
					_fab.show();
					tmenu = false;
				}
				else {
					
				}
			}
		});
		
		cut.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (editor.getText().toString().trim().equals("")) {
					
				}
				else {
					{
						HashMap<String, Object> _item = new HashMap<>();
						_item.put("text", editor.getText().toString());
						listmap.add(_item);
					}
					
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					editor.setText("");
				}
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", editor.getText().toString()));
				editor.setText("");
			}
		});
		
		copy.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", editor.getText().toString()));
			}
		});
		
		clear.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				alert.setTitle("Notice");
				alert.setMessage("We will empty all the text content! This will store in the history that you can retrieve back. ");
				alert.setIcon(R.drawable.error_file);
				alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (editor.getText().toString().trim().equals("")) {
							
						}
						else {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("text", editor.getText().toString());
								listmap.add(_item);
							}
							
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
							editor.setText("");
						}
					}
				});
				alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				_CustomDialogMaterial(alert, true);
			}
		});
		
		save_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				View popupView = getLayoutInflater().inflate(R.layout.saveas, null);
				
				//popup is the name of your custom view
				
				final PopupWindow popup = new PopupWindow(popupView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
				LinearLayout bg = popupView.findViewById(R.id.linear4);
				
				TextView txt2 = popupView.findViewById(R.id.textview2);
				
				LinearLayout o1 = popupView.findViewById(R.id.option1);
				
				LinearLayout o2 = popupView.findViewById(R.id.option2);
				
				LinearLayout o3 = popupView.findViewById(R.id.option3);
				
				LinearLayout o4 = popupView.findViewById(R.id.option4);
				
				LinearLayout o5 = popupView.findViewById(R.id.option5);
				
				LinearLayout o6 = popupView.findViewById(R.id.option6);
				
				LinearLayout o7 = popupView.findViewById(R.id.option7);
				
				LinearLayout o8 = popupView.findViewById(R.id.option8);
				txt2.setText("Save as current extension ".concat("(".concat(getIntent().getStringExtra("type").concat(")"))));
				o1.setOnClickListener(new OnClickListener() { public void onClick(View view) {
						FileUtil.writeFile(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(getIntent().getStringExtra("type")))), editor.getText().toString());
						_createSnackBar("Saved in: ".concat(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(getIntent().getStringExtra("type"))))));
						popup.dismiss();
					} });
				
				o2.setOnClickListener(new OnClickListener() { public void onClick(View view) {
						FileUtil.writeFile(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(".html"))), editor.getText().toString());
						_createSnackBar("Saved in: ".concat(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(".html")))));
						popup.dismiss();
					} });
				
				o3.setOnClickListener(new OnClickListener() { public void onClick(View view) {
						FileUtil.writeFile(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(".css"))), editor.getText().toString());
						_createSnackBar("Saved in: ".concat(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(".css")))));
						popup.dismiss();
					} });
				
				o4.setOnClickListener(new OnClickListener() { public void onClick(View view) {
						FileUtil.writeFile(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(".json"))), editor.getText().toString());
						_createSnackBar("Saved in: ".concat(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(".json")))));
						popup.dismiss();
					} });
				
				o5.setOnClickListener(new OnClickListener() { public void onClick(View view) {
						FileUtil.writeFile(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(".java"))), editor.getText().toString());
						_createSnackBar("Saved in: ".concat(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(".java")))));
						popup.dismiss();
					} });
				
				o6.setOnClickListener(new OnClickListener() { public void onClick(View view) {
						FileUtil.writeFile(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(".txt"))), editor.getText().toString());
						_createSnackBar("Saved in: ".concat(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(".txt")))));
						popup.dismiss();
					} });
				
				o7.setOnClickListener(new OnClickListener() { public void onClick(View view) {
						FileUtil.writeFile(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(".docs"))), editor.getText().toString());
						_createSnackBar("Saved in: ".concat(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(".docs")))));
						popup.dismiss();
					} });
				
				o8.setOnClickListener(new OnClickListener() { public void onClick(View view) {
						saveas.setTitle("Customize the extension");
						saveas.setMessage("No period (.) required!");
						final EditText edittext_extension = new EditText(EditorActivity.this);
						edittext_extension.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
						edittext_extension.setTextColor(0xFFFFFFFF);
						
						com.google.android.material.textfield.TextInputLayout textinput_search = new com.google.android.material.textfield.TextInputLayout(EditorActivity.this);
						textinput_search.setPadding(16, 0, 16, 0);
						textinput_search.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
						textinput_search.addView(edittext_extension);
						saveas.setView(textinput_search);
						saveas.setPositiveButton("Set and save ", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								FileUtil.writeFile(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(".".concat(edittext_extension.getText().toString())))), editor.getText().toString());
								_createSnackBar("Saved in: ".concat(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(".".concat(edittext_extension.getText().toString()))))));
							}
						});
						saveas.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						_CustomDialogMaterial(saveas, false);
						popup.dismiss();
					} });
				
				android.graphics.drawable.GradientDrawable round = new android.graphics.drawable.GradientDrawable ();
				round.setColor (Color.parseColor("#444444"));
				
				round.setCornerRadius (20);
				
				bg.setBackground (round);
				
				popup.setAnimationStyle(android.R.style.Animation_Dialog);
				
				popup.showAsDropDown(save_btn, 0,0);
			}
		});
		
		lock.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (editor.isEnabled()) {
					editor.setEnabled(false);
					lock.setImageResource(R.drawable.ic_lock_outline_white);
				}
				else {
					editor.setEnabled(true);
					lock.setImageResource(R.drawable.ic_lock_white);
				}
			}
		});
		
		spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (_position == 0) {
					editor.setEditorLanguage(new EmptyLanguage());
					imageview44.setImageResource(R.drawable.l_none);
				}
				else {
					if (_position == 1) {
						editor.setEditorLanguage(new JavaLanguage());
						imageview44.setImageResource(R.drawable.l_java);
					}
					else {
						if (_position == 2) {
							editor.setEditorLanguage(new UniversalLanguage(new JavaScriptDescription()));
							imageview44.setImageResource(R.drawable.l_javascript);
						}
						else {
							if (_position == 3) {
								editor.setEditorLanguage(new UniversalLanguage(new CppDescription()));
								imageview44.setImageResource(R.drawable.l_cpp);
							}
							else {
								if (_position == 4) {
									imageview44.setImageResource(R.drawable.l_c);
									editor.setEditorLanguage(new UniversalLanguage(new CDescription()));
								}
							}
						}
					}
				}
			}
			
			@Override
			public void onNothingSelected(AdapterView<?> _param1) {
				
			}
		});
		
		tablayout1.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
			@Override
			public void onTabSelected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				if (_position == 0) {
					vscroll1.setVisibility(View.VISIBLE);
					instruments_page.setVisibility(View.VISIBLE);
					properties_page.setVisibility(View.GONE);
					output_page.setVisibility(View.GONE);
					history_page.setVisibility(View.GONE);
				}
				else {
					if (_position == 1) {
						vscroll1.setVisibility(View.VISIBLE);
						instruments_page.setVisibility(View.GONE);
						properties_page.setVisibility(View.VISIBLE);
						output_page.setVisibility(View.GONE);
						history_page.setVisibility(View.GONE);
					}
					else {
						if (_position == 2) {
							vscroll1.setVisibility(View.VISIBLE);
							instruments_page.setVisibility(View.GONE);
							properties_page.setVisibility(View.GONE);
							output_page.setVisibility(View.VISIBLE);
							history_page.setVisibility(View.GONE);
						}
						else {
							if (_position == 3) {
								vscroll1.setVisibility(View.GONE);
								instruments_page.setVisibility(View.GONE);
								properties_page.setVisibility(View.GONE);
								output_page.setVisibility(View.GONE);
								history_page.setVisibility(View.VISIBLE);
							}
						}
					}
				}
			}
			
			@Override
			public void onTabUnselected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				
			}
			
			@Override
			public void onTabReselected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				
			}
		});
		
		linear20.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				alert.setTitle("Warning");
				alert.setMessage("We will modify the text parameters. Unfortunately it cannot perform the undo action but you can recover from the history..");
				alert.setIcon(R.drawable.error_file);
				alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (editor.getText().toString().trim().equals("")) {
							
						}
						else {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("text", editor.getText().toString());
								listmap.add(_item);
							}
							
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
							if (editor.getText().toString().equals("")) {
									SketchwareUtil.showMessage(getApplicationContext(), "The text is empty ");
							}
							else {
									jsonData = editor.getText().toString();
									{
												final String json_str = jsonData;
												final int indent_width = 4;
													
												    final char[] chars = json_str.toCharArray();
												    final String newline = System.lineSeparator();
												
												final boolean[] begin_quotes = {false};
												   
												final int[] progres = {0};
												 
												final String[] ret = {""};
												
												final ProgressDialog prog = new ProgressDialog(EditorActivity.this);
												
												prog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
												
												prog.setIndeterminate(false);
												
												prog.setMax(chars.length);
												
												prog.setMessage("Formatting in progress...");
												
												prog.setCancelable(false);
												
												prog.show();
												new Thread(new Runnable() {
																@Override
																public void run() {
																				Looper.prepare();
																				
																				
																				    for (int i = 0, indent = 0; i < chars.length; i++) {
																								        char c = chars[i];
																								
																								prog.setProgress(i);
																								
																								
																								
																								        if (c == '\"') {
																												            ret[0] += c;
																												            begin_quotes[0] = !begin_quotes[0];
																												            continue;
																												        }
																								
																								        if (!begin_quotes[0]) {
																												            switch (c) {
																																            case '{':
																																            case '[':
																																                ret[0] += c + newline + String.format("%" + (indent += indent_width) + "s", "");
																																                continue;
																																            case '}':
																																            case ']':
																																                ret[0] += newline + ((indent -= indent_width) > 0 ? String.format("%" + indent + "s", "") : "") + c;
																																                continue;
																																            case ':':
																																                ret[0] += c + " ";
																																                continue;
																																            case ',':
																																                ret[0] += c + newline + (indent > 0 ? String.format("%" + indent + "s", "") : "");
																																                continue;
																																            default:
																																                if (Character.isWhitespace(c)) continue;
																																            }
																												        }
																								
																								        ret[0] += c + (c == '\\' ? "" + chars[++i] : "");
																								    }
																				
																				    
																				
																				
																				runOnUiThread(new Runnable() {
																								@Override
																								public void run() {
																												
																												
																												
																												prog.dismiss();
																												
																								{
																											StringBuilder stringBuilder = new StringBuilder();
																											
																											try {
																														
																														Scanner scanner = new Scanner(ret[0]).useDelimiter("\\Z");
																														while (scanner.hasNext()) {
																																	stringBuilder .append(scanner.next());
																														}
																														editor.setText(stringBuilder );
																											} catch (Exception rt) {
																														rt.printStackTrace();
																											}
																								}
																												
																												Looper.loop();
																								} 
																								
																				});
																}
												}).start();
												
									}
							}
						}
					}
				});
				alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				_CustomDialogMaterial(alert, true);
			}
		});
		
		linear55.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_reverse();
			}
		});
		
		linear29.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				editor.setText(editor.getText().toString().concat("{}"));
			}
		});
		
		linear31.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				editor.setText(editor.getText().toString().concat("[]"));
			}
		});
		
		linear35.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				if (SpeechToText) {
					
				}
				else {
					stt.cancel();
					stt.destroy();
					SpeechToText = true;
				}
				return true;
			}
		});
		
		linear35.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (SpeechToText) {
					Intent _intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
					_intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
					_intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
					_intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
					stt.startListening(_intent);
					SpeechToText = false;
					textview13.setText("Press again to finish the transcription");
				}
				else {
					stt.stopListening();
					SpeechToText = true;
					textview13.setText("Live transcription ");
				}
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				editor.setText(editor.getText().toString().concat(textview8.getText().toString()));
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().equals("") || edittext2.getText().toString().equals("")) {
					((EditText)edittext2).setError(" ");
					((EditText)edittext1).setError(" ");
					SketchwareUtil.showMessage(getApplicationContext(), "ERR_ IT_CANNOT_BE_REPLACED");
				}
				else {
					editor.setText(editor.getText().toString().replace(edittext1.getText().toString(), edittext2.getText().toString()));
				}
			}
		});
		
		imageview33.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				edittext1.setText("");
			}
		});
		
		imageview34.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().equals("")) {
					((EditText)edittext1).setError("Enter a word first...");
				}
				else {
					editor.getSearcher().search(edittext1.getText().toString());
				}
			}
		});
		
		imageview35.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				edittext2.setText("");
			}
		});
		
		linear3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				theme= new AlertDialog.Builder(EditorActivity.this, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
				theme.setTitle("Set Theme");
				theme.setPositiveButton("Dismiss", new DialogInterface.OnClickListener() { public void onClick(DialogInterface _dialog, int _which) {  } });
				String[] items = {"HTML", "Darcula", "Eclipse", "GitHub", "NotepadXX", "VS2019"};
				int checkItem = 0; 
				theme.setSingleChoiceItems(items, checkItem, new DialogInterface.OnClickListener() { public void onClick(DialogInterface dialog, int which) { switch (which) {
							case 0:
							editor.setColorScheme(new HTMLScheme());
							spinner1.setSelection((int)(1));
							break;
							case 1:
							editor.setColorScheme(new SchemeDarcula());
							spinner1.setSelection((int)(0));
							break;
							case 2:
							editor.setColorScheme(new SchemeEclipse());
							spinner1.setSelection((int)(0));
							break;
							case 3: 
							editor.setColorScheme(new SchemeGitHub());
							spinner1.setSelection((int)(0));
							break;
							case 4:
							editor.setColorScheme(new SchemeNotepadXX());
							spinner1.setSelection((int)(0));
							break;
							case 5:
							editor.setColorScheme(new SchemeVS2019());
							spinner1.setSelection((int)(0));
							 break; } } });
				_CustomDialogMaterial(theme, true);
			}
		});
		
		switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					editor.setWordwrap(true);
				}
				else {
					editor.setWordwrap(false);
				}
			}
		});
		
		switch2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					editor.setOverScrollEnabled(true);
				}
				else {
					editor.setOverScrollEnabled(false);
				}
			}
		});
		
		switch4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					editor.setLineNumberEnabled(true);
				}
				else {
					editor.setLineNumberEnabled(false);
				}
			}
		});
		
		checkbox1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					checkbox2.setChecked(false);
					checkbox3.setChecked(false);
					checkbox4.setChecked(false);
					checkbox5.setChecked(false);
					checkbox6.setChecked(false);
					editor.setTypefaceText(Typeface.createFromAsset(getAssets(), "fonts/droid_sans_mono"+".ttf"));
				}
			}
		});
		
		checkbox2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					checkbox1.setChecked(false);
					checkbox3.setChecked(false);
					checkbox4.setChecked(false);
					checkbox5.setChecked(false);
					checkbox6.setChecked(false);
					editor.setTypefaceText(Typeface.createFromAsset(getAssets(), "fonts/default_font"+".ttf"));
				}
			}
		});
		
		checkbox3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					checkbox2.setChecked(false);
					checkbox1.setChecked(false);
					checkbox4.setChecked(false);
					checkbox5.setChecked(false);
					checkbox6.setChecked(false);
					editor.setTypefaceText(Typeface.createFromAsset(getAssets(), "fonts/ubuntu"+".ttf"));
				}
			}
		});
		
		checkbox4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					checkbox2.setChecked(false);
					checkbox3.setChecked(false);
					checkbox1.setChecked(false);
					checkbox5.setChecked(false);
					checkbox6.setChecked(false);
					editor.setTypefaceText(Typeface.createFromAsset(getAssets(), "fonts/nato_sans"+".ttf"));
				}
			}
		});
		
		checkbox5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					checkbox2.setChecked(false);
					checkbox3.setChecked(false);
					checkbox4.setChecked(false);
					checkbox1.setChecked(false);
					checkbox6.setChecked(false);
					editor.setTypefaceText(Typeface.createFromAsset(getAssets(), "fonts/open_sans"+".ttf"));
				}
			}
		});
		
		checkbox6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					checkbox2.setChecked(false);
					checkbox3.setChecked(false);
					checkbox4.setChecked(false);
					checkbox5.setChecked(false);
					checkbox1.setChecked(false);
					editor.setTypefaceText(Typeface.createFromAsset(getAssets(), "fonts/armata"+".ttf"));
				}
			}
		});
		
		imageview88.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				imageview88.setVisibility(View.GONE);
				imageview89.setVisibility(View.VISIBLE);
				_blurTextView(output_preview, true);
			}
		});
		
		imageview89.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				imageview88.setVisibility(View.VISIBLE);
				imageview89.setVisibility(View.GONE);
				_blurTextView(output_preview, false);
			}
		});
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				alert.setTitle("Do you want to recover this phase?");
				alert.setIcon(R.drawable.project_setup);
				alert.setMessage("The current content will be replaced with this phase. Will you continue though?");
				alert.setPositiveButton("Ok (Replace)", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (editor.getText().toString().trim().equals("")) {
							
						}
						else {
							u = editor.getText().toString().trim();
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("text", u);
								listmap.add(_item);
							}
							
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						}
						o = listmap.get((int)_position).get("text").toString();
						editor.setText(o);
					}
				});
				alert.setNegativeButton("Cancel ", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				_CustomDialogMaterial(alert, true);
			}
		});
		
		imageview94.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				history_page.setBackgroundColor(0xFFFFFFFF);
				ttt = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								history_page.setBackgroundColor(Color.TRANSPARENT);
							}
						});
					}
				};
				_timer.schedule(ttt, (int)(500));
			}
		});
		
		imageview93.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				alert.setTitle("Warning");
				alert.setMessage("Do you want to clear all history? This action cannot be undone!");
				alert.setIcon(R.drawable.error_file);
				alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						listmap.clear();
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
				});
				alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				_CustomDialogMaterial(alert, true);
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_fab.hide();
				extra_menu_root.setVisibility(View.VISIBLE);
				tmenu = true;
				Keyboard = true;
			}
		});
		
		stt.setRecognitionListener(new RecognitionListener() {
			@Override
			public void onReadyForSpeech(Bundle _param1) {
			}
			
			@Override
			public void onBeginningOfSpeech() {
			}
			
			@Override
			public void onRmsChanged(float _param1) {
			}
			
			@Override
			public void onBufferReceived(byte[] _param1) {
			}
			
			@Override
			public void onEndOfSpeech() {
			}
			
			@Override
			public void onPartialResults(Bundle _param1) {
			}
			
			@Override
			public void onEvent(int _param1, Bundle _param2) {
			}
			
			@Override
			public void onResults(Bundle _param1) {
				final ArrayList<String> _results = _param1.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
				final String _result = _results.get(0);
				editor.setText(editor.getText().toString().concat(_result));
			}
			
			@Override
			public void onError(int _param1) {
				final String _errorMessage;
				switch (_param1) {
					case SpeechRecognizer.ERROR_AUDIO:
					_errorMessage = "audio error";
					break;
					
					case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
					_errorMessage = "speech timeout";
					break;
					
					case SpeechRecognizer.ERROR_NO_MATCH:
					_errorMessage = "speech no match";
					break;
					
					case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
					_errorMessage = "recognizer busy";
					break;
					
					case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
					_errorMessage = "recognizer insufficient permissions";
					break;
					
					default:
					_errorMessage = "recognizer other error";
					break;
				}
				SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
			}
		});
	}
	
	private void initializeLogic() {
		getSupportActionBar().setDisplayHomeAsUpEnabled(false);
		if (!save.getString("save", "").equals("")) {
			editor.setText(save.getString("save", ""));
		}
		_Languags();
		android.graphics.drawable.GradientDrawable _BackgroundOf_editor = new android.graphics.drawable.GradientDrawable();
		_BackgroundOf_editor.setColors(new int[]{0xFF424242, 0xFF424242});
		_BackgroundOf_editor.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM);
		editor.setBackground(_BackgroundOf_editor);
		editor.setTypefaceText(Typeface.createFromAsset(getAssets(), "fonts/droid_sans_mono"+".ttf"));
		editor.setEditorLanguage(new EmptyLanguage());
		editor.setColorScheme(new SchemeDarcula());
		editor.setOverScrollEnabled(true);
		_Ripple_Drawable(cut, "#b2dfdb");
		_Ripple_Drawable(copy, "#b2dfdb");
		_Ripple_Drawable(clear, "#b2dfdb");
		_Ripple_Drawable(save_btn, "#b2dfdb");
		_Ripple_Drawable(lock, "#b2dfdb");
		com.google.android.material.appbar.AppBarLayout appBarLayout = (com.google.android.material.appbar.AppBarLayout)_toolbar.getParent(); appBarLayout.setStateListAnimator(null);
		
		
		vscroll1.setVerticalScrollBarEnabled(false);
		
		vscroll1.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
		
		setTitle(getIntent().getStringExtra("title").concat(getIntent().getStringExtra("type")));
		tablayout1.addTab(tablayout1.newTab().setText("Instruments"));
		tablayout1.addTab(tablayout1.newTab().setText("Properties"));
		tablayout1.addTab(tablayout1.newTab().setText("Output"));
		tablayout1.addTab(tablayout1.newTab().setText("History"));
		tablayout1.setSelectedTabIndicatorColor(0xFFFF0000);
		tablayout1.setSelectedTabIndicatorHeight(5);
		tablayout1.setTabTextColors(0xFFFFFFFF, 0xFFFF0000);
		tablayout1.setTabRippleColor(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_pressed}}, 
		
		new int[] {0xFF262626}));
		checkbox1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/droid_sans_mono.ttf"), 0);
		checkbox2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/default_font.ttf"), 0);
		checkbox3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/ubuntu.ttf"), 0);
		checkbox4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nato_sans.ttf"), 0);
		checkbox5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_sans.ttf"), 0);
		checkbox6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/armata.ttf"), 0);
		//Clipboard
		try{
			tt = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
							textview8.setText(clipboard.getText());
						}
					});
				}
			};
			_timer.scheduleAtFixedRate(tt, (int)(1000), (int)(1000));
		}catch(Exception e){
			SketchwareUtil.showMessage(getApplicationContext(), "Error! Clipboard manager could not be loaded!");
		}
		//Testing
		listview1.setAdapter(new Listview1Adapter(listmap));
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("text", "↓↓↓");
			listmap.add(_item);
		}
		
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				try {
					            editor.getSearcher().replaceAll(_filePath.get((int)(0)));
					        } catch (IllegalStateException e) {
					            e.printStackTrace();
					        }
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	
	@Override
	public void onBackPressed() {
		if (tmenu) {
			extra_menu_root.setVisibility(View.GONE);
			_fab.show();
			tmenu = false;
			Keyboard = false;
		}
		else {
			exit.setTitle("Do you want to abandon  this new file?");
			exit.setPositiveButton("Abandon", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					finish();
				}
			});
			exit.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					
				}
			});
			exit.setMessage("This action cannon be undone!");
			
			setTheme(android.R.style.Theme_Material);
			exit.setCancelable(false);
			AlertDialog alert = exit.show();
			alert.getWindow().getDecorView().setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, Color.parseColor("#252525")));
				alert.getWindow().getDecorView().setPadding(8,8,8,8);
			alert.show();
			
			alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#ff0000"));
				alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#ff0000"));
				alert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.parseColor("#ff0000"));
			alert.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
			alert.getWindow().getDecorView().setTranslationY(-20);
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		extra_menu_root.setVisibility(View.GONE);
		imageview89.setVisibility(View.GONE);
		output_title.setText("Location: ".concat(getIntent().getStringExtra("path").concat("/".concat(getIntent().getStringExtra("title").concat(getIntent().getStringExtra("type"))))));
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						output_preview.setText(editor.getText().toString());
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t, (int)(1000), (int)(1000));
		SpeechToText = true;
		htmlbin = FileUtil.getExternalStorageDir().concat("/CodeXYZ/Temp/Package/Logs/Bin/HTML");
		if (!FileUtil.isExistFile(htmlbin)) {
			FileUtil.makeDir(htmlbin);
		}
	}
	
	@Override
	public void onStop() {
		super.onStop();
		if (settings.getString("notification", "").equals("t")) {
			_set_Notification("CodeXYZ", "Running in progress...");
		}
		else {
			
		}
	}
	
	@Override
	public void onPause() {
		super.onPause();
		if (settings.getString("notification", "").equals("t")) {
			_set_Notification("CodeXYZ", "Running in progress...");
		}
		else {
			
		}
	}
	public void _MENU() {
	}
	@Override
	public boolean onCreateOptionsMenu (Menu menu){
		menu.add(0, 0, 0, "About");
		menu.add(0, 1, 1, "Search");
		menu.add(0, 2, 2, "Theme");
		menu.add(0, 3, 3, "Exit");
		
		menu.add(0, 4, 4, "Runs as HTML").setIcon(R.drawable.ic_play_arrow_white).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		menu.add(0, 5, 5, "More tools").setIcon(R.drawable.ic_now_widgets_white).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		menu.add(0, 6, 6, "Undo").setIcon(R.drawable.ic_undo_white_48dp).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		menu.add(0, 7, 7, "Redo").setIcon(R.drawable.ic_redo_white_48dp).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item){
		switch (item.getItemId()){
			case 0:
			about= new AlertDialog.Builder(EditorActivity.this, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
			about.setTitle("About ");
			about.setMessage("Library by: Rosemoe \n Version: 0.7.2 ");
			about.setPositiveButton("OK", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					
				}
			});
			about.setNegativeButton("View Library", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					go.setAction(Intent.ACTION_VIEW);
					go.setData(Uri.parse("https://github.com/Rosemoe/CodeEditor/"));
					startActivity(go);
				}
			});
			about.setNeutralButton("Get blocks for Sketchware", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					if (!FileUtil.isDirectory(FileUtil.getExternalStorageDir().concat("/CodeXYZ/Projects/"))) {
						FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/CodeXYZ/Projects/"));
					}
					FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/CodeXYZ/Sketchware/Blocks/Codera.json"), readFileFromAsset("Codera.json"));
					_createSnackBar(FileUtil.getExternalStorageDir().concat("/CodeXYZ/Sketchware/Blocks/Codera.json"));
					if (settings.getString("notification", "").equals("t")) {
						_set_Notification("Saved in:", FileUtil.getExternalStorageDir().concat("/CodeXYZ/Sketchware/Blocks/Codera.json"));
					}
					else {
						
					}
				}
			});
			_CustomDialogMaterial(about, true);
			break;
			case 1:
			
			search= new AlertDialog.Builder(EditorActivity.this, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
			search.setTitle("Word search");
			final EditText edittext_search = new EditText(EditorActivity.this);
			edittext_search.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
			
			com.google.android.material.textfield.TextInputLayout textinput_search = new com.google.android.material.textfield.TextInputLayout(EditorActivity.this);
			textinput_search.setPadding(16, 0, 16, 0);
			textinput_search.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
			textinput_search.addView(edittext_search);
			search.setView(textinput_search);
			search.setPositiveButton("Search", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					editor.getSearcher().search(edittext_search.getText().toString());
				}
			});
			search.setNegativeButton("Cancel ", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					
				}
			});
			_CustomDialogMaterial(search, false);
			break;
			case 2:
			
			theme= new AlertDialog.Builder(EditorActivity.this, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
			theme.setTitle("Set Theme");
			theme.setPositiveButton("Dismiss", new DialogInterface.OnClickListener() { public void onClick(DialogInterface _dialog, int _which) {  } });
			String[] items = {"HTML", "Darcula", "Eclipse", "GitHub", "NotepadXX", "VS2019"};
			int checkItem = 0; 
			theme.setSingleChoiceItems(items, checkItem, new DialogInterface.OnClickListener() { public void onClick(DialogInterface dialog, int which) { switch (which) {
						case 0:
						editor.setColorScheme(new HTMLScheme());
						spinner1.setSelection((int)(1));
						break;
						case 1:
						editor.setColorScheme(new SchemeDarcula());
						spinner1.setSelection((int)(0));
						break;
						case 2:
						editor.setColorScheme(new SchemeEclipse());
						spinner1.setSelection((int)(0));
						break;
						case 3: 
						editor.setColorScheme(new SchemeGitHub());
						spinner1.setSelection((int)(0));
						break;
						case 4:
						editor.setColorScheme(new SchemeNotepadXX());
						spinner1.setSelection((int)(0));
						break;
						case 5:
						editor.setColorScheme(new SchemeVS2019());
						spinner1.setSelection((int)(0));
						 break; } } });
			
			_CustomDialogMaterial(theme, true);
			break;
			case 3:
			exitt.setTitle(" You want to exit the app?");
			exitt.setPositiveButton("Continue (Kill Progress)", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					i.setClass(getApplicationContext(), ExitConfirmationActivity.class);
					startActivity(i);
				}
			});
			exitt.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					
				}
			});
			_CustomDialogMaterial(exitt, true);
			break;
			case 4:
			if (!FileUtil.isExistFile(htmlbin.concat("/".concat(getIntent().getStringExtra("title").concat(".html"))))) {
				FileUtil.writeFile(htmlbin.concat("/".concat(getIntent().getStringExtra("title").concat(".html"))), editor.getText().toString().trim());
				_without_dismiss("Compiling...");
				run1 = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								_without_dismiss("Preparing...");
								run1 = new TimerTask() {
									@Override
									public void run() {
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												_without_dismiss("Opening...");
												run.setClass(getApplicationContext(), HtmlPreviewActivity.class);
												run.putExtra("name", getIntent().getStringExtra("title").concat(".html"));
												startActivity(run);
											}
										});
									}
								};
								_timer.schedule(run1, (int)(250));
							}
						});
					}
				};
				_timer.schedule(run1, (int)(250));
			}
			else {
				//* 
				FileUtil.deleteFile(htmlbin.concat("/".concat(getIntent().getStringExtra("title").concat(".html"))));
				run1 = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								_without_dismiss("Deleting...");
								FileUtil.writeFile(htmlbin.trim(), getIntent().getStringExtra("title").concat(".html").trim());
								run1 = new TimerTask() {
									@Override
									public void run() {
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												_without_dismiss("Refreshing...");
												if (FileUtil.isExistFile(htmlbin.concat("/".concat(getIntent().getStringExtra("title").concat(".html"))))) {
													//*Continue process . 
													run1 = new TimerTask() {
														@Override
														public void run() {
															runOnUiThread(new Runnable() {
																@Override
																public void run() {
																	_without_dismiss("Compiling...");
																	run1 = new TimerTask() {
																		@Override
																		public void run() {
																			runOnUiThread(new Runnable() {
																				@Override
																				public void run() {
																					//*Result. 
																					_without_dismiss("Opening...");
																					run.setClass(getApplicationContext(), HtmlPreviewActivity.class);
																					run.putExtra("name", getIntent().getStringExtra("title").concat(".html"));
																					startActivity(run);
																				}
																			});
																		}
																	};
																	_timer.schedule(run1, (int)(250));
																}
															});
														}
													};
													_timer.schedule(run1, (int)(250));
												}
												else {
													FileUtil.writeFile(htmlbin.concat("/".concat(getIntent().getStringExtra("title").concat(".html"))), editor.getText().toString().trim());
													_without_dismiss("Compiling...");
													run1 = new TimerTask() {
														@Override
														public void run() {
															runOnUiThread(new Runnable() {
																@Override
																public void run() {
																	_without_dismiss("Preparing...");
																	run1 = new TimerTask() {
																		@Override
																		public void run() {
																			runOnUiThread(new Runnable() {
																				@Override
																				public void run() {
																					_without_dismiss("Opening...");
																					run.setClass(getApplicationContext(), HtmlPreviewActivity.class);
																					run.putExtra("name", getIntent().getStringExtra("title").concat(".html"));
																					startActivity(run);
																				}
																			});
																		}
																	};
																	_timer.schedule(run1, (int)(250));
																}
															});
														}
													};
													_timer.schedule(run1, (int)(250));
												}
											}
										});
									}
								};
								_timer.schedule(run1, (int)(120));
							}
						});
					}
				};
				_timer.schedule(run1, (int)(500));
			}
			break;
			case 5:
			i.setClass(getApplicationContext(), MoreToolsActivity.class);
			startActivity(i);
			break;
			case 6:
			if (editor.getText().toString().trim().equals("")) {
				
			}
			else {
				{
					HashMap<String, Object> _item = new HashMap<>();
					_item.put("text", editor.getText().toString());
					listmap.add(_item);
				}
				
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			editor.undo();
			break;
			case 7:
			if (editor.getText().toString().trim().equals("")) {
				
			}
			else {
				{
					HashMap<String, Object> _item = new HashMap<>();
					_item.put("text", editor.getText().toString());
					listmap.add(_item);
				}
				
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			editor.redo();
			break;
		}
		return super.onOptionsItemSelected(item);
	}
	
	
	public void _Elevation(final View _view, final double _number) {
		
		_view.setElevation((int)_number);
	}
	
	
	public void _setHighlighter(final TextView _view) {
		final String secondaryColor = "#678cb1";
		final String primaryColor = "#86b55a";
		final String numbersColor = "#f6c921";
		final String quotesColor = "#ff1744";
		final String commentsColor = "#9e9e9e";
		final String charColor = "#ff5722";
		final TextView regex1 = new TextView(this);
		final TextView regex2 = new TextView(this);
		final TextView regex3 = new TextView(this);
		final TextView regex4 = new TextView(this);
		final TextView regex5 = new TextView(this);
		final TextView regex6 = new TextView(this);
		final TextView regex7 = new TextView(this);
		final TextView regex8 = new TextView(this);
		final TextView regex9 = new TextView(this);
		final TextView regex10 = new TextView(this);
		final TextView regex11 = new TextView(this);
		
		regex1.setText("\\b(out|print|println|valueOf|toString|concat|equals|for|while|switch|getText");
		
		regex2.setText("|println|printf|print|out|parseInt|round|sqrt|charAt|compareTo|compareToIgnoreCase|concat|contains|contentEquals|equals|length|toLowerCase|trim|toUpperCase|toString|valueOf|substring|startsWith|split|replace|replaceAll|lastIndexOf|size)\\b");
		
		regex3.setText("\\b(public|private|protected|void|switch|case|class|import|package|extends|Activity|TextView|EditText|LinearLayout|CharSequence|String|int|onCreate|ArrayList|float|if|else|static|Intent|Button|SharedPreferences");
		
		regex4.setText("|abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|extends|final|finally|float|for|goto|if|implements|import|instanceof|interface|long|native|new|package|private|protected|");
		
		regex5.setText("public|return|short|static|strictfp|super|switch|synchronized|this|throw|throws|transient|try|void|volatile|while|true|false|null)\\b");
		
		regex6.setText("\\b([0-9]+)\\b");
		
		regex7.setText("(\\w+)(\\()+");
		
		regex8.setText("\\@\\s*(\\w+)");
		
		regex9.setText("\"(.*?)\"|'(.*?)'");
		
		regex10.setText("/\\*(?:.|[\\n\\r])*?\\*/|//.*");
		
		regex11.setText("\\b(Uzuakoli|Amoji|Bright|Ndudirim|Ezinwanne|Lightworker|Isuochi|Abia|Ngodo)\\b");
		_view.addTextChangedListener(new TextWatcher() {
			ColorScheme keywords1 = new ColorScheme(java.util.regex.Pattern.compile(regex1.getText().toString().concat(regex2.getText().toString())), Color.parseColor(secondaryColor));
			
			ColorScheme keywords2 = new ColorScheme(java.util.regex.Pattern.compile(regex3.getText().toString().concat(regex4.getText().toString().concat(regex5.getText().toString()))), Color.parseColor(primaryColor));
			
			ColorScheme keywords3 = new ColorScheme(java.util.regex.Pattern.compile(regex6.getText().toString()), Color.parseColor(numbersColor));
			
			ColorScheme keywords4 = new ColorScheme(java.util.regex.Pattern.compile(regex7.getText().toString()), Color.parseColor(secondaryColor));
			
			ColorScheme keywords5 = new ColorScheme(java.util.regex.Pattern.compile(regex9.getText().toString()), Color.parseColor(quotesColor));
			
			ColorScheme keywords6 = new ColorScheme(java.util.regex.Pattern.compile(regex10.getText().toString()), Color.parseColor(commentsColor));
			
			ColorScheme keywords7 = new ColorScheme(java.util.regex.Pattern.compile(regex8.getText().toString()), Color.parseColor(numbersColor));
			
			
			ColorScheme keywords8 = new ColorScheme(java.util.regex.Pattern.compile(regex11.getText().toString()), Color.parseColor(charColor));
			
			final ColorScheme[] schemes = {keywords1, keywords2, keywords3, keywords4, keywords5, keywords6, keywords7, keywords8}; @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { } @Override public void onTextChanged(CharSequence s, int start, int before, int count) { } @Override public void afterTextChanged(Editable s) { removeSpans(s, android.text.style.ForegroundColorSpan.class); for(ColorScheme scheme : schemes) { for(java.util.regex.Matcher m = scheme.pattern.matcher(s);
					
					m.find();) { if (scheme == keywords4) { s.setSpan(new android.text.style.ForegroundColorSpan(scheme.color), m.start(), m.end()-1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
						} 
						else { s.setSpan(new android.text.style.ForegroundColorSpan(scheme.color), m.start(), m.end(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); } } } } void removeSpans(Editable e, Class type) { android.text.style.CharacterStyle[] spans = e.getSpans(0, e.length(), type); for (android.text.style.CharacterStyle span : spans) { e.removeSpan(span); } } class ColorScheme { final java.util.regex.Pattern pattern; final int color; ColorScheme(java.util.regex.Pattern pattern, int color) { this.pattern = pattern; this.color = color; } } });
	}
	
	
	public void _Ripple_Drawable(final View _view, final String _c) {
		android.content.res.ColorStateList clr = new android.content.res.ColorStateList(new int[][]{new int[]{}},new int[]{Color.parseColor(_c)}); android.graphics.drawable.RippleDrawable ripdr = new android.graphics.drawable.RippleDrawable(clr, null, null); _view.setBackground(ripdr);
	}
	
	
	public void _Languags() {
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("Languag", "None");
			Languag_list.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("Languag", "Java");
			Languag_list.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("Languag", "JScript");
			Languag_list.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("Languag", "C++");
			Languag_list.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("Languag", "C");
			Languag_list.add(_item);
		}
		
		spinner1.setAdapter(new Spinner1Adapter(Languag_list));
	}
	
	
	public void _library() {
	}
	private String readFileFromAsset(String fileName){
		
		
		        BufferedReader reader = null;
		        InputStream inputStream = null;
		        StringBuilder builder = new StringBuilder();
		
		        try{
			            inputStream = getAssets().open(fileName);
			            reader = new BufferedReader(new InputStreamReader(inputStream));
			
			            String line;
			
			            while((line = reader.readLine()) != null)
			            {
				                builder.append(line);
				                builder.append("\n");
				            }
			        } catch (IOException ioe){
			            ioe.printStackTrace();
			        } finally {
			
			            if(inputStream != null)
			            {
				                try {
					                    inputStream.close();
					                } catch (IOException ioe){
					                    ioe.printStackTrace();
					                }
				            }
			
			            if(reader != null)
			            {
				                try {
					                    reader.close();
					                } catch (IOException ioe)
				                {
					                    ioe.printStackTrace();
					                }
				            }
			        }
		        return builder.toString();
		    }
	{
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				}
				else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					}
					else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _CustomDialogMaterial(final AlertDialog.Builder _dial, final boolean _booleann) {
		
		setTheme(android.R.style.Theme_Material);
		_dial.setCancelable(_booleann);
		AlertDialog alert = _dial.show();
		alert.getWindow().getDecorView().setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, Color.parseColor("#252525")));
			alert.getWindow().getDecorView().setPadding(8,8,8,8);
		alert.show();
		
		alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#ff0000"));
			alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#ff0000"));
			alert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.parseColor("#ff0000"));
		alert.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
		alert.getWindow().getDecorView().setTranslationY(-20);
	}
	
	
	public void _createSnackBar(final String _message) {
		ViewGroup parentLayout = (ViewGroup) ((ViewGroup) this .findViewById(android.R.id.content)).getChildAt(0);
		   com.google.android.material.snackbar.Snackbar.make(parentLayout, _message, com.google.android.material.snackbar.Snackbar.LENGTH_LONG) 
		        .setAction("OK", new View.OnClickListener() {
			            @Override 
			            public void onClick(View view) {
				
				            } 
			        }).show();
	}
	
	
	public void _without_dismiss(final String _text) {
		com.google.android.material.snackbar.Snackbar sb = com.google.android.material.snackbar.Snackbar.make(editor, _text, com.google.android.material.snackbar.Snackbar.LENGTH_LONG).setDuration(800);
		
		sb.show();
	}
	
	
	public void _reverse() {
		try{
			if (editor.getText().toString().equals("")) {
				SketchwareUtil.showMessage(getApplicationContext(), "Content is empty!");
			}
			else {
				list.clear();
				l = editor.getText().toString().length();
				if (editor.getText().toString().substring((int)(l - 1), (int)(l)).equals(" ")) {
					hx = editor.getText().toString();
				}
				else {
					hx = editor.getText().toString().concat(" ");
				}
				nm = 0;
				pis = 1;
				for(int _repeat33 = 0; _repeat33 < (int)(hx.length()); _repeat33++) {
					if (hx.substring((int)(nm), (int)(pis)).contains(" ")) {
						list.add(hx.substring((int)(nm), (int)(pis)).replace(" ", ""));
						nm = pis;
						pis++;
					}
					else {
						pis++;
					}
				}
				Collections.reverse(list);
				number = 0;
				text = "";
				for(int _repeat56 = 0; _repeat56 < (int)(list.size()); _repeat56++) {
					if (number == (list.size() - 1)) {
						if (number == 0) {
							text = text.concat(list.get((int)(number)));
						}
						else {
							text = text.concat(" ".concat(list.get((int)(number))));
						}
					}
					else {
						text = text.concat(" ".concat(list.get((int)(number))));
					}
					number = number + 1;
				}
				editor.setText(text);
			}
		}catch(Exception e){
			SketchwareUtil.showMessage(getApplicationContext(), e.toString());
		}
	}
	
	
	public void _blurTextView(final TextView _textview, final boolean _active) {
		//Code by X-Droid - This block is created by InfLps
		
		if (_active) {
				if (Build.VERSION.SDK_INT >= 11) {
						     _textview.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
				}
				float radius = _textview.getTextSize() / 3;
				BlurMaskFilter filter = new BlurMaskFilter(radius, BlurMaskFilter.Blur.NORMAL);
				_textview.getPaint().setMaskFilter(filter);
		}
		else {
				if (Build.VERSION.SDK_INT >= 11) {
						     _textview.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
				}
				float radius = _textview.getTextSize() / 1000;
				BlurMaskFilter filter = new BlurMaskFilter(radius, BlurMaskFilter.Blur.NORMAL);
				_textview.getPaint().setMaskFilter(filter);
		}
	}
	
	
	public void _set_Notification(final String _Title, final String _Message) {
		/*
Developer :- mohammed atta channel
Powered by :- Gopal
*/
		
		final Context context = getApplicationContext();
		
		
		NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
		
		Intent intent = new Intent(this, EditorActivity.class); 
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP); 
		PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0); 
		androidx.core.app.NotificationCompat.Builder builder; 
		
		    int notificationId = 1;
		    String channelId = "channel-01";
		    String channelName = "Successful save";
		    int importance = NotificationManager.IMPORTANCE_HIGH;
		
		    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
			        NotificationChannel mChannel = new NotificationChannel(
			                channelId, channelName, importance);
			        notificationManager.createNotificationChannel(mChannel);
			    }
		
		  
		 androidx.core.app.NotificationCompat.Builder mBuilder = new androidx.core.app.NotificationCompat.Builder(context, channelId)
		            .setSmallIcon(R.drawable.app_logo_transparent)
		            .setContentTitle(_Title)
		            .setContentText(_Message)
		            .setAutoCancel(true)
		            .setOngoing(false)
		            .setContentIntent(pendingIntent);
		    TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
		    stackBuilder.addNextIntent(intent);
		    PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(
		            0,
		            PendingIntent.FLAG_UPDATE_CURRENT
		    );
		    mBuilder.setContentIntent(resultPendingIntent);
		
		    notificationManager.notify(notificationId, mBuilder.build());
		
	}
	
	
	public void _set_erNotification(final String _Title, final String _Message) {
		/*
Developer :- mohammed atta channel
Powered by :- Gopal
*/
		
		final Context context = getApplicationContext();
		
		
		NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
		
		Intent intent = new Intent(this, EditorActivity.class); 
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP); 
		PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0); 
		androidx.core.app.NotificationCompat.Builder builder; 
		
		    int notificationId = 1;
		    String channelId = "channel-01";
		    String channelName = "Error save";
		    int importance = NotificationManager.IMPORTANCE_HIGH;
		
		    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
			        NotificationChannel mChannel = new NotificationChannel(
			                channelId, channelName, importance);
			        notificationManager.createNotificationChannel(mChannel);
			    }
		
		  
		 androidx.core.app.NotificationCompat.Builder mBuilder = new androidx.core.app.NotificationCompat.Builder(context, channelId)
		            .setSmallIcon(R.drawable.ic_error_white)
		            .setContentTitle(_Title)
		            .setContentText(_Message)
		            .setAutoCancel(true)
		            .setOngoing(false)
		            .setContentIntent(pendingIntent);
		    TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
		    stackBuilder.addNextIntent(intent);
		    PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(
		            0,
		            PendingIntent.FLAG_UPDATE_CURRENT
		    );
		    mBuilder.setContentIntent(resultPendingIntent);
		
		    notificationManager.notify(notificationId, mBuilder.build());
		
	}
	
	
	public void _ui() {
		
	}
	
	public class Spinner1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Spinner1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.languages, null);
			}
			
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			textview1.setText(_data.get((int)_position).get("Languag").toString());
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_sans.ttf"), 0);
			
			return _view;
		}
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.history, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView id = _view.findViewById(R.id.id);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			id.setText(String.valueOf((long)(_position)));
			textview2.setText(_data.get((int)_position).get("text").toString());
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}