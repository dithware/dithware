package com.inflps.codexyz;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class BatteryInfoActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private String d = "";
	private double b = 0;
	private String c = "";
	private double a = 0;
	private String m = "";
	private double v = 0;
	private String e = "";
	private String n = "";
	private double u = 0;
	private double z = 0;
	private double y = 0;
	
	private LinearLayout linear8;
	private LinearLayout bg;
	private TextView textview1;
	private TextView textview13;
	private ScrollView vscroll2;
	private LinearLayout linear3;
	private LinearLayout linear1;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private TextView textview6;
	private TextView b_level;
	private ProgressBar batteryLevel;
	private TextView textview8;
	private TextView b_status;
	private TextView textview10;
	private TextView b_temperature;
	private ProgressBar batteryTemperature;
	private TextView textview12;
	private TextView b_health;
	private Button button1;
	
	private TimerTask t;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.battery_info);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear8 = findViewById(R.id.linear8);
		bg = findViewById(R.id.bg);
		textview1 = findViewById(R.id.textview1);
		textview13 = findViewById(R.id.textview13);
		vscroll2 = findViewById(R.id.vscroll2);
		linear3 = findViewById(R.id.linear3);
		linear1 = findViewById(R.id.linear1);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		textview6 = findViewById(R.id.textview6);
		b_level = findViewById(R.id.b_level);
		batteryLevel = findViewById(R.id.batteryLevel);
		textview8 = findViewById(R.id.textview8);
		b_status = findViewById(R.id.b_status);
		textview10 = findViewById(R.id.textview10);
		b_temperature = findViewById(R.id.b_temperature);
		batteryTemperature = findViewById(R.id.batteryTemperature);
		textview12 = findViewById(R.id.textview12);
		b_health = findViewById(R.id.b_health);
		button1 = findViewById(R.id.button1);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
	}
	
	private void initializeLogic() {
		_dialogTheme();
		_initSlideActivity();
		_AdvancedBatteryV1(b_status, b_health, b_temperature, b_level);
		bg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFF262626));
		textview13.setVisibility(View.GONE);
		
		vscroll2.setVerticalScrollBarEnabled(false);
		
		vscroll2.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
		
	}
	
	@Override
	public void onStart() {
		super.onStart();
		try{
			t = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							_AdvancedBatteryV1(b_status, b_health, b_temperature, b_level);
							_more();
							batteryLevel.setProgress((int)v);
							batteryTemperature.setProgress((int)u);
						}
					});
				}
			};
			_timer.scheduleAtFixedRate(t, (int)(1000), (int)(1000));
		}catch(Exception e){
			SketchwareUtil.showMessage(getApplicationContext(), "Processing error");
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		textview13.setVisibility(View.VISIBLE);
		_AdvancedBatteryV1(b_status, b_health, b_temperature, b_level);
	}
	public void _dialogTheme() {
	}
	// setTheme() should be set before setContentView() so a small hack to do this in sketchware
	 @Override 
	    public void setContentView( int layoutResID) {
		if(getIntent().getBooleanExtra("dialogTheme",true)){
			supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
			setTheme(R.style.Theme_AppCompat_Light_Dialog);
			setFinishOnTouchOutside(false);
			
			//change true to false if you want to make dialog non cancellable when clicked outside
			//if you want to use this without app compat  change supportRequestWindowFeature() and setTheme() to below codes.
			/*
requestWindowFeature(Window.FEATURE_NO_TITLE);
setTheme(android.R.style.Theme_Dialog);
*/
			// Calling this allows the Activity behind this one to be seen again. Once all such Activities have been redrawn
			try {
				 	java.lang.reflect.Method getActivityOptions = Activity.class.getDeclaredMethod("getActivityOptions"); getActivityOptions.setAccessible(true);
				 Object options = getActivityOptions.invoke(this); Class<?>[] classes = Activity.class.getDeclaredClasses(); Class<?> translucentConversionListenerClazz = null; 
				for (Class clazz : classes) { if (clazz.getSimpleName().contains("TranslucentConversionListener")) { translucentConversionListenerClazz = clazz; } } 
				java.lang.reflect.Method convertToTranslucent = Activity.class.getDeclaredMethod("convertToTranslucent", translucentConversionListenerClazz, ActivityOptions.class); convertToTranslucent.setAccessible(true); convertToTranslucent.invoke(this, null, options); } catch (Throwable t) {
			}
		}
		super.setContentView(layoutResID);  
	}
	{
	}
	
	
	public void _initSlideActivity() {
		getWindow().getDecorView().setBackgroundResource(android.R.color.transparent);
		ViewConfiguration vc = ViewConfiguration.get(this);
		MIN_DISTANCE = vc.getScaledTouchSlop();
		
		rootView =(ViewGroup)getWindow().findViewById(Window.ID_ANDROID_CONTENT);
		//converts percent to 0-225 range .
		maxAlpha =(int) ((225.0d/100.0d)* MAX_SCRIM_ALPHA); 
		try{
			convertFromTranslucent = Activity.class.getDeclaredMethod("convertFromTranslucent");         convertFromTranslucent.setAccessible(true);
			java.lang.reflect.Method getActivityOptions = Activity.class.getDeclaredMethod("getActivityOptions"); 	getActivityOptions.setAccessible(true);
			options = getActivityOptions.invoke(this);
				Class<?>[] classes = Activity.class.getDeclaredClasses();
			 Class<?> translucentConversionListenerClazz = null;
				for (Class clazz : classes) {
						if (clazz.getSimpleName().contains("TranslucentConversionListener")) {
								translucentConversionListenerClazz = clazz; 
						} 
				} 
				 convertToTranslucent = Activity.class.getDeclaredMethod("convertToTranslucent", translucentConversionListenerClazz, ActivityOptions.class);
				convertToTranslucent.setAccessible(true);
		} catch (Exception e) {
			showMessage(e.toString());
			 }
	}
	// Custom Variables
	//You can change it to color of your choice 
	private static final int SCRIM_COLOR = 0xFF000000;
	//Alpha is not taken into consideration while calculating scrim color  so it dosent matter .
	
	private static final int  SCRIM_R = Color.red(SCRIM_COLOR);
	private static final int SCRIM_G = Color.green(SCRIM_COLOR);
	private static final int  SCRIM_B = Color.blue(SCRIM_COLOR);
	private static final int MAX_SCRIM_ALPHA= 80;
	//in percentage
	private ViewGroup rootView ;
	private boolean enableSwipe= false;
	private boolean lockSwipe = false;
	private float downX;
	private float downY;
	private float MIN_DISTANCE ;
	private int maxAlpha;
	private java.lang.reflect.Method convertFromTranslucent;
	private java.lang.reflect.Method getActivityOptions;
	
	private Object options;
	
	private java.lang.reflect.Method convertToTranslucent;
	// Detect touch Events
	 @Override public boolean dispatchTouchEvent(MotionEvent event) { 
		switch(event.getAction()) { 
			case MotionEvent.ACTION_DOWN: 
			downX = event.getRawX();
			downY =event.getRawY();
			enableSwipe = false;
			lockSwipe = false;
			//convert activity to transparent
			try {
					convertToTranslucent.invoke(this, null, options); 
			} catch (Throwable t) {
			}
			break; 
			case MotionEvent.ACTION_MOVE: 
			if (!lockSwipe){
				if(enableSwipe){
					float translation = event.getRawX() -downX - MIN_DISTANCE;
					if (translation >= rootView.getWidth() || translation<= 0){
						rootView.setTranslationX(0);
					}else{
						rootView.setTranslationX(translation);
						//calculate distance scrolled in percentage
						int distanceInPercentage =(int)( ((double)translation/(double)rootView.getWidth())*100);
						
						//calculate alpha from distance in range 0 - maxAlpha
						
						int alpha =(int) ( ((double)maxAlpha/100.0d)*distanceInPercentage);
						
						//alpha will be greater when it is scrolled more this we do not need this but we need the inverse of it so subtract it from maxAlpha
						alpha = maxAlpha - alpha;
						
						int scrimColor = Color.argb(alpha,SCRIM_R,SCRIM_G,SCRIM_B);
						
						getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(scrimColor));
					}
				}else{
					if(Math.abs(event.getRawY() - downY) >= MIN_DISTANCE){
						enableSwipe = false;
						lockSwipe = true;
					}else{
						enableSwipe = event.getRawX() -downX >= MIN_DISTANCE;
					}
				}
			}
			break; 
			case MotionEvent.ACTION_UP: 
			if(rootView.getTranslationX() > rootView.getWidth() / 5){
				rootView.animate() 
				.translationX(rootView.getWidth())
				.setListener(
				new AnimatorListenerAdapter() { 
							@Override public void onAnimationEnd(Animator animation) { 
						
							super.onAnimationEnd(animation);
						finish();
						overridePendingTransition(0, 0);
						
					} });
			}else{
				rootView.animate() 
				.translationX(0)
				.setListener(
				new AnimatorListenerAdapter() { 
							@Override public void onAnimationEnd(Animator animation) { 
						super.onAnimationEnd(animation);
						// convert activity back to normal
						try {
							 convertFromTranslucent.invoke(this);
							        } catch (Throwable t) {}
					} });
				enableSwipe =false;
				lockSwipe = false;
			}
			break; 
			default:
			enableSwipe =false;
			lockSwipe = false;
			break; 
		}
		if (enableSwipe){
			event.setAction(MotionEvent.ACTION_CANCEL);
		}
		return super.dispatchTouchEvent(event);
	}
	
	{
	}
	
	
	public void _AdvancedBatteryV1(final TextView _statusx, final TextView _bhealth, final TextView _btemp, final TextView _blevel) {
		BatteryManager blevelq = (BatteryManager)getSystemService(BATTERY_SERVICE);
		int blevelw = blevelq.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);//xenondry
		String blevele = Integer.toString(blevelw);
		_blevel.setText(blevele.concat("%"));
		BroadcastReceiver btempz = new BroadcastReceiver() {
				@Override
				public void onReceive(Context context, Intent intent) {
						float btempy = (float)(intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0))/10;
						_btemp.setText(btempy +" "+ (char) 0x00B0 +"C");
				}
		};
		IntentFilter btempx = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		getApplicationContext().registerReceiver(btempz,btempx);
		
		
		BroadcastReceiver healthbb = new BroadcastReceiver() {
				@Override
				public void onReceive(Context context, Intent intent) {
						int healthbc = intent.getIntExtra(BatteryManager.EXTRA_HEALTH,0);
						if (healthbc == BatteryManager.BATTERY_HEALTH_DEAD) {
								_bhealth.setText("Battery is dead");
						}
						if (healthbc == BatteryManager.BATTERY_HEALTH_GOOD) {
								_bhealth.setText("Battery is good");
						}
						if (healthbc == BatteryManager.BATTERY_HEALTH_OVERHEAT) {
								_bhealth.setText("Battery is overheat");
						}//xenondry
						if (healthbc == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE) {
								_bhealth.setText("Battery is over voltage");
						}
						if (healthbc == BatteryManager.BATTERY_HEALTH_UNKNOWN) {
								_bhealth.setText("Unknown battery health");
						}
						if (healthbc == BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE) {
								_bhealth.setText("Unspecified failure battery");
						}
				}
		};
		IntentFilter healthba = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		getApplicationContext().registerReceiver(healthbb,healthba);
		IntentFilter btstatus = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		
		Intent batteryStatus = registerReceiver(null, btstatus);
		
		int chargePlug = batteryStatus.getIntExtra(BatteryManager.EXTRA_PLUGGED,-1);
		
		boolean usbCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_USB;
		
		boolean acCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_AC;
		
		if(usbCharge){
			
			_statusx.setText("Device charging through USB");
			
		} else if(acCharge) {
			
			_statusx.setText("Device charging through AC" );
			
		} else {
			
			_statusx.setText("Device not charging");
			
		}
		
		
	}
	
	
	public void _more() {
		d = "0123456789";
		b = 0;
		c = b_level.getText().toString().trim();
		a = 0;
		m = "";
		for(int _repeat17 = 0; _repeat17 < (int)(c.length()); _repeat17++) {
			for(int _repeat20 = 0; _repeat20 < (int)(10); _repeat20++) {
				if (c.substring((int)(a), (int)(a + 1)).equals(d.substring((int)(b), (int)(b + 1)))) {
					m = m.concat(c.substring((int)(a), (int)(a + 1)));
					if (b == 9) {
						b = 0;
					}
					else {
						b++;
					}
				}
				else {
					if (b == 9) {
						b = 0;
					}
					else {
						b++;
					}
				}
			}
			a++;
		}
		v = Double.parseDouble(m);
		//
		d = "0123456789";
		y = 0;
		e = b_temperature.getText().toString().trim();
		z = 0;
		n = "";
		for(int _repeat74 = 0; _repeat74 < (int)(e.length()); _repeat74++) {
			for(int _repeat77 = 0; _repeat77 < (int)(10); _repeat77++) {
				if (e.substring((int)(z), (int)(z + 1)).equals(d.substring((int)(y), (int)(y + 1)))) {
					n = n.concat(e.substring((int)(z), (int)(z + 1)));
					if (y == 9) {
						y = 0;
					}
					else {
						y++;
					}
				}
				else {
					if (y == 9) {
						y = 0;
					}
					else {
						y++;
					}
				}
			}
			z++;
		}
		u = Double.parseDouble(n);
		//
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}