package com.inflps.codexyz;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class ImagePreviewActivity extends AppCompatActivity {
	
	private LinearLayout linear1;
	private LinearLayout linear3;
	private ImageView imageview88;
	private TextView textview7;
	private ImageView imageview89;
	private ScrollView vscroll1;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear5;
	private ImageView imageview2;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.image_preview);
		initialize(_savedInstanceState);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear3 = findViewById(R.id.linear3);
		imageview88 = findViewById(R.id.imageview88);
		textview7 = findViewById(R.id.textview7);
		imageview89 = findViewById(R.id.imageview89);
		vscroll1 = findViewById(R.id.vscroll1);
		hscroll1 = findViewById(R.id.hscroll1);
		linear5 = findViewById(R.id.linear5);
		imageview2 = findViewById(R.id.imageview2);
		
		imageview88.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		imageview89.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_SaveLinear(imageview2, FileUtil.getExternalStorageDir().concat("/".concat("Download/".concat("ICON_".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(1000000000), (int)(9999999999d)))).concat(".png"))))));
				SketchwareUtil.showMessage(getApplicationContext(), "Saved in .../Download/");
			}
		});
	}
	
	private void initializeLogic() {
		imageview2.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(getIntent().getStringExtra("icon"), 1024, 1024));
	}
	
	public void _SaveLinear(final View _view, final String _path) {
		Bitmap image = Bitmap.createBitmap(_view.getWidth(), _view.getHeight(), Bitmap.Config.ARGB_8888);
		
		Canvas canvas = new Canvas(image);
		android.graphics.drawable.Drawable bgDrawable = _view.getBackground();
		if (bgDrawable!=null) {
			bgDrawable.draw(canvas);
		} else{
			canvas.drawColor(Color.TRANSPARENT);
		};
		
		_view.draw(canvas);
		
		
		java.io.File pictureFile = new java.io.File(_path);
		
		
		
		
		if (pictureFile == null) {
			showMessage("Error creating media file, check storage permissions");
			
			return;
			
		};
		
		try {
			
			java.io.FileOutputStream fos = new java.io.FileOutputStream(pictureFile); 
			image.compress(Bitmap.CompressFormat.PNG, 100, fos);
			fos.close();
			
		} catch (java.io.FileNotFoundException e) {
			
			showMessage("File not found");
			
		} catch (java.io.IOException e) {
			
			showMessage("Error accessing file");
			
		};
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}