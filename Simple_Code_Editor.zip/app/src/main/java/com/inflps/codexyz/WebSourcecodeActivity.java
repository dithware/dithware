package com.inflps.codexyz;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class WebSourcecodeActivity extends AppCompatActivity {
	
	private LinearLayout linear1;
	private LinearLayout linear4;
	private ImageView imageview1;
	private TextView textview2;
	private ImageView imageview3;
	private LinearLayout linear5;
	private LinearLayout linear15;
	private LinearLayout linear8;
	private LinearLayout linear13;
	private LinearLayout linear6;
	private HorizontalScrollView hscroll1;
	private HorizontalScrollView hscroll3;
	private TextView textview31;
	private EditText edittext1;
	private TextView textview22;
	private TextView textview34;
	private Switch switch1;
	private TextView textview33;
	private TextView textview23;
	private ImageView imageview4;
	private ScrollView vscroll1;
	private LinearLayout linear7;
	private TextView textview24;
	private LinearLayout linear10;
	private TextView textview26;
	private TextView textview25;
	private LinearLayout linear14;
	private TextView textview29;
	private TextView textview30;
	
	private RequestNetwork sc;
	private RequestNetwork.RequestListener _sc_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.web_sourcecode);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear4 = findViewById(R.id.linear4);
		imageview1 = findViewById(R.id.imageview1);
		textview2 = findViewById(R.id.textview2);
		imageview3 = findViewById(R.id.imageview3);
		linear5 = findViewById(R.id.linear5);
		linear15 = findViewById(R.id.linear15);
		linear8 = findViewById(R.id.linear8);
		linear13 = findViewById(R.id.linear13);
		linear6 = findViewById(R.id.linear6);
		hscroll1 = findViewById(R.id.hscroll1);
		hscroll3 = findViewById(R.id.hscroll3);
		textview31 = findViewById(R.id.textview31);
		edittext1 = findViewById(R.id.edittext1);
		textview22 = findViewById(R.id.textview22);
		textview34 = findViewById(R.id.textview34);
		switch1 = findViewById(R.id.switch1);
		textview33 = findViewById(R.id.textview33);
		textview23 = findViewById(R.id.textview23);
		imageview4 = findViewById(R.id.imageview4);
		vscroll1 = findViewById(R.id.vscroll1);
		linear7 = findViewById(R.id.linear7);
		textview24 = findViewById(R.id.textview24);
		linear10 = findViewById(R.id.linear10);
		textview26 = findViewById(R.id.textview26);
		textview25 = findViewById(R.id.textview25);
		linear14 = findViewById(R.id.linear14);
		textview29 = findViewById(R.id.textview29);
		textview30 = findViewById(R.id.textview30);
		sc = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		textview22.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().contains("https://www.") || edittext1.getText().toString().contains("http://www.")) {
					sc.startRequestNetwork(RequestNetworkController.GET, edittext1.getText().toString(), "Result", _sc_request_listener);
				}
				else {
					if (switch1.isChecked()) {
						sc.startRequestNetwork(RequestNetworkController.GET, "https://www.".concat(edittext1.getText().toString()), "Result", _sc_request_listener);
					}
					else {
						sc.startRequestNetwork(RequestNetworkController.GET, "http://www.".concat(edittext1.getText().toString()), "Result", _sc_request_listener);
					}
				}
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview24.getText().toString()));
				SketchwareUtil.showMessage(getApplicationContext(), "Copied to clipboard.");
			}
		});
		
		_sc_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				textview24.setText(_response);
				textview25.setText(_tag);
				textview30.setText("");
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				textview25.setText(_tag);
				textview30.setText(_message);
				textview24.setText("");
			}
		};
	}
	
	private void initializeLogic() {
		textview24.setTextIsSelectable(true);
		textview24.setTypeface(Typeface.MONOSPACE);
		textview25.setTypeface(Typeface.MONOSPACE);
		textview30.setTypeface(Typeface.MONOSPACE);
		textview24.addTextChangedListener(new TextWatcher() {
				
				  ColorScheme keywords = new ColorScheme(
				      Pattern.compile(
				          "\\b(transient|Activity|View|Log|MotionEvent|void|const|static|volatile|interface|native|protected|final|abstract|synchronized|enum|instanceof|assert|break|goto|return|new|throw|throws|super|extends|implements|import)\\b"),
				      Color.parseColor("#FFD84315") //brown
				  );
				
				ColorScheme keywordskeywords = new ColorScheme(
				      Pattern.compile(
				          "\\b(class|private|public|this|0|arg|args|out)\\b"),
				      Color.parseColor("#FFFF1744") //rose
				  );
				
				ColorScheme keywords2 = new ColorScheme(
				      Pattern.compile(
				          "\\b(package|strictfp|char|short|int|long|double|String|float|byte|boolean|default|do|continue)\\b"),
				      Color.parseColor("#FF4DB6AC") 
				  );
				
				ColorScheme keywords3 = new ColorScheme(
				      Pattern.compile(
				          "\\b(if|else|switch|case|for|while)\\b"),
				      Color.parseColor("#FFD500F9") //mauve
				  );
				
				ColorScheme keywords4 = new ColorScheme(
				      Pattern.compile(
				          "\\b(try|catch|finally|true|false|null|IOException|java.io.IOException)\\b"),
				      Color.parseColor("#FFFFC400") // jaune foncé
				  );
				
				ColorScheme keywords5 = new ColorScheme(
				      Pattern.compile(
				          "\\b(BroadcastReceiver|Intent|Integer|CharSequence|Dialog|OnFocusChangeListener|OnCreateContextMenuListener|OnKeyListener|WifiManager|StringBuffer|StringBuilder|OnClickListener|OnTouchListener|OnLongClickListener|OnCheckedChanged|addTextChangedListener|Color.parseColor|color|colors|parseColor|Color|ColorScheme|ProcessBuilder|Process|PackageManager|)\\b"),
				      Color.parseColor("#FF2196F3") //Blue
				  );
				
				ColorScheme keywords6 = new ColorScheme(
				      Pattern.compile(
				          "\\b(LinearLayout|LinearParams|CheckboxGroup|CheckBox|Button|Switch|Spannable|EditText|TextView|ImageView|CircleImageView|RadioButton|TabLayout|SwipRefreshLayout)\\b"),
				      Color.parseColor("#FFC0CA33") //Lime foncé
				  );
				
				ColorScheme newtypes = new ColorScheme(
				      Pattern.compile(
				          "\\b(onTextChanged|isSelected|isChecked|CheckBox|Button|Switch|Spannable|EditText|TextView|ImageView|CircleImageView|RadioButton|TabLayout|SwipRefreshLayout)\\b"),
				      Color.parseColor("#76ff03") //green claire
				  );
				
				ColorScheme keywords7 = new ColorScheme(    
				      Pattern.compile(
				          "\\b(java.io.|BufferedReader|InputStream|BufferedWriter|InputStreamReader|File|FileReader|java.io.BufferedReader|setElevation|setBackground|setStroke|setCornerRadii|java.io.InputStream|android.graphics.drawable.GradientDrawable|android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM|java.io.BufferedWriter|java.io.InputStreamReader|java.io.File|java.io.FileReader)\\b"),
				      Color.parseColor("#FFBA68C8") 
				  );
				
				
				  final ColorScheme[] schemes = {newtypes, keywordskeywords , keywords4, keywords3, keywords2, keywords, keywords5, keywords6, keywords7 };
				
				  @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {
						
						  }
				
				  @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
						
						  }
				
				  @Override public void afterTextChanged(Editable s) {
						    removeSpans(s, ForegroundColorSpan.class);
						    for (ColorScheme scheme : schemes) {
								      for(Matcher m = scheme.pattern.matcher(s); m.find();) {
										        s.setSpan(new ForegroundColorSpan(scheme.color),
										            m.start(),
										            m.end(),
										            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
										      }
								    }
						  }
				
				  void removeSpans(Editable e, Class<? extends CharacterStyle> type) {
						    CharacterStyle[] spans = e.getSpans(0, e.length(), type);
						    for (CharacterStyle span : spans) {
								      e.removeSpan(span);
								    }
						  }
				
				  class ColorScheme {
						    final Pattern pattern;
						    final int color;
						
						     ColorScheme(Pattern pattern, int color) {
								      this.pattern = pattern;
								      this.color = color;
								    }
						  }
				
		});
		
		android.graphics.drawable.GradientDrawable HHHBDCG = new android.graphics.drawable.GradientDrawable();HHHBDCG.setColor(Color.argb(255,0,0,0));
		HHHBDCG.setCornerRadii(new float[] { 0, 0, 0, 0, 50, 50, 50, 50 });
		linear6.setBackground(HHHBDCG);
		android.graphics.drawable.GradientDrawable CDBIIBD = new android.graphics.drawable.GradientDrawable();CDBIIBD.setColor(Color.argb(255,0,0,0));
		CDBIIBD.setCornerRadii(new float[] { 50, 50, 50, 50, 0, 0, 0, 0 });
		linear13.setBackground(CDBIIBD);
		linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, 0xFF292929));
		linear14.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, 0xFFD50000));
		linear10.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, 0xFF304FFE));
		linear15.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, 0xFF292929));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}