package com.inflps.codexyz;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class HtmlPreviewActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private LinearLayout linear1;
	private ProgressBar progressbar1;
	private WebView webview1;
	private LinearLayout web_menu;
	private ImageView imageview1;
	private LinearLayout linear122;
	private LinearLayout linear3;
	private ImageView imageview4;
	private ImageView imageview89;
	private ImageView imageview5;
	private ImageView imageview6;
	private TextView textview2;
	private LinearLayout linear123;
	private EditText edittext1;
	private ImageView imageview90;
	private LinearLayout linear4;
	private ScrollView vscroll1;
	private LinearLayout linear5;
	private ImageView imageview7;
	private TextView textview22;
	private LinearLayout linear121;
	private LinearLayout linear10;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private TextView textview23;
	private ImageView imageview88;
	private TextView textview25;
	private TextView textview26;
	private LinearLayout linear141;
	private LinearLayout linear9;
	private LinearLayout linear124;
	private Switch switch3;
	private Switch switch6;
	private Switch switch2;
	private Switch switch4;
	private Switch switch5;
	private LinearLayout linear125;
	private Button button2;
	private Button button1;
	private Button button3;
	private Switch switch1;
	private TextView textview27;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear137;
	private LinearLayout linear126;
	private LinearLayout linear128;
	private LinearLayout linear130;
	private LinearLayout linear131;
	private LinearLayout linear133;
	private LinearLayout linear135;
	private LinearLayout linear140;
	private ImageView imageview91;
	private LinearLayout android_bar;
	private ImageView imageview92;
	private LinearLayout ios_bar;
	private ImageView imageview93;
	private LinearLayout windows_bar;
	private ImageView imageview94;
	private LinearLayout macos_bar;
	private ImageView imageview95;
	private LinearLayout linux_bar;
	private ImageView imageview96;
	private LinearLayout dos_bar;
	private ImageView imageview98;
	private LinearLayout solaris_bar;
	
	private SharedPreferences webview;
	private SharedPreferences settings;
	private AlertDialog.Builder alert;
	private TimerTask t;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.html_preview);
		initialize(_savedInstanceState);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		progressbar1 = findViewById(R.id.progressbar1);
		webview1 = findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		web_menu = findViewById(R.id.web_menu);
		imageview1 = findViewById(R.id.imageview1);
		linear122 = findViewById(R.id.linear122);
		linear3 = findViewById(R.id.linear3);
		imageview4 = findViewById(R.id.imageview4);
		imageview89 = findViewById(R.id.imageview89);
		imageview5 = findViewById(R.id.imageview5);
		imageview6 = findViewById(R.id.imageview6);
		textview2 = findViewById(R.id.textview2);
		linear123 = findViewById(R.id.linear123);
		edittext1 = findViewById(R.id.edittext1);
		imageview90 = findViewById(R.id.imageview90);
		linear4 = findViewById(R.id.linear4);
		vscroll1 = findViewById(R.id.vscroll1);
		linear5 = findViewById(R.id.linear5);
		imageview7 = findViewById(R.id.imageview7);
		textview22 = findViewById(R.id.textview22);
		linear121 = findViewById(R.id.linear121);
		linear10 = findViewById(R.id.linear10);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		textview23 = findViewById(R.id.textview23);
		imageview88 = findViewById(R.id.imageview88);
		textview25 = findViewById(R.id.textview25);
		textview26 = findViewById(R.id.textview26);
		linear141 = findViewById(R.id.linear141);
		linear9 = findViewById(R.id.linear9);
		linear124 = findViewById(R.id.linear124);
		switch3 = findViewById(R.id.switch3);
		switch6 = findViewById(R.id.switch6);
		switch2 = findViewById(R.id.switch2);
		switch4 = findViewById(R.id.switch4);
		switch5 = findViewById(R.id.switch5);
		linear125 = findViewById(R.id.linear125);
		button2 = findViewById(R.id.button2);
		button1 = findViewById(R.id.button1);
		button3 = findViewById(R.id.button3);
		switch1 = findViewById(R.id.switch1);
		textview27 = findViewById(R.id.textview27);
		hscroll1 = findViewById(R.id.hscroll1);
		linear137 = findViewById(R.id.linear137);
		linear126 = findViewById(R.id.linear126);
		linear128 = findViewById(R.id.linear128);
		linear130 = findViewById(R.id.linear130);
		linear131 = findViewById(R.id.linear131);
		linear133 = findViewById(R.id.linear133);
		linear135 = findViewById(R.id.linear135);
		linear140 = findViewById(R.id.linear140);
		imageview91 = findViewById(R.id.imageview91);
		android_bar = findViewById(R.id.android_bar);
		imageview92 = findViewById(R.id.imageview92);
		ios_bar = findViewById(R.id.ios_bar);
		imageview93 = findViewById(R.id.imageview93);
		windows_bar = findViewById(R.id.windows_bar);
		imageview94 = findViewById(R.id.imageview94);
		macos_bar = findViewById(R.id.macos_bar);
		imageview95 = findViewById(R.id.imageview95);
		linux_bar = findViewById(R.id.linux_bar);
		imageview96 = findViewById(R.id.imageview96);
		dos_bar = findViewById(R.id.dos_bar);
		imageview98 = findViewById(R.id.imageview98);
		solaris_bar = findViewById(R.id.solaris_bar);
		webview = getSharedPreferences("webview", Activity.MODE_PRIVATE);
		settings = getSharedPreferences("settings", Activity.MODE_PRIVATE);
		alert = new AlertDialog.Builder(this);
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				progressbar1.setProgress((int)webview1.getProgress());
				edittext1.setText(_url);
				progressbar1.setVisibility(View.VISIBLE);
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				progressbar1.setProgress((int)0);
				progressbar1.setVisibility(View.GONE);
				if (getIntent().getStringExtra("name").equals("nohtml")) {
					textview2.setText(webview1.getTitle());
				}
				else {
					textview2.setText("HTML Player ");
				}
				super.onPageFinished(_param1, _param2);
			}
		});
		
		imageview1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				FileUtil.deleteFile("file:///".concat(FileUtil.getExternalStorageDir().concat("/CodeX/Temp/Package/Logs/Bin/HTML/".concat(getIntent().getStringExtra("name")))));
				finish();
				return true;
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (webview1.canGoBack()) {
					webview1.goBack();
				}
				else {
					
				}
			}
		});
		
		imageview89.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.loadUrl(webview1.getUrl());
			}
		});
		
		imageview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (webview1.canGoForward()) {
					webview1.goForward();
				}
				else {
					
				}
			}
		});
		
		imageview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (web_menu.getVisibility() == View.GONE) {
					web_menu.setVisibility(View.VISIBLE);
				}
				else {
					web_menu.setVisibility(View.GONE);
				}
			}
		});
		
		imageview90.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().contains("https://") || edittext1.getText().toString().contains("http://")) {
						webview1.loadUrl(edittext1.getText().toString());
				}
				else {
						webview1.loadUrl("https://www.google.com/search?ie=UTF-8&client=ms-android-samsung&source=android-browser&q=".concat(edittext1.getText().toString()));
				}
			}
		});
		
		imageview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				web_menu.setVisibility(View.GONE);
			}
		});
		
		switch3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					_WebView(switch1.isChecked(), switch2.isChecked(), switch5.isChecked(), true, switch4.isChecked(), webview1);
				}
				else {
					_WebView(switch1.isChecked(), switch2.isChecked(), switch5.isChecked(), false, switch4.isChecked(), webview1);
				}
			}
		});
		
		switch6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					WebSettings webSettings = webview1.getSettings(); 
					webSettings.setJavaScriptEnabled(true); 
					webSettings.setLoadsImagesAutomatically(true);
					
					webview1.loadUrl(webview1.getUrl());
				}
				else {
					WebSettings webSettings = webview1.getSettings(); 
					webSettings.setJavaScriptEnabled(false); 
					webSettings.setLoadsImagesAutomatically(false);
					
					webview1.loadUrl(webview1.getUrl());
				}
			}
		});
		
		switch2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					_WebView(switch1.isChecked(), true, switch5.isChecked(), switch3.isChecked(), switch4.isChecked(), webview1);
				}
				else {
					_WebView(switch1.isChecked(), false, switch5.isChecked(), switch3.isChecked(), switch4.isChecked(), webview1);
				}
			}
		});
		
		switch4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					_WebView(switch1.isChecked(), switch2.isChecked(), switch5.isChecked(), switch3.isChecked(), true, webview1);
				}
				else {
					_WebView(switch1.isChecked(), switch2.isChecked(), switch5.isChecked(), switch3.isChecked(), false, webview1);
				}
			}
		});
		
		switch5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					_WebView(switch1.isChecked(), switch2.isChecked(), true, switch3.isChecked(), switch4.isChecked(), webview1);
				}
				else {
					_WebView(switch1.isChecked(), switch2.isChecked(), false, switch3.isChecked(), switch4.isChecked(), webview1);
				}
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.loadUrl("https://www.google.com");
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.loadUrl("javascript:(function () { var script = document.createElement('script'); script.src=\"//cdn.jsdelivr.net/npm/eruda\"; document.body.appendChild(script); script.onload = function () { eruda.init() } })();");
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.loadUrl("javascript:(function() { \" +\n        \"var head = document.getElementsByClassName('header')[0].style.display='none'; \" +\n        \"})()\")");
			}
		});
		
		switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					_WebView(true, switch2.isChecked(), switch5.isChecked(), switch3.isChecked(), switch4.isChecked(), webview1);
				}
				else {
					_WebView(false, switch2.isChecked(), switch5.isChecked(), switch3.isChecked(), switch4.isChecked(), webview1);
				}
			}
		});
		
		linear126.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				android_bar.setBackgroundColor(0xFFFFC107);
				ios_bar.setBackgroundColor(Color.TRANSPARENT);
				windows_bar.setBackgroundColor(Color.TRANSPARENT);
				macos_bar.setBackgroundColor(Color.TRANSPARENT);
				linux_bar.setBackgroundColor(Color.TRANSPARENT);
				dos_bar.setBackgroundColor(Color.TRANSPARENT);
				solaris_bar.setBackgroundColor(Color.TRANSPARENT);
				webview1.getSettings().setLoadWithOverviewMode(true); webview1.getSettings().setUseWideViewPort(true); final WebSettings webSettings = webview1.getSettings(); 
				final String newUserAgent = "Mozilla/5.0 (Linux; Android 11; en-us; Pixel 4 XL Build/RQ3A.210805.001) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.85 Mobile Safari/537.36";
				webSettings.setUserAgentString(newUserAgent);
				
				webview1.loadUrl(webview1.getUrl());
			}
		});
		
		linear128.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				android_bar.setBackgroundColor(Color.TRANSPARENT);
				ios_bar.setBackgroundColor(0xFFFFC107);
				windows_bar.setBackgroundColor(Color.TRANSPARENT);
				macos_bar.setBackgroundColor(Color.TRANSPARENT);
				linux_bar.setBackgroundColor(Color.TRANSPARENT);
				dos_bar.setBackgroundColor(Color.TRANSPARENT);
				solaris_bar.setBackgroundColor(Color.TRANSPARENT);
				webview1.getSettings().setLoadWithOverviewMode(true); webview1.getSettings().setUseWideViewPort(true); final WebSettings webSettings = webview1.getSettings(); 
				final String newUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1";
				webSettings.setUserAgentString(newUserAgent);
				
				webview1.loadUrl(webview1.getUrl());
			}
		});
		
		linear130.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				android_bar.setBackgroundColor(Color.TRANSPARENT);
				ios_bar.setBackgroundColor(Color.TRANSPARENT);
				windows_bar.setBackgroundColor(0xFFFFC107);
				macos_bar.setBackgroundColor(Color.TRANSPARENT);
				linux_bar.setBackgroundColor(Color.TRANSPARENT);
				dos_bar.setBackgroundColor(Color.TRANSPARENT);
				solaris_bar.setBackgroundColor(Color.TRANSPARENT);
				webview1.getSettings().setLoadWithOverviewMode(true); webview1.getSettings().setUseWideViewPort(true); final WebSettings webSettings = webview1.getSettings(); 
				final String newUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.119 Safari/537.36 Edge/20.0";
				webSettings.setUserAgentString(newUserAgent);
				
				webview1.loadUrl(webview1.getUrl());
			}
		});
		
		linear131.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				android_bar.setBackgroundColor(Color.TRANSPARENT);
				ios_bar.setBackgroundColor(Color.TRANSPARENT);
				windows_bar.setBackgroundColor(Color.TRANSPARENT);
				macos_bar.setBackgroundColor(0xFFFFC107);
				linux_bar.setBackgroundColor(Color.TRANSPARENT);
				dos_bar.setBackgroundColor(Color.TRANSPARENT);
				solaris_bar.setBackgroundColor(Color.TRANSPARENT);
				webview1.getSettings().setLoadWithOverviewMode(true); webview1.getSettings().setUseWideViewPort(true); final WebSettings webSettings = webview1.getSettings(); 
				final String newUserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 12_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1 Safari/605.1.15";
				webSettings.setUserAgentString(newUserAgent);
				
				webview1.loadUrl(webview1.getUrl());
			}
		});
		
		linear133.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				View linuxoschoseV = getLayoutInflater().inflate(R.layout.ostype_linux, null);
				final PopupWindow linuxoschose = new PopupWindow(linuxoschoseV, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
				final ImageView kali = linuxoschoseV.findViewById(R.id.kali);
				final ImageView ubuntu = linuxoschoseV.findViewById(R.id.ubuntu);
				final ImageView mint = linuxoschoseV.findViewById(R.id.mint);
				final ImageView debian = linuxoschoseV.findViewById(R.id.debian);
				final ImageView suse = linuxoschoseV.findViewById(R.id.suse);
				final ImageView unix = linuxoschoseV.findViewById(R.id.unix);
				kali.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						linuxoschose.dismiss();
						linuxoschose.dismiss();
						android_bar.setBackgroundColor(Color.TRANSPARENT);
						ios_bar.setBackgroundColor(Color.TRANSPARENT);
						windows_bar.setBackgroundColor(Color.TRANSPARENT);
						macos_bar.setBackgroundColor(Color.TRANSPARENT);
						linux_bar.setBackgroundColor(0xFFFFC107);
						dos_bar.setBackgroundColor(Color.TRANSPARENT);
						solaris_bar.setBackgroundColor(Color.TRANSPARENT);
						webview1.getSettings().setLoadWithOverviewMode(true); webview1.getSettings().setUseWideViewPort(true); final WebSettings webSettings = webview1.getSettings(); 
						final String newUserAgent = "Mozilla/5.0 (X11; Linux x86_64; rv:94.0) Gecko/20100101 Firefox/94.0";
						webSettings.setUserAgentString(newUserAgent);
						
						webview1.loadUrl(webview1.getUrl());
					}
				});
				ubuntu.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						linuxoschose.dismiss();
						android_bar.setBackgroundColor(Color.TRANSPARENT);
						ios_bar.setBackgroundColor(Color.TRANSPARENT);
						windows_bar.setBackgroundColor(Color.TRANSPARENT);
						macos_bar.setBackgroundColor(Color.TRANSPARENT);
						linux_bar.setBackgroundColor(0xFFFFC107);
						dos_bar.setBackgroundColor(Color.TRANSPARENT);
						solaris_bar.setBackgroundColor(Color.TRANSPARENT);
						webview1.getSettings().setLoadWithOverviewMode(true); webview1.getSettings().setUseWideViewPort(true); final WebSettings webSettings = webview1.getSettings(); 
						final String newUserAgent = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:94.0) Gecko/20100101 Firefox/94.0";
						webSettings.setUserAgentString(newUserAgent);
						
						webview1.loadUrl(webview1.getUrl());
					}
				});
				mint.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						linuxoschose.dismiss();
						android_bar.setBackgroundColor(Color.TRANSPARENT);
						ios_bar.setBackgroundColor(Color.TRANSPARENT);
						windows_bar.setBackgroundColor(Color.TRANSPARENT);
						macos_bar.setBackgroundColor(Color.TRANSPARENT);
						linux_bar.setBackgroundColor(0xFFFFC107);
						dos_bar.setBackgroundColor(Color.TRANSPARENT);
						solaris_bar.setBackgroundColor(Color.TRANSPARENT);
						webview1.getSettings().setLoadWithOverviewMode(true); webview1.getSettings().setUseWideViewPort(true); final WebSettings webSettings = webview1.getSettings(); 
						final String newUserAgent = "Mozilla/5.0 (X11; Linux x86_64; rv:94.0) Gecko/20100101 Firefox/94.0";
						webSettings.setUserAgentString(newUserAgent);
						
						webview1.loadUrl(webview1.getUrl());
					}
				});
				debian.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						linuxoschose.dismiss();
						android_bar.setBackgroundColor(Color.TRANSPARENT);
						ios_bar.setBackgroundColor(Color.TRANSPARENT);
						windows_bar.setBackgroundColor(Color.TRANSPARENT);
						macos_bar.setBackgroundColor(Color.TRANSPARENT);
						linux_bar.setBackgroundColor(0xFFFFC107);
						dos_bar.setBackgroundColor(Color.TRANSPARENT);
						solaris_bar.setBackgroundColor(Color.TRANSPARENT);
						webview1.getSettings().setLoadWithOverviewMode(true); webview1.getSettings().setUseWideViewPort(true); final WebSettings webSettings = webview1.getSettings(); 
						final String newUserAgent = "Mozilla/5.0 (X11; Linux x86_64; rv:94.0) Gecko/20100101 Firefox/94.0";
						webSettings.setUserAgentString(newUserAgent);
						
						webview1.loadUrl(webview1.getUrl());
					}
				});
				suse.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						linuxoschose.dismiss();
						android_bar.setBackgroundColor(Color.TRANSPARENT);
						ios_bar.setBackgroundColor(Color.TRANSPARENT);
						windows_bar.setBackgroundColor(Color.TRANSPARENT);
						macos_bar.setBackgroundColor(Color.TRANSPARENT);
						linux_bar.setBackgroundColor(0xFFFFC107);
						dos_bar.setBackgroundColor(Color.TRANSPARENT);
						solaris_bar.setBackgroundColor(Color.TRANSPARENT);
						webview1.getSettings().setLoadWithOverviewMode(true); webview1.getSettings().setUseWideViewPort(true); final WebSettings webSettings = webview1.getSettings(); 
						final String newUserAgent = "Mozilla/5.0 (X11; Linux x86_64; rv:94.0) Gecko/20100101 Firefox/94.0";
						webSettings.setUserAgentString(newUserAgent);
						
						webview1.loadUrl(webview1.getUrl());
					}
				});
				unix.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						linuxoschose.dismiss();
						android_bar.setBackgroundColor(Color.TRANSPARENT);
						ios_bar.setBackgroundColor(Color.TRANSPARENT);
						windows_bar.setBackgroundColor(Color.TRANSPARENT);
						macos_bar.setBackgroundColor(Color.TRANSPARENT);
						linux_bar.setBackgroundColor(0xFFFFC107);
						dos_bar.setBackgroundColor(Color.TRANSPARENT);
						solaris_bar.setBackgroundColor(Color.TRANSPARENT);
						webview1.getSettings().setLoadWithOverviewMode(true); webview1.getSettings().setUseWideViewPort(true); final WebSettings webSettings = webview1.getSettings(); 
						final String newUserAgent = "Mozilla/5.0 (X11; Unix; Linux x86_64; rv:94.0) Gecko/20100101 Firefox/94.0";
						webSettings.setUserAgentString(newUserAgent);
						
						webview1.loadUrl(webview1.getUrl());
					}
				});
				linuxoschose.setAnimationStyle(android.R.style.Animation_Dialog);
				linuxoschose.showAsDropDown(linear141, 0,0);
				linuxoschose.setBackgroundDrawable(new BitmapDrawable());
			}
		});
		
		linear135.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				android_bar.setBackgroundColor(Color.TRANSPARENT);
				ios_bar.setBackgroundColor(Color.TRANSPARENT);
				windows_bar.setBackgroundColor(Color.TRANSPARENT);
				macos_bar.setBackgroundColor(Color.TRANSPARENT);
				linux_bar.setBackgroundColor(Color.TRANSPARENT);
				dos_bar.setBackgroundColor(0xFFFFC107);
				solaris_bar.setBackgroundColor(Color.TRANSPARENT);
				webview1.getSettings().setLoadWithOverviewMode(true); webview1.getSettings().setUseWideViewPort(true); final WebSettings webSettings = webview1.getSettings(); 
				final String newUserAgent = "Mozilla/5.0 (compatible; MSIE 5.0; Windows 3.1; Trident/4.0)";
				webSettings.setUserAgentString(newUserAgent);
				
				webview1.loadUrl(webview1.getUrl());
			}
		});
		
		linear140.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				android_bar.setBackgroundColor(Color.TRANSPARENT);
				ios_bar.setBackgroundColor(Color.TRANSPARENT);
				windows_bar.setBackgroundColor(Color.TRANSPARENT);
				macos_bar.setBackgroundColor(Color.TRANSPARENT);
				linux_bar.setBackgroundColor(Color.TRANSPARENT);
				dos_bar.setBackgroundColor(Color.TRANSPARENT);
				solaris_bar.setBackgroundColor(0xFFFFC107);
				webview1.getSettings().setLoadWithOverviewMode(true); webview1.getSettings().setUseWideViewPort(true); final WebSettings webSettings = webview1.getSettings(); 
				final String newUserAgent = "Mozilla/5.0 (X11; SunOS i86pc; rv:82.0) Gecko/20100101 Firefox/82.0";
				webSettings.setUserAgentString(newUserAgent);
				
				webview1.loadUrl(webview1.getUrl());
			}
		});
	}
	
	private void initializeLogic() {
		if (getIntent().getStringExtra("name").equals("nohtml")) {
			webview1.loadUrl("https://www.google.com");
			edittext1.setText(webview1.getUrl());
			textview2.setText("Browser ");
		}
		else {
			webview1.loadUrl("file:///".concat(FileUtil.getExternalStorageDir().concat("/CodeXYZ/Temp/Package/Logs/Bin/HTML/".concat(getIntent().getStringExtra("name")))));
			edittext1.setText("file:///".concat(FileUtil.getExternalStorageDir().concat("/CodeXYZ/Temp/Package/Logs/Bin/HTML/".concat(getIntent().getStringExtra("name")))));
			textview2.setText("HTML Player ");
		}
		
		_WebView(true, true, true, true, true, webview1);
		web_menu.setVisibility(View.GONE);
		
		vscroll1.setVerticalScrollBarEnabled(false);
		
		vscroll1.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
		
		
		hscroll1.setHorizontalScrollBarEnabled(false);
		
		hscroll1.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
		
		//v.5.0.1
	}
	
	@Override
	public void onBackPressed() {
		if (web_menu.getVisibility() == View.VISIBLE) {
			web_menu.setVisibility(View.GONE);
		}
		else {
			if (webview1.canGoBack()) {
				webview1.goBack();
			}
			else {
				alert.setTitle("Are you exiting the console?");
				alert.setIcon(R.drawable.help);
				alert.setMessage("This is for accident prevention only");
				alert.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						finish();
					}
				});
				alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				_CustomDialogMaterial(alert, true);
			}
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (settings.getString("beta", "").equals("t")) {
			button1.setVisibility(View.VISIBLE);
			imageview89.setVisibility(View.VISIBLE);
			button2.setVisibility(View.VISIBLE);
			button3.setVisibility(View.VISIBLE);
		}
		else {
			button1.setVisibility(View.GONE);
			imageview89.setVisibility(View.GONE);
			button2.setVisibility(View.GONE);
			button3.setVisibility(View.GONE);
		}
	}
	public void _WebView_Download(final WebView _wview, final String _path) {
		if (FileUtil.isExistFile(_path)) {
			
		}
		else {
			FileUtil.makeDir(_path);
		}
		_wview.setDownloadListener(new DownloadListener() { public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) { DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url)); String cookies = CookieManager.getInstance().getCookie(url); request.addRequestHeader("cookie", cookies); request.addRequestHeader("User-Agent", userAgent); request.setDescription("Downloading file..."); request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype)); request.allowScanningByMediaScanner();//Made by XenonDry request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); java.io.File aatv = new java.io.File(Environment.getExternalStorageDirectory().getPath() + "/XenonDry/Download");if(!aatv.exists()){if (!aatv.mkdirs()){ Log.e("TravellerLog ::","Problem creating Image folder");}} request.setDestinationInExternalPublicDir(_path, URLUtil.guessFileName(url, contentDisposition, mimetype)); 
				
				DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE); manager.enqueue(request); showMessage("Downloading File...."); BroadcastReceiver onComplete = new BroadcastReceiver() { public void onReceive(Context ctxt, Intent intent) { showMessage("Download Complete!"); unregisterReceiver(this); }}; registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)); } }); 
	}
	
	
	public void _WebView(final boolean _js, final boolean _zoom, final boolean _download, final boolean _html, final boolean _cookies, final WebView _view) {
		_view.getSettings().setJavaScriptEnabled(_js); //Made by XenonDry
		CookieManager.getInstance().setAcceptCookie(_cookies);
		WebSettings webSettings = _view.getSettings(); 
		webSettings.setJavaScriptEnabled(_html); 
		webSettings.setJavaScriptCanOpenWindowsAutomatically(_html);
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
			webSettings.setAllowFileAccessFromFileURLs(_html); 
			webSettings.setAllowUniversalAccessFromFileURLs(_html);
		}
		if(_zoom == true){
			_view.getSettings().setBuiltInZoomControls(true);_view.getSettings().setDisplayZoomControls(false);
		}
		else if(_zoom == false){
			_view.getSettings().setBuiltInZoomControls(false);_view.getSettings().setDisplayZoomControls(true);
		}
		if(_download == true){
			
			_WebView_Download(webview1, "/Downloads");
		}
		else if(_download == false){
		}
	}
	
	
	public void _CustomDialogMaterial(final AlertDialog.Builder _dial, final boolean _booleann) {
		
		setTheme(android.R.style.Theme_Material);
		_dial.setCancelable(_booleann);
		AlertDialog alert = _dial.show();
		alert.getWindow().getDecorView().setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, Color.parseColor("#252525")));
			alert.getWindow().getDecorView().setPadding(8,8,8,8);
		alert.show();
		
		alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#ff0000"));
			alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#ff0000"));
			alert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.parseColor("#ff0000"));
		alert.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
		alert.getWindow().getDecorView().setTranslationY(-20);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}