package com.inflps.codexyz;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import com.google.android.material.appbar.AppBarLayout;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class TerminalActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private String out = "";
	private String output = "";
	private String pre_path = "";
	private String pwd = "";
	private String pre = "";
	private String command = "";
	private String terminal_text = "";
	private double num = 0;
	private double size = 0;
	
	private ScrollView vscroll1;
	private LinearLayout zoom_lin;
	private LinearLayout linear2;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private TextView out_text;
	private TextView textview2;
	private EditText terminal;
	private TextView textview5;
	private LinearLayout linear8;
	private TextView textview3;
	private LinearLayout linear7;
	private TextView textview4;
	
	private TimerTask t;
	private TimerTask tt;
	private TimerTask ttt;
	private Intent intent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.terminal);
		initialize(_savedInstanceState);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = findViewById(R.id.vscroll1);
		zoom_lin = findViewById(R.id.zoom_lin);
		linear2 = findViewById(R.id.linear2);
		hscroll1 = findViewById(R.id.hscroll1);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		out_text = findViewById(R.id.out_text);
		textview2 = findViewById(R.id.textview2);
		terminal = findViewById(R.id.terminal);
		textview5 = findViewById(R.id.textview5);
		linear8 = findViewById(R.id.linear8);
		textview3 = findViewById(R.id.textview3);
		linear7 = findViewById(R.id.linear7);
		textview4 = findViewById(R.id.textview4);
		
		linear2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				terminal.requestFocus();
			}
		});
		
		terminal.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.contains("\n")) {
					terminal_text = _charSeq.replace("\n", "");
					if (terminal_text.startsWith("cd")) {
						if (terminal_text.replace("cd", "").replace(" ", "").equals("")) {
							_main_command("");
						}
						else {
							pwd = pwd.concat("/".concat(terminal_text.replace("cd ", "")));
							_main_command("");
						}
					}
					else {
						if (terminal_text.startsWith("ls")) {
							_main_command("ls ".concat(" ".concat(pwd)));
						}
						else {
							if (terminal_text.startsWith("home")) {
								pwd = FileUtil.getExternalStorageDir();
								_main_command("");
							}
							else {
								if (terminal_text.startsWith("clear")) {
									output = "";
									_main_command("");
								}
								else {
									if (terminal_text.startsWith("help")) {
										_temp_command("help");
									}
									else {
										if (terminal_text.startsWith("really")) {
											_temp_command("really");
										}
										else {
											if (terminal_text.startsWith("what")) {
												_temp_command("what");
											}
											else {
												if (terminal_text.startsWith("refresh")) {
													_temp_command("refresh");
												}
												else {
													if (terminal_text.startsWith("about")) {
														_temp_command("about");
													}
													else {
														if (terminal_text.startsWith("tester47")) {
															_temp_command("tester47");
														}
														else {
															if (terminal_text.startsWith("ansi regular")) {
																_temp_command("ansi regular");
															}
															else {
																if (terminal_text.startsWith("3d ascii")) {
																	_temp_command("3d ascii");
																}
																else {
																	if (terminal_text.startsWith("benjamin")) {
																		_temp_command("benjamin");
																	}
																	else {
																		if (terminal_text.startsWith("braced")) {
																			_temp_command("braced");
																		}
																		else {
																			if (terminal_text.startsWith("app icon")) {
																				_temp_command("app icon");
																			}
																			else {
																				if (terminal_text.startsWith("null")) {
																					_temp_command("null");
																				}
																				else {
																					if (terminal_text.startsWith("chain")) {
																						_temp_command("chain");
																					}
																					else {
																						if (terminal_text.startsWith("units")) {
																							_temp_command("units");
																						}
																						else {
																							if (terminal_text.startsWith("zoom")) {
																								_temp_command("zoom");
																							}
																							else {
																								if (terminal_text.startsWith("zoom -d")) {
																									_temp_command("zoom -d");
																								}
																								else {
																									if (terminal_text.startsWith("debug /app")) {
																										_temp_command("debug /app");
																									}
																									else {
																										if (terminal_text.startsWith("kill /app")) {
																											_temp_command("kill /app");
																										}
																										else {
																											_main_command(_charSeq);
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				else {
					
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		textview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				size = 10;
				terminal.setTextSize((int)10);
				out_text.setTextSize((int)10);
				textview2.setTextSize((int)10);
			}
		});
		
		textview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				size++;
				terminal.setTextSize((int)size);
				out_text.setTextSize((int)size);
				textview2.setTextSize((int)size);
			}
		});
		
		textview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (size < 5) {
					
				}
				else {
					size--;
					terminal.setTextSize((int)size);
					out_text.setTextSize((int)size);
					textview2.setTextSize((int)size);
				}
			}
		});
	}
	
	private void initializeLogic() {
		setTitle("Android Terminal");
		
		pre_path = "~";
		pre = " $";
		pwd = FileUtil.getExternalStorageDir();
		command = "";
		out = "";
		size = 10;
		_pre_command();
		terminal.performClick();
		terminal.requestFocus();
		zoom_lin.setVisibility(View.GONE);
		terminal.setTypeface(Typeface.MONOSPACE);
		textview2.setTypeface(Typeface.MONOSPACE);
		out_text.setTypeface(Typeface.MONOSPACE);
		out_text.setTextIsSelectable(true);
		vscroll1.setVerticalScrollBarEnabled(false);
		vscroll1.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
		hscroll1.setHorizontalScrollBarEnabled(false);
		hscroll1.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
		
	}
	
	@Override
	public void onBackPressed() {
		num++;
		if (num == 2) {
			num = 2;
			finish();
		}
		else {
			out_text.setText(out_text.getText().toString().concat("\n>>> [To complete the process press \"back\" again]\n\n>>> After 3000ms, this option is deactivated."));
			t = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							num--;
							out_text.setText(out_text.getText().toString().concat("\n>>> This option has been disabled."));
						}
					});
				}
			};
			_timer.schedule(t, (int)(3000));
		}
	}
	public void _execute_shell(final String _command) {
		StringBuilder output = new StringBuilder();
		try{
				java.lang.Process cmdProc = Runtime.getRuntime().exec(_command);
				
				
				java.io.BufferedReader stdoutReader = new java.io.BufferedReader(
				         new java.io.InputStreamReader(cmdProc.getInputStream()));
				String line;
				while ((line = stdoutReader.readLine()) != null) {
						   // process procs standard output here
						  output.append(line + "\n");
				}
				
				this.out = output.toString();
		}catch(Exception e){
				out = e.toString();
		}
	}
	
	
	public void _add_output(final String _text) {
		output = output.concat(textview2.getText().toString().replace("$", "").concat(">>>").concat(terminal.getText().toString().replace("\n", "").concat("\n>>>".concat(_text.concat("")))));
	}
	
	
	public void _pre_command() {
		textview2.setText(pre_path.concat(pwd.concat(pre)));
	}
	
	
	public void _main_command(final String _command) {
		if (_command.equals("")) {
			
		}
		else {
			_execute_shell(_command);
		}
		_pre_command();
		if (out.equals("")) {
			_add_output("Done...");
		}
		else {
			_add_output(out);
		}
		out_text.setText(output);
		terminal.setText("");
		out = "";
	}
	
	
	public void _temp_command(final String _command) {
		if (_command.equals("help")) {
			out_text.setText(out_text.getText().toString().concat(">>> \n>>>temp/ help\n\n┏━━━━━[Command Example]\n┃\n┣━━━━━ home [To Go Home Directory]\n┣━━━━━ clear [To Clean Terminal]\n┣━━━━━ cd \n┃     ┗━━━━━━━━━━━ cd [path]\n┃     ┗━━━━━━━━━━━ cd ~\n┃     ┗━━━━━━━━━━━ cd --\n┃     ┗━━━━━━━━━━━ cd -\n┣━━━━━ ls\n┃     ┗━━━━━━━━━━━ ls -n\n┃     ┗━━━━━━━━━━━ ls --version\n┃     ┗━━━━━━━━━━━ ls -l\n┃     ┗━━━━━━━━━━━ ls help\n┃     ┗━━━━━━━━━━━ ls -a\n┃     ┗━━━━━━━━━━━ ls -al\n┃     ┗━━━━━━━━━━━ ls -i\n┣━━━━━ mkdir \n┣━━━━━ whoami\n┣━━━━━ cat /proc/meminfo\n┣━━━━━ pwd\n┣━━━━━ rm -rf [filename]\n┣━━━━━ cp -v\n┃     ┗━━━━━━━━━━━ cp -r\n┃     ┗━━━━━━━━━━━ cd -n\n┣━━━━━ mv -u\n┃     ┗━━━━━━━━━━━ mv -v\n┃     ┗━━━━━━━━━━━ mv -f\n┃     ┗━━━━━━━━━━━ mv -i\n┃     ┗━━━━━━━━━━━ mv [filename]\n┃\n┣━━━━━And many others just test ...\n┗━━━━━You can also run .sh file\n\n┏━━━━━[Temp Command Example]\n┃\n┣━━━━━[Q]: What does this temporary order mean? \n┣━━━━━[A]: means Temporary Command, which will disappear when you refresh or use terminal command (non-temporary)\n┃\n┃\n┃\n┣━━━━━ help\n┣━━━━━ zoom ┓\n┃            ┃\n┃            ┗━━━━━━━━━━━d zoom\n┃            \n┣━━━━━refresh\n┃\n┣━━━━━really\n┣━━━━━what\n┃\n┗━━━━━[Dingbats Commands - Temporary] ━┓\n                                        ┃\n                                        ┃\n                                        ┃\n                                        ┣━━━━━━━ansi regular\n                                        ┣━━━━━━━3d ascii\n                                        ┣━━━━━━━benjamin\n                                        ┣━━━━━━━braced\n                                        ┣━━━━━━━units\n                                        ┣━━━━━━━Tester47\n                                        ┗━━━━━━━chain━━━━━━┓\n                                                              ┃\n┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n┃\n┃\n┣━━━━━about\n┣━━━━━app icon\n┃\n┃\n┃\n┗━━━━━[OnBackPressed]━━━Exit━━━━after 3000 ms ━━━ the option is disabled \n\n\n┏━━━━━end\n┗━━━━━....\n\n\n[!] Some controls may not work or work abnormally!"));
			terminal.setText("");
		}
		else {
			if (_command.equals("really")) {
				out_text.setText(out_text.getText().toString().concat(">>> \n>>> temp/ascii/really\n\nCSS:\n\n─────────▄▄───────────────────▄▄──\n──────────▀█───────────────────▀█─\n──────────▄█───────────────────▄█─\n──█████████▀───────────█████████▀─\n───▄██████▄─────────────▄██████▄──\n─▄██▀────▀██▄─────────▄██▀────▀██▄\n─██────────██─────────██────────██\n─██───██───██─────────██───██───██\n─██────────██─────────██────────██\n──██▄────▄██───────────██▄────▄██─\n───▀██████▀─────────────▀██████▀──\n──────────────────────────────────\n──────────────────────────────────\n──────────────────────────────────\n───────────█████████████──────────\n──────────────────────────────────\n──────────────────────────────────"));
				terminal.setText("");
			}
			else {
				if (_command.equals("what")) {
					out_text.setText(out_text.getText().toString().concat(">>> \n>>> what\n\nCSS:\n\n\n\n╭╮╭╮╭╮\n┃┃┃┃┃┃\n┃┃┃┃┃┃\n┃╰╯╰╯┃\n╰╮╭╮╭╯\n╱╰╯╰╯\n╭╮╱╭╮\n┃┃╱┃┃\n┃╰━╯┃\n┃╭━╮┃\n┃┃╱┃┃\n╰╯╱╰╯\n╭━━━╮\n┃╭━╮┃\n┃┃╱┃┃\n┃╰━╯┃\n┃╭━╮┃\n╰╯╱╰╯\n╭━━━━╮\n┃╭╮╭╮┃\n╰╯┃┃╰╯\n╱╱┃┃\n╱╱┃┃\n╱╱╰╯"));
					terminal.setText("");
				}
				else {
					if (_command.equals("refresh")) {
						tt = new TimerTask() {
								@Override
								public void run() {
										runOnUiThread(new Runnable() {
												@Override
												public void run() {
														out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n\n\n0%");
														terminal.setText("");
														tt = new TimerTask() {
																@Override
																public void run() {
																		runOnUiThread(new Runnable() {
																				@Override
																				public void run() {
																						out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ \n\n7%");
																						terminal.setText("");
																						tt = new TimerTask() {
																								@Override
																								public void run() {
																										runOnUiThread(new Runnable() {
																												@Override
																												public void run() {
																														out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ \n\n16%");
																														terminal.setText("");
																														tt = new TimerTask() {
																																@Override
																																public void run() {
																																		runOnUiThread(new Runnable() {
																																				@Override
																																				public void run() {
																																						out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ ▃ \n\n34%");
																																						terminal.setText("");
																																						tt = new TimerTask() {
																																								@Override
																																								public void run() {
																																										runOnUiThread(new Runnable() {
																																												@Override
																																												public void run() {
																																														out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ ▃ ▄ \n\n47%");
																																														terminal.setText("");
																																														tt = new TimerTask() {
																																																@Override
																																																public void run() {
																																																		runOnUiThread(new Runnable() {
																																																				@Override
																																																				public void run() {
																																																						out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ ▃ ▄ ▅ \n\n61%");
																																																						terminal.setText("");
																																																						tt = new TimerTask() {
																																																								@Override
																																																								public void run() {
																																																										runOnUiThread(new Runnable() {
																																																												@Override
																																																												public void run() {
																																																														out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ ▃ ▄ ▅ ▆ \n\n72%");
																																																														terminal.setText("");
																																																														tt = new TimerTask() {
																																																																@Override
																																																																public void run() {
																																																																		runOnUiThread(new Runnable() {
																																																																				@Override
																																																																				public void run() {
																																																																						out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ ▃ ▄ ▅ ▆ ▇ \n\n83%");
																																																																						terminal.setText("");
																																																																						tt = new TimerTask() {
																																																																								@Override
																																																																								public void run() {
																																																																										runOnUiThread(new Runnable() {
																																																																												@Override
																																																																												public void run() {
																																																																														out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ ▃ ▄ ▅ ▆ ▇ █\n\n99%");
																																																																														terminal.setText("");
																																																																														tt = new TimerTask() {
																																																																																@Override
																																																																																public void run() {
																																																																																		runOnUiThread(new Runnable() {
																																																																																				@Override
																																																																																				public void run() {
																																																																																						out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ ▃ ▄ ▅ ▆ ▇ █\n\n100%");
																																																																																						terminal.setText("");
																																																																																						tt = new TimerTask() {
																																																																																								@Override
																																																																																								public void run() {
																																																																																										runOnUiThread(new Runnable() {
																																																																																												@Override
																																																																																												public void run() {
																																																																																														out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ ▃ ▄ ▅ ▆ ▇ █\n\n100%\n\n\n>>> in progress...\n\n𝍩");
																																																																																														terminal.setText("");
																																																																																														tt = new TimerTask() {
																																																																																																@Override
																																																																																																public void run() {
																																																																																																		runOnUiThread(new Runnable() {
																																																																																																				@Override
																																																																																																				public void run() {
																																																																																																						out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ ▃ ▄ ▅ ▆ ▇ █\n\n100%\n\n\n>>> in progress...\n\n𝍪");
																																																																																																						terminal.setText("");
																																																																																																						tt = new TimerTask() {
																																																																																																								@Override
																																																																																																								public void run() {
																																																																																																										runOnUiThread(new Runnable() {
																																																																																																												@Override
																																																																																																												public void run() {
																																																																																																														out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ ▃ ▄ ▅ ▆ ▇ █\n\n100%\n\n\n>>> in progress...\n\n𝍫");
																																																																																																														terminal.setText("");
																																																																																																														tt = new TimerTask() {
																																																																																																																@Override
																																																																																																																public void run() {
																																																																																																																		runOnUiThread(new Runnable() {
																																																																																																																				@Override
																																																																																																																				public void run() {
																																																																																																																						out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ ▃ ▄ ▅ ▆ ▇ █\n\n100%\n\n\n>>> in progress...\n\n𝍬");
																																																																																																																						terminal.setText("");
																																																																																																																						tt = new TimerTask() {
																																																																																																																								@Override
																																																																																																																								public void run() {
																																																																																																																										runOnUiThread(new Runnable() {
																																																																																																																												@Override
																																																																																																																												public void run() {
																																																																																																																														out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ ▃ ▄ ▅ ▆ ▇ █\n\n100%\n\n\n>>> in progress...\n\n𝍭");
																																																																																																																														terminal.setText("");
																																																																																																																														tt = new TimerTask() {
																																																																																																																																@Override
																																																																																																																																public void run() {
																																																																																																																																		runOnUiThread(new Runnable() {
																																																																																																																																				@Override
																																																																																																																																				public void run() {
																																																																																																																																						out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ ▃ ▄ ▅ ▆ ▇ █\n\n100%\n\n\n>>> in progress...\n\n𝍩");
																																																																																																																																						terminal.setText("");
																																																																																																																																						tt = new TimerTask() {
																																																																																																																																								@Override
																																																																																																																																								public void run() {
																																																																																																																																										runOnUiThread(new Runnable() {
																																																																																																																																												@Override
																																																																																																																																												public void run() {
																																																																																																																																														out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ ▃ ▄ ▅ ▆ ▇ █\n\n100%\n\n\n>>> in progress...\n\n𝍪");
																																																																																																																																														terminal.setText("");
																																																																																																																																														tt = new TimerTask() {
																																																																																																																																																@Override
																																																																																																																																																public void run() {
																																																																																																																																																		runOnUiThread(new Runnable() {
																																																																																																																																																				@Override
																																																																																																																																																				public void run() {
																																																																																																																																																						out_text.setText(">>> refresh\n\n\n\n>>> refreshing...\n\n▁ ▂ ▃ ▄ ▅ ▆ ▇ █\n\n100%\n\n\n>>> in progress...\n\n\n>>> ended\n\n\n>>> done");
																																																																																																																																																						terminal.setText("");
																																																																																																																																																				}
																																																																																																																																																		});
																																																																																																																																																}
																																																																																																																																														};
																																																																																																																																														_timer.schedule(tt, (int)(150));
																																																																																																																																												}
																																																																																																																																										});
																																																																																																																																								}
																																																																																																																																						};
																																																																																																																																						_timer.schedule(tt, (int)(150));
																																																																																																																																				}
																																																																																																																																		});
																																																																																																																																}
																																																																																																																														};
																																																																																																																														_timer.schedule(tt, (int)(150));
																																																																																																																												}
																																																																																																																										});
																																																																																																																								}
																																																																																																																						};
																																																																																																																						_timer.schedule(tt, (int)(150));
																																																																																																																				}
																																																																																																																		});
																																																																																																																}
																																																																																																														};
																																																																																																														_timer.schedule(tt, (int)(150));
																																																																																																												}
																																																																																																										});
																																																																																																								}
																																																																																																						};
																																																																																																						_timer.schedule(tt, (int)(150));
																																																																																																				}
																																																																																																		});
																																																																																																}
																																																																																														};
																																																																																														_timer.schedule(tt, (int)(150));
																																																																																												}
																																																																																										});
																																																																																								}
																																																																																						};
																																																																																						_timer.schedule(tt, (int)(150));
																																																																																				}
																																																																																		});
																																																																																}
																																																																														};
																																																																														_timer.schedule(tt, (int)(750));
																																																																												}
																																																																										});
																																																																								}
																																																																						};
																																																																						_timer.schedule(tt, (int)(750));
																																																																				}
																																																																		});
																																																																}
																																																														};
																																																														_timer.schedule(tt, (int)(750));
																																																												}
																																																										});
																																																								}
																																																						};
																																																						_timer.schedule(tt, (int)(750));
																																																				}
																																																		});
																																																}
																																														};
																																														_timer.schedule(tt, (int)(450));
																																												}
																																										});
																																								}
																																						};
																																						_timer.schedule(tt, (int)(450));
																																				}
																																		});
																																}
																														};
																														_timer.schedule(tt, (int)(750));
																												}
																										});
																								}
																						};
																						_timer.schedule(tt, (int)(450));
																				}
																		});
																}
														};
														_timer.schedule(tt, (int)(250));
												}
										});
								}
						};
						_timer.schedule(tt, (int)(150));
					}
					else {
						if (_command.equals("null")) {
							out_text.setText(out_text.getText().toString().concat("\n~/storage/emulated/0 $"));
							terminal.setText("");
						}
						else {
							if (_command.equals("about")) {
								out_text.setText(out_text.getText().toString().concat("\n>>> temp/about\n\n\n>>>\n\n\n\n\n\n\n╔══╦╗────╔╗\n║╔╗║╚╦═╦╦╣╚╗\n║╠╣║╬║╬║║║╔╣\n╚╝╚╩═╩═╩═╩═╝\n\n\n\n\nDev. by: InfLps\nApp version: 5.0.1 (Relase:10)\nAlias: Sketchware\nCountry: Romania (+40)\nFull app name: CodeXYZ\nAbbreviated app name: CodeXYZ\nDate since last update: 15.08.2023\nApp release date: 02.02.2021\n\n\n\n\n\n>>>"));
								terminal.setText("");
							}
							else {
								if (_command.equals("tester47")) {
									out_text.setText(out_text.getText().toString().concat("\n>>> temp/tester47\n\n\n>>>\n\n\n███████▓█████▓▓╬╬╬╬╬╬╬╬▓███▓╬╬╬╬╬╬╬▓╬╬▓█ \n████▓▓▓▓╬╬▓█████╬╬╬╬╬╬███▓╬╬╬╬╬╬╬╬╬╬╬╬╬█ \n███▓▓▓▓╬╬╬╬╬╬▓██╬╬╬╬╬╬▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█ \n████▓▓▓╬╬╬╬╬╬╬▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█ \n███▓█▓███████▓▓███▓╬╬╬╬╬╬▓███████▓╬╬╬╬▓█ \n████████████████▓█▓╬╬╬╬╬▓▓▓▓▓▓▓▓╬╬╬╬╬╬╬█ \n███▓▓▓▓▓▓▓╬╬▓▓▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█ \n████▓▓▓╬╬╬╬▓▓▓▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█ \n███▓█▓▓▓▓▓▓▓▓▓▓▓▓▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█ \n█████▓▓▓▓▓▓▓▓█▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█ \n█████▓▓▓▓▓▓▓██▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬██ \n█████▓▓▓▓▓████▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬██ \n████▓█▓▓▓▓██▓▓▓▓██╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬██ \n████▓▓███▓▓▓▓▓▓▓██▓╬╬╬╬╬╬╬╬╬╬╬╬█▓╬▓╬╬▓██ \n█████▓███▓▓▓▓▓▓▓▓████▓▓╬╬╬╬╬╬╬█▓╬╬╬╬╬▓██ \n█████▓▓█▓███▓▓▓████╬▓█▓▓╬╬╬▓▓█▓╬╬╬╬╬╬███ \n██████▓██▓███████▓╬╬╬▓▓╬▓▓██▓╬╬╬╬╬╬╬▓███ \n███████▓██▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓╬╬╬╬╬╬╬╬╬╬╬████ \n███████▓▓██▓▓▓▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓████ \n████████▓▓▓█████▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█████ \n█████████▓▓▓█▓▓▓▓▓███▓╬╬╬╬╬╬╬╬╬╬╬▓██████ \n██████████▓▓▓█▓▓▓╬▓██╬╬╬╬╬╬╬╬╬╬╬▓███████ \n███████████▓▓█▓▓▓▓███▓╬╬╬╬╬╬╬╬╬▓████████ \n██████████████▓▓▓███▓▓╬╬╬╬╬╬╬╬██████████ \n███████████████▓▓▓██▓▓╬╬╬╬╬╬▓███████████\n"));
									terminal.setText("");
								}
								else {
									if (_command.equals("ansi regular")) {
										out_text.setText(out_text.getText().toString().concat("\n>>> temp/ascii/ansi regular\n\n\n>>>\n\n\n ██████    \n██    ██   \n██    ██   \n██ ▄▄ ██   \n ██████    \n    ▀▀     \n           \n██     ██  \n██     ██  \n██  █  ██  \n██ ███ ██  \n ███ ███   \n           \n           \n███████    \n██         \n█████      \n██         \n███████    \n           \n           \n██████     \n██   ██    \n██████     \n██   ██    \n██   ██    \n           \n           \n████████   \n   ██      \n   ██      \n   ██      \n   ██      \n           \n           \n██    ██   \n ██  ██    \n  ████     \n   ██      \n   ██      \n           \n           \n██    ██   \n██    ██   \n██    ██   \n██    ██   \n ██████    \n           \n           \n██         \n██         \n██         \n██         \n██         \n           \n           \n ██████    \n██    ██   \n██    ██   \n██    ██   \n ██████    \n           \n           \n██████     \n██   ██    \n██████     \n██         \n██         \n           \n           \n █████     \n██   ██    \n███████    \n██   ██    \n██   ██    \n           \n           \n███████    \n██         \n███████    \n     ██    \n███████    \n           \n           \n██████     \n██   ██    \n██   ██    \n██   ██    \n██████     \n           \n           \n███████    \n██         \n█████      \n██         \n██         \n           \n           \n ██████    \n██         \n██   ███   \n██    ██   \n ██████    \n           \n           \n██   ██    \n██   ██    \n███████    \n██   ██    \n██   ██    \n           \n           \n     ██    \n     ██    \n     ██    \n██   ██    \n █████     \n           \n           \n██   ██    \n██  ██     \n█████      \n██  ██     \n██   ██    \n           \n           \n██         \n██         \n██         \n██         \n███████    \n           \n           \n███████    \n   ███     \n  ███      \n ███       \n███████    \n           \n           \n██   ██    \n ██ ██     \n  ███      \n ██ ██     \n██   ██    \n           \n           \n ██████    \n██         \n██         \n██         \n ██████    \n           \n           \n██    ██   \n██    ██   \n██    ██   \n ██  ██    \n  ████     \n           \n           \n██████     \n██   ██    \n██████     \n██   ██    \n██████     \n           \n           \n███    ██  \n████   ██  \n██ ██  ██  \n██  ██ ██  \n██   ████  \n           \n           \n███    ███ \n████  ████ \n██ ████ ██ \n██  ██  ██ \n██      ██ \n           \n           \n ██        \n███        \n ██        \n ██        \n ██        \n           \n           \n██████     \n     ██    \n █████     \n██         \n███████    \n           \n           \n██████     \n     ██    \n █████     \n     ██    \n██████     \n           \n           \n██   ██    \n██   ██    \n███████    \n     ██    \n     ██    \n           \n           \n███████    \n██         \n███████    \n     ██    \n███████    \n           \n           \n ██████    \n██         \n███████    \n██    ██   \n ██████    \n           \n           \n███████    \n     ██    \n    ██     \n   ██      \n   ██      \n           \n           \n █████     \n██   ██    \n █████     \n██   ██    \n █████     \n           \n           \n █████     \n██   ██    \n ██████    \n     ██    \n █████     \n           \n           \n ██████    \n██  ████   \n██ ██ ██   \n████  ██   \n ██████    \n           \n           "));
										terminal.setText("");
									}
									else {
										if (_command.equals("3d ascii")) {
											out_text.setText(out_text.getText().toString().concat("\n>>> temp/ascii/3d ascii\n\n\n>>>\n\n\n ________          \n|\\   __  \\         \n\\ \\  \\|\\  \\        \n \\ \\  \\\\\\  \\       \n  \\ \\  \\\\\\  \\      \n   \\ \\_____  \\     \n    \\|___| \\__\\    \n          \\|__|    \n                   \n                   \n ___       __      \n|\\  \\     |\\  \\    \n\\ \\  \\    \\ \\  \\   \n \\ \\  \\  __\\ \\  \\  \n  \\ \\  \\|\\__\\_\\  \\ \n   \\ \\____________\\\n    \\|____________|\n                   \n                   \n                   \n _______           \n|\\  ___ \\          \n\\ \\   __/|         \n \\ \\  \\_|/__       \n  \\ \\  \\_|\\ \\      \n   \\ \\_______\\     \n    \\|_______|     \n                   \n                   \n                   \n ________          \n|\\   __  \\         \n\\ \\  \\|\\  \\        \n \\ \\   _  _\\       \n  \\ \\  \\\\  \\|      \n   \\ \\__\\\\ _\\      \n    \\|__|\\|__|     \n                   \n                   \n                   \n _________         \n|\\___   ___\\       \n\\|___ \\  \\_|       \n     \\ \\  \\        \n      \\ \\  \\       \n       \\ \\__\\      \n        \\|__|      \n                   \n                   \n                   \n  ___    ___       \n |\\  \\  /  /|      \n \\ \\  \\/  / /      \n  \\ \\    / /       \n   \\/  /  /        \n __/  / /          \n|\\___/ /           \n\\|___|/            \n                   \n                   \n ___  ___          \n|\\  \\|\\  \\         \n\\ \\  \\\\\\  \\        \n \\ \\  \\\\\\  \\       \n  \\ \\  \\\\\\  \\      \n   \\ \\_______\\     \n    \\|_______|     \n                   \n                   \n                   \n ___               \n|\\  \\              \n\\ \\  \\             \n \\ \\  \\            \n  \\ \\  \\           \n   \\ \\__\\          \n    \\|__|          \n                   \n                   \n                   \n ________          \n|\\   __  \\         \n\\ \\  \\|\\  \\        \n \\ \\  \\\\\\  \\       \n  \\ \\  \\\\\\  \\      \n   \\ \\_______\\     \n    \\|_______|     \n                   \n                   \n                   \n ________          \n|\\   __  \\         \n\\ \\  \\|\\  \\        \n \\ \\   ____\\       \n  \\ \\  \\___|       \n   \\ \\__\\          \n    \\|__|          \n                   \n                   \n                   \n ________          \n|\\   __  \\         \n\\ \\  \\|\\  \\        \n \\ \\   __  \\       \n  \\ \\  \\ \\  \\      \n   \\ \\__\\ \\__\\     \n    \\|__|\\|__|     \n                   \n                   \n                   \n ________          \n|\\   ____\\         \n\\ \\  \\___|_        \n \\ \\_____  \\       \n  \\|____|\\  \\      \n    ____\\_\\  \\     \n   |\\_________\\    \n   \\|_________|    \n                   \n                   \n ________          \n|\\   ___ \\         \n\\ \\  \\_|\\ \\        \n \\ \\  \\ \\\\ \\       \n  \\ \\  \\_\\\\ \\      \n   \\ \\_______\\     \n    \\|_______|     \n                   \n                   \n                   \n ________          \n|\\  _____\\         \n\\ \\  \\__/          \n \\ \\   __\\         \n  \\ \\  \\_|         \n   \\ \\__\\          \n    \\|__|          \n                   \n                   \n                   \n ________          \n|\\   ____\\         \n\\ \\  \\___|         \n \\ \\  \\  ___       \n  \\ \\  \\|\\  \\      \n   \\ \\_______\\     \n    \\|_______|     \n                   \n                   \n                   \n ___  ___          \n|\\  \\|\\  \\         \n\\ \\  \\\\\\  \\        \n \\ \\   __  \\       \n  \\ \\  \\ \\  \\      \n   \\ \\__\\ \\__\\     \n    \\|__|\\|__|     \n                   \n                   \n                   \n    ___            \n   |\\  \\           \n   \\ \\  \\          \n __ \\ \\  \\         \n|\\  \\\\_\\  \\        \n\\ \\________\\       \n \\|________|       \n                   \n                   \n                   \n ___  __           \n|\\  \\|\\  \\         \n\\ \\  \\/  /|_       \n \\ \\   ___  \\      \n  \\ \\  \\\\ \\  \\     \n   \\ \\__\\\\ \\__\\    \n    \\|__| \\|__|    \n                   \n                   \n                   \n ___               \n|\\  \\              \n\\ \\  \\             \n \\ \\  \\            \n  \\ \\  \\____       \n   \\ \\_______\\     \n    \\|_______|     \n                   \n                   \n                   \n ________          \n|\\_____  \\         \n \\|___/  /|        \n     /  / /        \n    /  /_/__       \n   |\\________\\     \n    \\|_______|     \n                   \n                   \n                   \n ___    ___        \n|\\  \\  /  /|       \n\\ \\  \\/  / /       \n \\ \\    / /        \n  /     \\/         \n /  /\\   \\         \n/__/ /\\ __\\        \n|__|/ \\|__|        \n                   \n                   \n ________          \n|\\   ____\\         \n\\ \\  \\___|         \n \\ \\  \\            \n  \\ \\  \\____       \n   \\ \\_______\\     \n    \\|_______|     \n                   \n                   \n                   \n ___      ___      \n|\\  \\    /  /|     \n\\ \\  \\  /  / /     \n \\ \\  \\/  / /      \n  \\ \\    / /       \n   \\ \\__/ /        \n    \\|__|/         \n                   \n                   \n                   \n ________          \n|\\   __  \\         \n\\ \\  \\|\\ /_        \n \\ \\   __  \\       \n  \\ \\  \\|\\  \\      \n   \\ \\_______\\     \n    \\|_______|     \n                   \n                   \n                   \n ________          \n|\\   ___  \\        \n\\ \\  \\\\ \\  \\       \n \\ \\  \\\\ \\  \\      \n  \\ \\  \\\\ \\  \\     \n   \\ \\__\\\\ \\__\\    \n    \\|__| \\|__|    \n                   \n                   \n                   \n _____ ______      \n|\\   _ \\  _   \\    \n\\ \\  \\\\\\__\\ \\  \\   \n \\ \\  \\\\|__| \\  \\  \n  \\ \\  \\    \\ \\  \\ \n   \\ \\__\\    \\ \\__\\\n    \\|__|     \\|__|\n                   \n                   \n                   \n  _____            \n / __  \\           \n|\\/_|\\  \\          \n\\|/ \\ \\  \\         \n     \\ \\  \\        \n      \\ \\__\\       \n       \\|__|       \n                   \n                   \n                   \n  _______          \n /  ___  \\         \n/__/|_/  /|        \n|__|//  / /        \n    /  /_/__       \n   |\\________\\     \n    \\|_______|     \n                   \n                   \n                   \n ________          \n|\\_____  \\         \n\\|____|\\ /_        \n      \\|\\  \\       \n     __\\_\\  \\      \n    |\\_______\\     \n    \\|_______|     \n                   \n                   \n                   \n ___   ___         \n|\\  \\ |\\  \\        \n\\ \\  \\\\_\\  \\       \n \\ \\______  \\      \n  \\|_____|\\  \\     \n         \\ \\__\\    \n          \\|__|    \n                   \n                   \n                   \n ________          \n|\\   ____\\         \n\\ \\  \\___|_        \n \\ \\_____  \\       \n  \\|____|\\  \\      \n    ____\\_\\  \\     \n   |\\_________\\    \n   \\|_________|    \n                   \n                   \n ________          \n|\\   ____\\         \n\\ \\  \\___|         \n \\ \\  \\____        \n  \\ \\  ___  \\      \n   \\ \\_______\\     \n    \\|_______|     \n                   \n                   \n                   \n ________          \n|\\_____  \\         \n \\|___/  /|        \n     /  / /        \n    /  / /         \n   /__/ /          \n   |__|/           \n                   \n                   \n                   \n ________          \n|\\   __  \\         \n\\ \\  \\|\\  \\        \n \\ \\   __  \\       \n  \\ \\  \\|\\  \\      \n   \\ \\_______\\     \n    \\|_______|     \n                   \n                   \n                   \n ________          \n|\\  ___  \\         \n\\ \\____   \\        \n \\|____|\\  \\       \n     __\\_\\  \\      \n    |\\_______\\     \n    \\|_______|     \n                   \n                   \n                   \n ________          \n|\\   __  \\         \n\\ \\  \\|\\  \\        \n \\ \\  \\\\\\  \\       \n  \\ \\  \\\\\\  \\      \n   \\ \\_______\\     \n    \\|_______|     \n                   \n                   \n                        "));
											terminal.setText("");
										}
										else {
											if (_command.equals("benjamin")) {
												out_text.setText(out_text.getText().toString().concat("\n>>> temp/benjamin\n\n()_ \n\\/\\/\n[-  \n|2  \n\"|\" \n`/  \n|_| \n|   \n()  \n|'  \n/-\\ \n_\\\" \n|)  \n|=  \n[,  \n|-| \n.]  \n|<  \n|_  \n\"/_ \n><  \n(   \n\\/  \n|3  \n|\\| \n|\\/|\n'|  \n^/_ \n-}  \n+|  \n;\"  \n(o  \n\"/  \n{}  \n\")  \n(\\)       "));
												terminal.setText("");
											}
											else {
												if (_command.equals("braced")) {
													out_text.setText(out_text.getText().toString().concat("\n>>> temp/ascii/braced\n\n\n\n\n .---.   \n/ {-. \\  \n\\ '-} {  \n `--`-'  \n         \n.-.  .-. \n| {  } | \n{  /\\  } \n`-'  `-' \n         \n.----.   \n} |__}   \n} '__}   \n`----'   \n         \n.---.    \n} }}_}   \n| } \\    \n`-'-'    \n         \n.-----.  \n`-' '-'  \n  } {    \n  `-'    \n         \n.-.  .-. \n \\ \\/ /  \n  `-\\ }  \n    `-'  \n         \n.-. .-.  \n| } { |  \n\\ `-' /  \n `---'   \n         \n.-.      \n{ |      \n| }      \n`-'      \n         \n .---.   \n/ {-. \\  \n\\ '-} /  \n `---'   \n         \n.-.-.    \n| } }}   \n| |-'    \n`-'      \n         \n  .--.   \n / {} \\  \n/  /\\  \\ \n`-'  `-' \n         \n .----.  \n{ {__-`  \n.-._} }  \n`----'   \n         \n.----.   \n} {-. \\  \n} '-} /  \n`----'   \n         \n.----.   \n} |__}   \n} '_}    \n`--'     \n         \n.----.   \n| |--'   \n| }-`}   \n`----'   \n         \n.-. .-.  \n{ {_} |  \n| { } }  \n`-' `-'  \n         \n   .-.   \n   | |   \n{`-' }   \n `---'   \n         \n.-..-.   \n| ' /    \n| . \\    \n`-'`-`   \n         \n.-.      \n} |      \n} '--.   \n`----'   \n         \n.---.    \n`-`} }   \n{ /.-.   \n `---'   \n         \n.-..-.   \n\\ {} /   \n/ {} \\   \n`-'`-'   \n         \n.----.   \n| }`-'   \n| },-.   \n`----'   \n         \n.-.   .-.\n \\ \\_/ / \n  \\   /  \n   `-'   \n         \n.----.   \n| {_} }  \n| {_} }  \n`----'   \n         \n.-. .-.  \n|  \\{ |  \n| }\\  {  \n`-' `-'  \n         \n.-.  .-. \n}  \\/  { \n| {  } | \n`-'  `-' \n         \n.-.      \n{ |      \n| }      \n`-'      \n         \n.---.    \n`-`} }   \n{ {.-.   \n `---'   \n         \n.---.    \n`-`} }   \n.-.} }   \n`----`   \n         \n.-. .-.  \n \\ \\| |  \n  `-\\ }  \n    `-'  \n         \n .---.   \n{ {`-'   \n.-.} }   \n`---'    \n         \n  .-.    \n / /.    \n{ {} }   \n `--'    \n         \n.---.    \n`-`} }   \n  / /    \n `-'     \n         \n .--.    \n{ {} }   \n{ {} }   \n `--'    \n         \n .--.    \n{ {} }   \n `/ /    \n `-'     \n         \n .---.   \n. .-. .  \n' `-' '  \n `---'   \n         "));
													terminal.setText("");
												}
												else {
													if (_command.equals("app icon")) {
														out_text.setText(out_text.getText().toString().concat("\n>>> temp/ascii/app icon\n\nMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\nMMMMWXKKKKKKKKKKKKKKKKKKKKKKKKKKKKXWMMMM\nMMMKl'............................'lXMMM\nMMMk.                              'OMMM\nMMMk.     ....................     'OMMM\nMMMk.    .lOO00O00000000O00OOl.    'OMMM\nMMMk.    .xMMMMMMMMMMMMMMMMMMx.    'OMMM\nMMMk.    .xMMM0occcccccco0MMMx.    'OMMM\nMMMk.    .xMMMx.        .l000l.    'OMMM\nMMMk.    .xMMMx.         .....     'OMMM\nMMMk.    .xMMMx.                   'OMMM\nMMMk.    .xMMMk'..............     'OMMM\nMMMk.    .xMMMNK0000000000000l.    'OMMM\nMMMk.    .xWMMMMMMMMMMMMMMMMWx.    'OMMM\nMMMk.    .,ccccccccccccccccc:,.    'OMMM\nMMMk.                              'OMMM\nMMMO'                              ,0MMM\nMMMWOolllllllllllllllllllllllllllloOWMMM\nMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\nMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"));
														terminal.setText("");
													}
													else {
														if (_command.equals("chain")) {
															out_text.setText(out_text.getText().toString().concat("\n>>> temp/ascii/chain\n\n⫘⫘⫘⫘⫘⫘⫘⫘⫘\n⫘⫘⫘⫘⫘⫘⫘⫘⫘\n⫘⫘⫘⫘⫘⫘⫘⫘⫘\n⫘⫘⫘⫘⫘⫘⫘⫘⫘\n⫘⫘⫘⫘⫘⫘⫘⫘⫘"));
															terminal.setText("");
														}
														else {
															if (_command.equals("units")) {
																out_text.setText(out_text.getText().toString().concat("\n>>> temp/ascii/units\n\n㍱ \n㍲ \n㍳ \n㍴ \n㍵ \n㍶ \n㍷ \n㍸\n㍹\n㍺\n㎀ \n㎁ \n㎂ \n㎃ \n㎄ \n㎅ \n㎆ \n㎇ \n㎈ \n㎉ \n㎊ \n㎋ \n㎌ \n㎍ \n㎎ \n㎏ \n㎐ \n㎑ \n㎒ \n㎓ \n㎔ \n㎕ \n㎖ \n㎗ \n㎘ \n㎙ \n㎚ \n㎛ \n㎜ \n㎝ \n㎞ \n㎟ \n㎠ \n㎡ \n㎢ \n㎣ \n㎤ \n㎥ \n㎦ \n㎧ \n㎨ \n㎩ \n㎪ \n㎫ \n㎬ \n㎭ \n㎮ \n㎯ \n㎰ \n㎱ \n㎲ \n㎳ \n㎴ \n㎵ \n㎶ \n㎷ \n㎸ \n㎹ \n㎺ \n㎻ \n㎼ \n㎽ \n㎾ \n㎿ \n㏀ \n㏁ \n㏂ \n㏃ \n㏄ \n㏅ \n㏆ \n㏇ \n㏈ \n㏉ \n㏊ \n㏋ \n㏌ \n㏍ \n㏎ \n㏏ \n㏐ \n㏑ \n㏒ \n㏓ \n㏔ \n㏕ \n㏖ \n㏗ \n㏘ \n㏙ \n㏚ \n㏛ \n㏜ \n㏝ \n㏞ \n㏟"));
																terminal.setText("");
															}
															else {
																if (_command.equals("zoom")) {
																	if (zoom_lin.getVisibility() == View.GONE) {
																		out_text.setText(out_text.getText().toString().concat("\n>>> [COMPLETED] Zoom has been activated"));
																		zoom_lin.setVisibility(View.VISIBLE);
																		terminal.setText("");
																	}
																	else {
																		out_text.setText(out_text.getText().toString().concat("\n>>> [ERROR] Zoom is already actived"));
																		terminal.setText("");
																	}
																}
																else {
																	if (_command.equals("zoom -d")) {
																		if (zoom_lin.getVisibility() == View.VISIBLE) {
																			out_text.setText(out_text.getText().toString().concat("\n>>> [COMPLETED] Zoom has been dezactived "));
																			zoom_lin.setVisibility(View.GONE);
																			terminal.setText("");
																		}
																		else {
																			out_text.setText(out_text.getText().toString().concat("\n>>> [ERROR] Zoom is already dezactived"));
																			terminal.setText("");
																		}
																	}
																	else {
																		if (_command.equals("debug /app")) {
																			intent.setClass(getApplicationContext(), DebugActivity.class);
																			startActivity(intent);
																		}
																		else {
																			if (_command.equals("kill /app")) {
																				intent.setClass(getApplicationContext(), ExitConfirmationActivity.class);
																				startActivity(intent);
																			}
																			else {
																				
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}