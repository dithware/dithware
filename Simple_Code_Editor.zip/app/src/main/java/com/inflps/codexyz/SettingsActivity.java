package com.inflps.codexyz;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class SettingsActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private String fontName = "";
	private String typeace = "";
	private String q = "";
	private String message1 = "";
	private String errormessage = "";
	private String packageName = "";
	private HashMap<String, Object> Country = new HashMap<>();
	private String flagUrl = "";
	private String country_code = "";
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ScrollView vscroll1;
	private LinearLayout linear3;
	private ImageView imageview88;
	private TextView textview36;
	private LinearLayout linear4;
	private TextView textview40;
	private LinearLayout linear147;
	private LinearLayout linear150;
	private LinearLayout linear201;
	private TextView textview44;
	private LinearLayout linear182;
	private LinearLayout linear194;
	private LinearLayout linear180;
	private LinearLayout linear185;
	private LinearLayout linear188;
	private LinearLayout linear190;
	private TextView textview41;
	private LinearLayout linear151;
	private LinearLayout linear174;
	private LinearLayout linear197;
	private TextView textview53;
	private LinearLayout linear199;
	private ImageView imageview89;
	private Switch switch1;
	private ImageView imageview90;
	private Switch switch2;
	private ImageView imageview104;
	private LinearLayout linear202;
	private TextView textview60;
	private TextView textview62;
	private TextView textview61;
	private ImageView imageview96;
	private LinearLayout linear183;
	private Switch switch6;
	private TextView textview46;
	private ImageView imageview100;
	private LinearLayout linear195;
	private Switch switch9;
	private TextView textview52;
	private ImageView imageview95;
	private LinearLayout linear181;
	private Switch switch5;
	private TextView textview45;
	private ImageView imageview97;
	private LinearLayout linear186;
	private Switch switch7;
	private ImageView imageview98;
	private LinearLayout linear189;
	private Switch switch8;
	private TextView textview47;
	private ImageView imageview99;
	private LinearLayout linear192;
	private TextView textview51;
	private TextView textview50;
	private ImageView imageview91;
	private TextView textview37;
	private TextView textview39;
	private ImageView imageview92;
	private TextView textview42;
	private ImageView imageview101;
	private TextView textview54;
	private TextView country_name;
	private ImageView country_flag;
	private LinearLayout linear203;
	private ProgressBar progressbar1;
	private LinearLayout linear205;
	private ImageView imageview106;
	private ImageView imageview103;
	private LinearLayout linear200;
	private TextView textview58;
	private TextView textview59;
	private TextView textview2;
	
	private SharedPreferences settings;
	private TimerTask t;
	private Intent i = new Intent();
	private AlertDialog.Builder alert;
	private Intent i2 = new Intent();
	private RequestNetwork country;
	private RequestNetwork.RequestListener _country_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.settings);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		vscroll1 = findViewById(R.id.vscroll1);
		linear3 = findViewById(R.id.linear3);
		imageview88 = findViewById(R.id.imageview88);
		textview36 = findViewById(R.id.textview36);
		linear4 = findViewById(R.id.linear4);
		textview40 = findViewById(R.id.textview40);
		linear147 = findViewById(R.id.linear147);
		linear150 = findViewById(R.id.linear150);
		linear201 = findViewById(R.id.linear201);
		textview44 = findViewById(R.id.textview44);
		linear182 = findViewById(R.id.linear182);
		linear194 = findViewById(R.id.linear194);
		linear180 = findViewById(R.id.linear180);
		linear185 = findViewById(R.id.linear185);
		linear188 = findViewById(R.id.linear188);
		linear190 = findViewById(R.id.linear190);
		textview41 = findViewById(R.id.textview41);
		linear151 = findViewById(R.id.linear151);
		linear174 = findViewById(R.id.linear174);
		linear197 = findViewById(R.id.linear197);
		textview53 = findViewById(R.id.textview53);
		linear199 = findViewById(R.id.linear199);
		imageview89 = findViewById(R.id.imageview89);
		switch1 = findViewById(R.id.switch1);
		imageview90 = findViewById(R.id.imageview90);
		switch2 = findViewById(R.id.switch2);
		imageview104 = findViewById(R.id.imageview104);
		linear202 = findViewById(R.id.linear202);
		textview60 = findViewById(R.id.textview60);
		textview62 = findViewById(R.id.textview62);
		textview61 = findViewById(R.id.textview61);
		imageview96 = findViewById(R.id.imageview96);
		linear183 = findViewById(R.id.linear183);
		switch6 = findViewById(R.id.switch6);
		textview46 = findViewById(R.id.textview46);
		imageview100 = findViewById(R.id.imageview100);
		linear195 = findViewById(R.id.linear195);
		switch9 = findViewById(R.id.switch9);
		textview52 = findViewById(R.id.textview52);
		imageview95 = findViewById(R.id.imageview95);
		linear181 = findViewById(R.id.linear181);
		switch5 = findViewById(R.id.switch5);
		textview45 = findViewById(R.id.textview45);
		imageview97 = findViewById(R.id.imageview97);
		linear186 = findViewById(R.id.linear186);
		switch7 = findViewById(R.id.switch7);
		imageview98 = findViewById(R.id.imageview98);
		linear189 = findViewById(R.id.linear189);
		switch8 = findViewById(R.id.switch8);
		textview47 = findViewById(R.id.textview47);
		imageview99 = findViewById(R.id.imageview99);
		linear192 = findViewById(R.id.linear192);
		textview51 = findViewById(R.id.textview51);
		textview50 = findViewById(R.id.textview50);
		imageview91 = findViewById(R.id.imageview91);
		textview37 = findViewById(R.id.textview37);
		textview39 = findViewById(R.id.textview39);
		imageview92 = findViewById(R.id.imageview92);
		textview42 = findViewById(R.id.textview42);
		imageview101 = findViewById(R.id.imageview101);
		textview54 = findViewById(R.id.textview54);
		country_name = findViewById(R.id.country_name);
		country_flag = findViewById(R.id.country_flag);
		linear203 = findViewById(R.id.linear203);
		progressbar1 = findViewById(R.id.progressbar1);
		linear205 = findViewById(R.id.linear205);
		imageview106 = findViewById(R.id.imageview106);
		imageview103 = findViewById(R.id.imageview103);
		linear200 = findViewById(R.id.linear200);
		textview58 = findViewById(R.id.textview58);
		textview59 = findViewById(R.id.textview59);
		textview2 = findViewById(R.id.textview2);
		settings = getSharedPreferences("settings", Activity.MODE_PRIVATE);
		alert = new AlertDialog.Builder(this);
		country = new RequestNetwork(this);
		
		imageview88.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		linear201.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				alert.setTitle("Alert");
				alert.setMessage("This can cause the device to freeze or hang while moving items (depending on their size or quantity).");
				alert.setPositiveButton("Start dir migration", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						i.setClass(getApplicationContext(), MigrationActivity.class);
						startActivity(i);
					}
				});
				alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				_CustomDialogMaterial(alert, true);
			}
		});
		
		linear190.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_CheckIfInstalled("com.inflps.codex", "", "");
			}
		});
		
		linear174.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				
				return true;
			}
		});
		
		linear174.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), InformationActivity.class);
				startActivity(i);
			}
		});
		
		linear199.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				packageName = "com.inflps.codexyz";
				//Uninstall the app
				try {
					    Intent intent = new Intent(Intent.ACTION_DELETE);
					    intent.setData(Uri.parse("package:" + packageName));
					    startActivity(intent);
				} catch (ActivityNotFoundException e) {
					    // App not found
				}
			}
		});
		
		switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					settings.edit().putString("beta", "t").commit();
					settings.edit().putString("preview", "t").commit();
					settings.edit().putString("sound", "t").commit();
					switch6.setEnabled(true);
					switch8.setEnabled(true);
					linear188.setAlpha((float)(1));
					linear182.setAlpha((float)(1));
				}
				else {
					settings.edit().putString("beta", "f").commit();
					settings.edit().putString("preview", "f").commit();
					settings.edit().putString("sound", "f").commit();
					switch6.setEnabled(false);
					switch8.setEnabled(false);
					linear188.setAlpha((float)(0.4d));
					linear182.setAlpha((float)(0.4d));
				}
			}
		});
		
		switch2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					settings.edit().putString("legacy", "t").commit();
					switch1.setChecked(false);
					switch1.setAlpha((float)(0.4d));
					switch1.setEnabled(false);
					settings.edit().putString("beta", "f").commit();
				}
				else {
					settings.edit().putString("legacy", "f").commit();
					switch1.setAlpha((float)(1));
					switch1.setEnabled(true);
				}
			}
		});
		
		switch6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					settings.edit().putString("preview", "t").commit();
				}
				else {
					settings.edit().putString("preview", "f").commit();
				}
			}
		});
		
		switch9.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					settings.edit().putString("notification", "t").commit();
				}
				else {
					settings.edit().putString("notification", "f").commit();
				}
			}
		});
		
		switch5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					settings.edit().putString("scroll", "t").commit();
				}
				else {
					settings.edit().putString("scroll", "f").commit();
				}
			}
		});
		
		switch7.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (!_isChecked) {
					switch7.setChecked(true);
					SketchwareUtil.showMessage(getApplicationContext(), "An error occurred");
				}
			}
		});
		
		switch8.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					settings.edit().putString("sound", "t").commit();
				}
				else {
					settings.edit().putString("sound", "f").commit();
				}
			}
		});
		
		imageview106.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Only you know where you live, we don't!");
			}
		});
		
		_country_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				Country = new HashMap<>();
				Country = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
				country_name.setText(Country.get("country").toString());
				country_code = Country.get("countryCode").toString();
				flagUrl = "https://www.countryflags.io/".concat(Country.get("countryCode").toString().concat("/flat/64.png"));
				Glide.with(getApplicationContext()).load(Uri.parse(flagUrl)).into(country_flag);
				progressbar1.setVisibility(View.GONE);
				country_flag.setVisibility(View.VISIBLE);
				country_name.setVisibility(View.VISIBLE);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		_initSlideActivity();
	}
	
	@Override
	public void onStart() {
		super.onStart();
		_refresh();
		country_name.setVisibility(View.GONE);
		country_flag.setVisibility(View.GONE);
		progressbar1.setVisibility(View.VISIBLE);
		country.startRequestNetwork(RequestNetworkController.GET, "http://ip-api.com/json/", "countrycode", _country_request_listener);
	}
	public void _initSlideActivity() {
		getWindow().getDecorView().setBackgroundResource(android.R.color.transparent);
		ViewConfiguration vc = ViewConfiguration.get(this);
		MIN_DISTANCE = vc.getScaledTouchSlop();
		
		rootView =(ViewGroup)getWindow().findViewById(Window.ID_ANDROID_CONTENT);
		//converts percent to 0-225 range .
		maxAlpha =(int) ((225.0d/100.0d)* MAX_SCRIM_ALPHA); 
		try{
			convertFromTranslucent = Activity.class.getDeclaredMethod("convertFromTranslucent");         convertFromTranslucent.setAccessible(true);
			java.lang.reflect.Method getActivityOptions = Activity.class.getDeclaredMethod("getActivityOptions"); 	getActivityOptions.setAccessible(true);
			options = getActivityOptions.invoke(this);
				Class<?>[] classes = Activity.class.getDeclaredClasses();
			 Class<?> translucentConversionListenerClazz = null;
				for (Class clazz : classes) {
						if (clazz.getSimpleName().contains("TranslucentConversionListener")) {
								translucentConversionListenerClazz = clazz; 
						} 
				} 
				 convertToTranslucent = Activity.class.getDeclaredMethod("convertToTranslucent", translucentConversionListenerClazz, ActivityOptions.class);
				convertToTranslucent.setAccessible(true);
		} catch (Exception e) {
			showMessage(e.toString());
			 }
	}
	// Custom Variables
	//You can change it to color of your choice 
	private static final int SCRIM_COLOR = 0xFF000000;
	//Alpha is not taken into consideration while calculating scrim color  so it dosent matter .
	
	private static final int  SCRIM_R = Color.red(SCRIM_COLOR);
	private static final int SCRIM_G = Color.green(SCRIM_COLOR);
	private static final int  SCRIM_B = Color.blue(SCRIM_COLOR);
	private static final int MAX_SCRIM_ALPHA= 80;
	//in percentage
	private ViewGroup rootView ;
	private boolean enableSwipe= false;
	private boolean lockSwipe = false;
	private float downX;
	private float downY;
	private float MIN_DISTANCE ;
	private int maxAlpha;
	private java.lang.reflect.Method convertFromTranslucent;
	private java.lang.reflect.Method getActivityOptions;
	
	private Object options;
	
	private java.lang.reflect.Method convertToTranslucent;
	// Detect touch Events
	 @Override public boolean dispatchTouchEvent(MotionEvent event) { 
		switch(event.getAction()) { 
			case MotionEvent.ACTION_DOWN: 
			downX = event.getRawX();
			downY =event.getRawY();
			enableSwipe = false;
			lockSwipe = false;
			//convert activity to transparent
			try {
					convertToTranslucent.invoke(this, null, options); 
			} catch (Throwable t) {
			}
			break; 
			case MotionEvent.ACTION_MOVE: 
			if (!lockSwipe){
				if(enableSwipe){
					float translation = event.getRawX() -downX - MIN_DISTANCE;
					if (translation >= rootView.getWidth() || translation<= 0){
						rootView.setTranslationX(0);
					}else{
						rootView.setTranslationX(translation);
						//calculate distance scrolled in percentage
						int distanceInPercentage =(int)( ((double)translation/(double)rootView.getWidth())*100);
						
						//calculate alpha from distance in range 0 - maxAlpha
						
						int alpha =(int) ( ((double)maxAlpha/100.0d)*distanceInPercentage);
						
						//alpha will be greater when it is scrolled more this we do not need this but we need the inverse of it so subtract it from maxAlpha
						alpha = maxAlpha - alpha;
						
						int scrimColor = Color.argb(alpha,SCRIM_R,SCRIM_G,SCRIM_B);
						
						getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(scrimColor));
					}
				}else{
					if(Math.abs(event.getRawY() - downY) >= MIN_DISTANCE){
						enableSwipe = false;
						lockSwipe = true;
					}else{
						enableSwipe = event.getRawX() -downX >= MIN_DISTANCE;
					}
				}
			}
			break; 
			case MotionEvent.ACTION_UP: 
			if(rootView.getTranslationX() > rootView.getWidth() / 5){
				rootView.animate() 
				.translationX(rootView.getWidth())
				.setListener(
				new AnimatorListenerAdapter() { 
							@Override public void onAnimationEnd(Animator animation) { 
						
							super.onAnimationEnd(animation);
						finish();
						overridePendingTransition(0, 0);
						
					} });
			}else{
				rootView.animate() 
				.translationX(0)
				.setListener(
				new AnimatorListenerAdapter() { 
							@Override public void onAnimationEnd(Animator animation) { 
						super.onAnimationEnd(animation);
						// convert activity back to normal
						try {
							 convertFromTranslucent.invoke(this);
							        } catch (Throwable t) {}
					} });
				enableSwipe =false;
				lockSwipe = false;
			}
			break; 
			default:
			enableSwipe =false;
			lockSwipe = false;
			break; 
		}
		if (enableSwipe){
			event.setAction(MotionEvent.ACTION_CANCEL);
		}
		return super.dispatchTouchEvent(event);
	}
	
	{
	}
	
	
	public void _refresh() {
		// For widget performance
		if (settings.getString("beta", "").equals("t")) {
			switch1.setChecked(true);
		}
		else {
			switch1.setChecked(false);
		}
		if (settings.getString("legacy", "").equals("t")) {
			switch2.setChecked(true);
		}
		else {
			switch2.setChecked(false);
		}
		if (settings.getString("preview", "").equals("t")) {
			switch6.setChecked(true);
		}
		else {
			switch6.setChecked(false);
		}
		if (settings.getString("scroll", "").equals("t")) {
			switch5.setChecked(true);
		}
		else {
			switch5.setChecked(false);
		}
		if (settings.getString("sound", "").equals("t")) {
			switch8.setChecked(true);
		}
		else {
			switch8.setChecked(false);
		}
		if (settings.getString("notification", "").equals("t")) {
			switch9.setChecked(true);
		}
		else {
			switch9.setChecked(false);
		}
		//
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				}
				else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					}
					else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _CheckIfInstalled(final String _q, final String _message1, final String _errormessage) {
		//Moreblock By Mix Studio Official
		q = _q;
		message1 = _message1;
		errormessage = _errormessage;
		boolean isAppInstalled = appInstalledOrNot(q); // mixstudio
		
		if(isAppInstalled) {
			i2.setClass(getApplicationContext(), InfoActivity.class);
			startActivity(i2);
		} else {
			SketchwareUtil.showMessage(getApplicationContext(), "Fortunately the old app is non-existent!");
		}
	}
	
	private boolean appInstalledOrNot(String uri) { android.content.pm.PackageManager pm = getPackageManager(); try { pm.getPackageInfo(uri, android.content.pm.PackageManager.GET_ACTIVITIES); return true; } catch (android.content.pm.PackageManager.NameNotFoundException e) { } return false;
	}
	
	
	public void _CustomDialogMaterial(final AlertDialog.Builder _dial, final boolean _booleann) {
		
		setTheme(android.R.style.Theme_Material);
		_dial.setCancelable(_booleann);
		AlertDialog alert = _dial.show();
		alert.getWindow().getDecorView().setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, Color.parseColor("#252525")));
			alert.getWindow().getDecorView().setPadding(8,8,8,8);
		alert.show();
		
		alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#ff0000"));
			alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#ff0000"));
			alert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.parseColor("#ff0000"));
		alert.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
		alert.getWindow().getDecorView().setTranslationY(-20);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}