package com.inflps.codexyz;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import com.bumptech.glide.Glide;
import de.hdodenhof.circleimageview.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class AcknowledgementsActivity extends AppCompatActivity {
	
	private LinearLayout linear10;
	private LinearLayout linear26;
	private LinearLayout linear1;
	private LinearLayout linear11;
	private TextView textview1;
	private ScrollView vscroll1;
	private TextView textview4;
	private LinearLayout Layout;
	private LinearLayout linear27;
	private TextView textview9;
	private LinearLayout linear129;
	private LinearLayout linear132;
	private LinearLayout linear141;
	private LinearLayout linear147;
	private LinearLayout linear150;
	private LinearLayout linear153;
	private LinearLayout linear156;
	private LinearLayout linear159;
	private LinearLayout linear162;
	private LinearLayout linear165;
	private LinearLayout linear168;
	private LinearLayout linear171;
	private LinearLayout linear174;
	private LinearLayout linear177;
	private CircleImageView cimg1;
	private LinearLayout linear130;
	private TextView textview10;
	private ImageView imageview88;
	private LinearLayout linear131;
	private TextView textview11;
	private LinearLayout linear133;
	private LinearLayout linear134;
	private ImageView imageview97;
	private ImageView imageview98;
	private LinearLayout linear135;
	private LinearLayout linear138;
	private CircleImageView cimg2;
	private LinearLayout linear136;
	private TextView textview12;
	private ImageView imageview94;
	private LinearLayout linear137;
	private CircleImageView cimg3;
	private LinearLayout linear139;
	private TextView textview14;
	private ImageView imageview96;
	private LinearLayout linear140;
	private CircleImageView cimg4;
	private LinearLayout linear142;
	private TextView textview15;
	private ImageView imageview100;
	private LinearLayout linear143;
	private TextView textview16;
	private CircleImageView cimg5;
	private LinearLayout linear148;
	private TextView textview19;
	private ImageView imageview104;
	private LinearLayout linear149;
	private TextView textview20;
	private CircleImageView cimg6;
	private LinearLayout linear151;
	private TextView textview21;
	private ImageView imageview106;
	private LinearLayout linear152;
	private TextView textview22;
	private CircleImageView cimg7;
	private LinearLayout linear154;
	private TextView textview23;
	private ImageView imageview108;
	private LinearLayout linear155;
	private TextView textview24;
	private CircleImageView cimg8;
	private LinearLayout linear157;
	private TextView textview25;
	private ImageView imageview110;
	private LinearLayout linear158;
	private TextView textview26;
	private CircleImageView cimg9;
	private LinearLayout linear160;
	private TextView textview27;
	private ImageView imageview112;
	private LinearLayout linear161;
	private TextView textview28;
	private CircleImageView cimg10;
	private LinearLayout linear163;
	private TextView textview29;
	private ImageView imageview115;
	private ImageView imageview114;
	private LinearLayout linear164;
	private TextView textview30;
	private CircleImageView cimg11;
	private LinearLayout linear166;
	private TextView textview31;
	private ImageView imageview117;
	private LinearLayout linear167;
	private TextView textview32;
	private CircleImageView cimg12;
	private LinearLayout linear169;
	private TextView textview33;
	private ImageView imageview119;
	private LinearLayout linear170;
	private TextView textview34;
	private CircleImageView cimg13;
	private LinearLayout linear172;
	private TextView textview35;
	private ImageView imageview121;
	private LinearLayout linear173;
	private TextView textview36;
	private CircleImageView cimg14;
	private LinearLayout linear175;
	private TextView textview37;
	private ImageView imageview123;
	private LinearLayout linear176;
	private TextView textview38;
	private TextView textview39;
	private LinearLayout linear29;
	private LinearLayout linear121;
	private LinearLayout linear122;
	private LinearLayout linear123;
	private LinearLayout linear124;
	private LinearLayout linear125;
	private LinearLayout linear126;
	private LinearLayout linear127;
	private LinearLayout linear128;
	private ImageView imageview2;
	private TextView textview2;
	private ImageView imageview89;
	private TextView textview5;
	private ImageView imageview90;
	private TextView textview6;
	private ImageView imageview91;
	private TextView textview7;
	private ImageView imageview92;
	private TextView textview8;
	
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.acknowledgements);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear10 = findViewById(R.id.linear10);
		linear26 = findViewById(R.id.linear26);
		linear1 = findViewById(R.id.linear1);
		linear11 = findViewById(R.id.linear11);
		textview1 = findViewById(R.id.textview1);
		vscroll1 = findViewById(R.id.vscroll1);
		textview4 = findViewById(R.id.textview4);
		Layout = findViewById(R.id.Layout);
		linear27 = findViewById(R.id.linear27);
		textview9 = findViewById(R.id.textview9);
		linear129 = findViewById(R.id.linear129);
		linear132 = findViewById(R.id.linear132);
		linear141 = findViewById(R.id.linear141);
		linear147 = findViewById(R.id.linear147);
		linear150 = findViewById(R.id.linear150);
		linear153 = findViewById(R.id.linear153);
		linear156 = findViewById(R.id.linear156);
		linear159 = findViewById(R.id.linear159);
		linear162 = findViewById(R.id.linear162);
		linear165 = findViewById(R.id.linear165);
		linear168 = findViewById(R.id.linear168);
		linear171 = findViewById(R.id.linear171);
		linear174 = findViewById(R.id.linear174);
		linear177 = findViewById(R.id.linear177);
		cimg1 = findViewById(R.id.cimg1);
		linear130 = findViewById(R.id.linear130);
		textview10 = findViewById(R.id.textview10);
		imageview88 = findViewById(R.id.imageview88);
		linear131 = findViewById(R.id.linear131);
		textview11 = findViewById(R.id.textview11);
		linear133 = findViewById(R.id.linear133);
		linear134 = findViewById(R.id.linear134);
		imageview97 = findViewById(R.id.imageview97);
		imageview98 = findViewById(R.id.imageview98);
		linear135 = findViewById(R.id.linear135);
		linear138 = findViewById(R.id.linear138);
		cimg2 = findViewById(R.id.cimg2);
		linear136 = findViewById(R.id.linear136);
		textview12 = findViewById(R.id.textview12);
		imageview94 = findViewById(R.id.imageview94);
		linear137 = findViewById(R.id.linear137);
		cimg3 = findViewById(R.id.cimg3);
		linear139 = findViewById(R.id.linear139);
		textview14 = findViewById(R.id.textview14);
		imageview96 = findViewById(R.id.imageview96);
		linear140 = findViewById(R.id.linear140);
		cimg4 = findViewById(R.id.cimg4);
		linear142 = findViewById(R.id.linear142);
		textview15 = findViewById(R.id.textview15);
		imageview100 = findViewById(R.id.imageview100);
		linear143 = findViewById(R.id.linear143);
		textview16 = findViewById(R.id.textview16);
		cimg5 = findViewById(R.id.cimg5);
		linear148 = findViewById(R.id.linear148);
		textview19 = findViewById(R.id.textview19);
		imageview104 = findViewById(R.id.imageview104);
		linear149 = findViewById(R.id.linear149);
		textview20 = findViewById(R.id.textview20);
		cimg6 = findViewById(R.id.cimg6);
		linear151 = findViewById(R.id.linear151);
		textview21 = findViewById(R.id.textview21);
		imageview106 = findViewById(R.id.imageview106);
		linear152 = findViewById(R.id.linear152);
		textview22 = findViewById(R.id.textview22);
		cimg7 = findViewById(R.id.cimg7);
		linear154 = findViewById(R.id.linear154);
		textview23 = findViewById(R.id.textview23);
		imageview108 = findViewById(R.id.imageview108);
		linear155 = findViewById(R.id.linear155);
		textview24 = findViewById(R.id.textview24);
		cimg8 = findViewById(R.id.cimg8);
		linear157 = findViewById(R.id.linear157);
		textview25 = findViewById(R.id.textview25);
		imageview110 = findViewById(R.id.imageview110);
		linear158 = findViewById(R.id.linear158);
		textview26 = findViewById(R.id.textview26);
		cimg9 = findViewById(R.id.cimg9);
		linear160 = findViewById(R.id.linear160);
		textview27 = findViewById(R.id.textview27);
		imageview112 = findViewById(R.id.imageview112);
		linear161 = findViewById(R.id.linear161);
		textview28 = findViewById(R.id.textview28);
		cimg10 = findViewById(R.id.cimg10);
		linear163 = findViewById(R.id.linear163);
		textview29 = findViewById(R.id.textview29);
		imageview115 = findViewById(R.id.imageview115);
		imageview114 = findViewById(R.id.imageview114);
		linear164 = findViewById(R.id.linear164);
		textview30 = findViewById(R.id.textview30);
		cimg11 = findViewById(R.id.cimg11);
		linear166 = findViewById(R.id.linear166);
		textview31 = findViewById(R.id.textview31);
		imageview117 = findViewById(R.id.imageview117);
		linear167 = findViewById(R.id.linear167);
		textview32 = findViewById(R.id.textview32);
		cimg12 = findViewById(R.id.cimg12);
		linear169 = findViewById(R.id.linear169);
		textview33 = findViewById(R.id.textview33);
		imageview119 = findViewById(R.id.imageview119);
		linear170 = findViewById(R.id.linear170);
		textview34 = findViewById(R.id.textview34);
		cimg13 = findViewById(R.id.cimg13);
		linear172 = findViewById(R.id.linear172);
		textview35 = findViewById(R.id.textview35);
		imageview121 = findViewById(R.id.imageview121);
		linear173 = findViewById(R.id.linear173);
		textview36 = findViewById(R.id.textview36);
		cimg14 = findViewById(R.id.cimg14);
		linear175 = findViewById(R.id.linear175);
		textview37 = findViewById(R.id.textview37);
		imageview123 = findViewById(R.id.imageview123);
		linear176 = findViewById(R.id.linear176);
		textview38 = findViewById(R.id.textview38);
		textview39 = findViewById(R.id.textview39);
		linear29 = findViewById(R.id.linear29);
		linear121 = findViewById(R.id.linear121);
		linear122 = findViewById(R.id.linear122);
		linear123 = findViewById(R.id.linear123);
		linear124 = findViewById(R.id.linear124);
		linear125 = findViewById(R.id.linear125);
		linear126 = findViewById(R.id.linear126);
		linear127 = findViewById(R.id.linear127);
		linear128 = findViewById(R.id.linear128);
		imageview2 = findViewById(R.id.imageview2);
		textview2 = findViewById(R.id.textview2);
		imageview89 = findViewById(R.id.imageview89);
		textview5 = findViewById(R.id.textview5);
		imageview90 = findViewById(R.id.imageview90);
		textview6 = findViewById(R.id.textview6);
		imageview91 = findViewById(R.id.imageview91);
		textview7 = findViewById(R.id.textview7);
		imageview92 = findViewById(R.id.imageview92);
		textview8 = findViewById(R.id.textview8);
	}
	
	private void initializeLogic() {
		_convertToBottomSheet();
		Glide.with(getApplicationContext()).load(Uri.parse("https://avatars.githubusercontent.com/u/28822819?v=4")).into(cimg1);
		Glide.with(getApplicationContext()).load(Uri.parse("https://avatars.githubusercontent.com/u/26028538?v=4")).into(cimg2);
		Glide.with(getApplicationContext()).load(Uri.parse("https://asset.brandfetch.io/idarKiKkI-/id53SttZhi.jpeg")).into(cimg3);
		Glide.with(getApplicationContext()).load(Uri.parse("https://sketchub.in/storage/user_avatars/51978.png")).into(cimg4);
		Glide.with(getApplicationContext()).load(Uri.parse("https://sketchub.in/storage/user_avatars/77835.png")).into(cimg5);
		Glide.with(getApplicationContext()).load(Uri.parse("https://sketchub.in/storage/user_avatars/75297.png")).into(cimg6);
		Glide.with(getApplicationContext()).load(Uri.parse("https://sketchub.in/storage/user_avatars/1619.png")).into(cimg7);
		Glide.with(getApplicationContext()).load(Uri.parse("https://sketchub.in/storage/user_avatars/74776.png")).into(cimg8);
		Glide.with(getApplicationContext()).load(Uri.parse("https://sketchub.in/storage/user_avatars/2220.png")).into(cimg9);
		Glide.with(getApplicationContext()).load(Uri.parse("https://sketchub.in/storage/user_avatars/228.png")).into(cimg10);
		Glide.with(getApplicationContext()).load(Uri.parse("https://ui-avatars.com/api/?size=150&bold=true&rounded=true&name=tysin&background=0586FF&color=fff")).into(cimg11);
		Glide.with(getApplicationContext()).load(Uri.parse("https://sketchub.in/storage/user_avatars/49309.png")).into(cimg12);
		Glide.with(getApplicationContext()).load(Uri.parse("https://sketchub.in/storage/user_avatars/79598.png")).into(cimg13);
		Glide.with(getApplicationContext()).load(Uri.parse("https://sketchub.in/storage/user_avatars/55314.png")).into(cimg14);
	}
	
	public void _convertToBottomSheet() {
	}
	private androidx.coordinatorlayout.widget.CoordinatorLayout mCoordinatorLayout;
	@Override
	public void finish(){
		com.google.android.material.bottomsheet.BottomSheetBehavior.from(mCoordinatorLayout.getChildAt(0)).setState(com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_COLLAPSED);
	}
	private void superFinish(){
		super.finish();
	}
	 @Override
	public void setContentView(int layId){
			if(mCoordinatorLayout == null){
					overridePendingTransition(0,0);
					mCoordinatorLayout = new androidx.coordinatorlayout.widget.CoordinatorLayout(this);
					makeActivityTransparent();
			mCoordinatorLayout.setBackgroundColor(0x80000000);
					mCoordinatorLayout.setOnClickListener(new View.OnClickListener(){
							@Override
							public void onClick (View v){
										finish();
							}
					});
			}
			mCoordinatorLayout.removeAllViews();
			androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams params = new androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
			final com.google.android.material.bottomsheet.BottomSheetBehavior behavior = new com.google.android.material.bottomsheet.BottomSheetBehavior();
			params.setBehavior(behavior);
			behavior.setBottomSheetCallback(new com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback(){
					@Override
					public void onSlide(View bottomSheet, float slideOffset){
							
					}
					@Override
					public void onStateChanged(View bottomSheet, int newState){
							if(newState == com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_COLLAPSED){
									superFinish();
					overridePendingTransition(0,0);
							}
					}
			});
			View inflated = getLayoutInflater().inflate(layId,null);	
			mCoordinatorLayout.addView(inflated,params);
			
			if(mCoordinatorLayout.getParent()!= null)((ViewGroup)mCoordinatorLayout.getParent()).removeView(mCoordinatorLayout);
			setContentView(mCoordinatorLayout);
		inflated.post(new Runnable(){
			@Override
			            public void run() {
				behavior.setState(com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED);
			}});
		
	}
	
	private void makeActivityTransparent(){
		getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
			try {
					java.lang.reflect.Method getActivityOptions = Activity.class.getDeclaredMethod("getActivityOptions"); 
					getActivityOptions.setAccessible(true);
					Object options = getActivityOptions.invoke(this);
					Class<?>[] classes = Activity.class.getDeclaredClasses();
					Class<?> translucentConversionListenerClazz = null;
					for (Class clazz : classes) { 
							if (clazz.getSimpleName().contains("TranslucentConversionListener")) { 
									translucentConversionListenerClazz = clazz;
							} 
					} 
					java.lang.reflect.Method convertToTranslucent = Activity.class.getDeclaredMethod("convertToTranslucent", translucentConversionListenerClazz, ActivityOptions.class); 
					convertToTranslucent.setAccessible(true); 
					convertToTranslucent.invoke(this, null, options); 
			} catch (Throwable t) {
			}
	}
	
	{
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}