package com.inflps.codexyz;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class InformationActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear3;
	private LinearLayout linear26;
	private LinearLayout linear28;
	private ImageView imageview96;
	private LinearLayout linear10;
	private TextView textview57;
	private LinearLayout linear122;
	private LinearLayout linear123;
	private ImageView imageview1;
	private LinearLayout linear121;
	private LinearLayout linear11;
	private TextView textview1;
	private ImageView imageview95;
	private TextView textview55;
	private TabLayout tablayout1;
	private LinearLayout linear124;
	private LinearLayout aboutDevicePage;
	private LinearLayout aboutBatteryPage;
	private LinearLayout appInfoPage;
	private TextView textview58;
	private TextView textview59;
	private LinearLayout linear125;
	private Button button1;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private TextView textview6;
	private TextView b_level;
	private TextView textview8;
	private TextView b_status;
	private TextView textview10;
	private TextView b_temperature;
	private TextView textview12;
	private TextView b_health;
	private TextView textview60;
	private TextView textview61;
	private ImageView imageview88;
	private ImageView imageview89;
	private ImageView imageview90;
	private ImageView imageview91;
	private ImageView imageview92;
	private ImageView imageview93;
	private ImageView imageview94;
	
	private TimerTask t;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.information);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vscroll1 = findViewById(R.id.vscroll1);
		linear1 = findViewById(R.id.linear1);
		linear3 = findViewById(R.id.linear3);
		linear26 = findViewById(R.id.linear26);
		linear28 = findViewById(R.id.linear28);
		imageview96 = findViewById(R.id.imageview96);
		linear10 = findViewById(R.id.linear10);
		textview57 = findViewById(R.id.textview57);
		linear122 = findViewById(R.id.linear122);
		linear123 = findViewById(R.id.linear123);
		imageview1 = findViewById(R.id.imageview1);
		linear121 = findViewById(R.id.linear121);
		linear11 = findViewById(R.id.linear11);
		textview1 = findViewById(R.id.textview1);
		imageview95 = findViewById(R.id.imageview95);
		textview55 = findViewById(R.id.textview55);
		tablayout1 = findViewById(R.id.tablayout1);
		linear124 = findViewById(R.id.linear124);
		aboutDevicePage = findViewById(R.id.aboutDevicePage);
		aboutBatteryPage = findViewById(R.id.aboutBatteryPage);
		appInfoPage = findViewById(R.id.appInfoPage);
		textview58 = findViewById(R.id.textview58);
		textview59 = findViewById(R.id.textview59);
		linear125 = findViewById(R.id.linear125);
		button1 = findViewById(R.id.button1);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		textview6 = findViewById(R.id.textview6);
		b_level = findViewById(R.id.b_level);
		textview8 = findViewById(R.id.textview8);
		b_status = findViewById(R.id.b_status);
		textview10 = findViewById(R.id.textview10);
		b_temperature = findViewById(R.id.b_temperature);
		textview12 = findViewById(R.id.textview12);
		b_health = findViewById(R.id.b_health);
		textview60 = findViewById(R.id.textview60);
		textview61 = findViewById(R.id.textview61);
		imageview88 = findViewById(R.id.imageview88);
		imageview89 = findViewById(R.id.imageview89);
		imageview90 = findViewById(R.id.imageview90);
		imageview91 = findViewById(R.id.imageview91);
		imageview92 = findViewById(R.id.imageview92);
		imageview93 = findViewById(R.id.imageview93);
		imageview94 = findViewById(R.id.imageview94);
		
		imageview96.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		tablayout1.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
			@Override
			public void onTabSelected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				if (_position == 0) {
					aboutDevicePage.setVisibility(View.VISIBLE);
					aboutBatteryPage.setVisibility(View.GONE);
					appInfoPage.setVisibility(View.GONE);
				}
				else {
					if (_position == 1) {
						aboutDevicePage.setVisibility(View.GONE);
						aboutBatteryPage.setVisibility(View.VISIBLE);
						appInfoPage.setVisibility(View.GONE);
					}
					else {
						if (_position == 2) {
							aboutDevicePage.setVisibility(View.GONE);
							aboutBatteryPage.setVisibility(View.GONE);
							appInfoPage.setVisibility(View.VISIBLE);
						}
					}
				}
			}
			
			@Override
			public void onTabUnselected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				
			}
			
			@Override
			public void onTabReselected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				aboutBatteryPage.setBackgroundColor(0xFFFFFFFF);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								aboutBatteryPage.setBackgroundColor(Color.TRANSPARENT);
								_AdvancedBatteryV1(b_status, b_health, b_temperature, b_level);
							}
						});
					}
				};
				_timer.schedule(t, (int)(300));
			}
		});
	}
	
	private void initializeLogic() {
		textview59.setTextIsSelectable(true);
		
		vscroll1.setVerticalScrollBarEnabled(false);
		
		vscroll1.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
		
		_about_the_device__(textview59);
		_AdvancedBatteryV1(b_status, b_health, b_temperature, b_level);
		_aboutApp();
		tablayout1.addTab(tablayout1.newTab().setText("About your device "));
		tablayout1.addTab(tablayout1.newTab().setText("About your device battery "));
		tablayout1.addTab(tablayout1.newTab().setText("About app"));
		tablayout1.setSelectedTabIndicatorColor(0xFFFF0000);
		tablayout1.setSelectedTabIndicatorHeight(5);
		tablayout1.setTabTextColors(0xFFFFFFFF, 0xFFFF0000);
		tablayout1.setTabRippleColor(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_pressed}}, 
		
		new int[] {0xFF262626}));
	}
	
	@Override
	public void onStart() {
		super.onStart();
		
	}
	public void _about_the_device__(final TextView _textview) {
		
		_textview.setText("Build type: ".concat(Build.TYPE.concat("\n\n".concat("Build tags: ".concat(Build.TAGS.concat("\n\n".concat("Build user: ".concat(Build.USER.concat("\n\n".concat("Build unknown: ".concat(Build.UNKNOWN.concat("\n\n".concat("Build id: ".concat(Build.ID.concat("\n\n".concat("Build product: ".concat(Build.PRODUCT.concat("\n\n".concat("Build display: ".concat(Build.DISPLAY.concat("\n\n".concat("Build fingerprint: ".concat(Build.FINGERPRINT.concat("\n\n".concat("Build host: ".concat(Build.HOST.concat("\n\n".concat("Build CPU ABI: ".concat(Build.CPU_ABI.concat("\n\n".concat("Build hardware: ".concat(Build.HARDWARE.concat("\n\n".concat("Build serial: ".concat(Build.SERIAL.concat("\n\n".concat("Build radio: ".concat(Build.RADIO.concat("\n\n".concat("Build bootloader: ".concat(Build.BOOTLOADER.concat("\n\n".concat("Build board: ".concat(Build.BOARD.concat("\n\n".concat("Build security patch: ".concat(Build.VERSION.SECURITY_PATCH.concat("\n\n".concat("Build brand: ".concat(Build.BRAND.concat("\n\n".concat("Build SDK: ".concat(Build.VERSION.SDK.concat("\n\n".concat("Build model: ".concat(Build.MANUFACTURER.concat(" ".concat(Build.MODEL)).concat("\n\n".concat("Build release: ".concat(Build.VERSION.RELEASE.concat("\n\n".concat("Device language: ".concat(Locale.getDefault().getDisplayLanguage().concat("\n\n".concat(""))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))));
	}
	
	
	public void _AdvancedBatteryV1(final TextView _statusx, final TextView _bhealth, final TextView _btemp, final TextView _blevel) {
		BatteryManager blevelq = (BatteryManager)getSystemService(BATTERY_SERVICE);
		int blevelw = blevelq.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);//xenondry
		String blevele = Integer.toString(blevelw);
		_blevel.setText(blevele.concat("%"));
		BroadcastReceiver btempz = new BroadcastReceiver() {
				@Override
				public void onReceive(Context context, Intent intent) {
						float btempy = (float)(intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0))/10;
						_btemp.setText(btempy +" "+ (char) 0x00B0 +"C");
				}
		};
		IntentFilter btempx = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		getApplicationContext().registerReceiver(btempz,btempx);
		
		
		BroadcastReceiver healthbb = new BroadcastReceiver() {
				@Override
				public void onReceive(Context context, Intent intent) {
						int healthbc = intent.getIntExtra(BatteryManager.EXTRA_HEALTH,0);
						if (healthbc == BatteryManager.BATTERY_HEALTH_DEAD) {
								_bhealth.setText("Battery is dead");
						}
						if (healthbc == BatteryManager.BATTERY_HEALTH_GOOD) {
								_bhealth.setText("Battery is good");
						}
						if (healthbc == BatteryManager.BATTERY_HEALTH_OVERHEAT) {
								_bhealth.setText("Battery is overheat");
						}//xenondry
						if (healthbc == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE) {
								_bhealth.setText("Battery is over voltage");
						}
						if (healthbc == BatteryManager.BATTERY_HEALTH_UNKNOWN) {
								_bhealth.setText("Unknown battery health");
						}
						if (healthbc == BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE) {
								_bhealth.setText("Unspecified failure battery");
						}
				}
		};
		IntentFilter healthba = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		getApplicationContext().registerReceiver(healthbb,healthba);
		IntentFilter btstatus = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		
		Intent batteryStatus = registerReceiver(null, btstatus);
		
		int chargePlug = batteryStatus.getIntExtra(BatteryManager.EXTRA_PLUGGED,-1);
		
		boolean usbCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_USB;
		
		boolean acCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_AC;
		
		if(usbCharge){
			
			_statusx.setText("Device charging through USB");
			
		} else if(acCharge) {
			
			_statusx.setText("Device charging through AC" );
			
		} else {
			
			_statusx.setText("Device not charging");
			
		}
		
		
	}
	
	
	public void _aboutApp() {
		textview60.setText("GENERAL\n\n\nPackage name: com.inflps.codexyz\n\nApp Version: 5.0.1\n\nVersion code: 10\n\nApp relase: 10\n\nInstaller: com.google.android.packageinstaller\n\nApk source: Unknown\n\nTarget SDK: 28\n\nTarget android version: Android 9 Pie (And above)\n\nMin. SDK: 21\n\nMin. android version: Android 5.0 Lollipop \n\nApk path: /data/app/~~EVULFvGtKtSDWKL9aAoA2w==/com.inflps.codexyz-JXY-krnLxTXZsBsF4lcrRQ==/base.apk\n\nData path: /data/user/0/com.inflps.codexyz\n\nInstall location: Internal storage only\n\nApk size (Approximate): 8,3 MB (Non-Instaled)\n\n\n\n\nCERTIFICATE\n\n\nSign algorithm: SHA1withRSA\n\nValid From: 29.02.2008, 03:33\n\nValid to: 17.07.2035, 04:33\n\nCertificate MD5: e89b158e4bcf988ebd09eb83f5378e87\n\nIssuer name: Android\n\nIssuer organization: Android\n\nIssuer country: US\n\nSubject name: Android\n\nSubject organization: Android\n\nSubject country: US\n\n\n\nUSED PERMISSIONS\n\n\nandroid.permission.INTERNET\nandroid.permission.ACCESS_NETWORK_STATE\nandroid.permission.READ_EXTERNAL_STORAGE\nandroid.permission.WRITE_EXTERNAL_STORAGE\nandroid.permission.RECORD_AUDIO\nandroid.permission.MANAGE_EXTERNAL_STORAGE\nandroid.permission.QUERY_ALL_PACKAGES\nandroid.permission.REQUEST_DELETE_PACKAGES\nandroid.permission.VIBRATE\nandroid.permission.ACCESS_MEDIA_LOCATION\n\n\n\n");
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}