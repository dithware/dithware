package com.inflps.codexyz;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import com.google.android.material.appbar.AppBarLayout;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class MoreToolsActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private String fontName = "";
	private String typeace = "";
	
	private ScrollView vscroll1;
	private LinearLayout background;
	private LinearLayout linear52;
	private LinearLayout linear54;
	private LinearLayout linear56;
	private LinearLayout linear60;
	private LinearLayout linear62;
	private LinearLayout linear63;
	private LinearLayout linear68;
	private LinearLayout linear83;
	private ImageView imageview9;
	private TextView textview37;
	private ImageView imageview10;
	private TextView textview38;
	private ImageView imageview11;
	private TextView textview40;
	private ImageView imageview13;
	private TextView textview42;
	private ImageView imageview15;
	private LinearLayout linear65;
	private TextView textview44;
	private TextView textview48;
	private ImageView imageview16;
	private LinearLayout linear64;
	private TextView textview45;
	private TextView textview46;
	private ImageView imageview17;
	private LinearLayout linear69;
	private TextView textview53;
	private TextView textview54;
	private LinearLayout linear70;
	private LinearLayout linear73;
	private LinearLayout linear77;
	private LinearLayout linear79;
	private LinearLayout linear84;
	private LinearLayout linear75;
	private LinearLayout linear82;
	private LinearLayout linear81;
	private ImageView imageview88;
	private TextView textview56;
	private TextView textview66;
	private ImageView imageview89;
	private ImageView nwi1_1;
	private LinearLayout linear74;
	private TextView textview59;
	private TextView textview60;
	private ImageView nwi2_1;
	private LinearLayout linear78;
	private TextView textview63;
	private ImageView nwi3_1;
	private LinearLayout linear80;
	private TextView textview65;
	private ImageView imageview90;
	private LinearLayout linear85;
	private TextView textview67;
	private ImageView nwi4_1;
	private LinearLayout linear76;
	private TextView textview61;
	private TextView textview62;
	
	private Intent i = new Intent();
	private AlertDialog.Builder ph_info;
	private AlertDialog.Builder battery_info;
	private AlertDialog.Builder b_battery_level;
	private Intent baterylevel = new Intent();
	private Intent batterytemperature = new Intent();
	private SharedPreferences option;
	private SharedPreferences settings;
	private TimerTask t;
	private Intent ii = new Intent();
	private AlertDialog.Builder alert;
	private Intent run = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.more_tools);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = findViewById(R.id.vscroll1);
		background = findViewById(R.id.background);
		linear52 = findViewById(R.id.linear52);
		linear54 = findViewById(R.id.linear54);
		linear56 = findViewById(R.id.linear56);
		linear60 = findViewById(R.id.linear60);
		linear62 = findViewById(R.id.linear62);
		linear63 = findViewById(R.id.linear63);
		linear68 = findViewById(R.id.linear68);
		linear83 = findViewById(R.id.linear83);
		imageview9 = findViewById(R.id.imageview9);
		textview37 = findViewById(R.id.textview37);
		imageview10 = findViewById(R.id.imageview10);
		textview38 = findViewById(R.id.textview38);
		imageview11 = findViewById(R.id.imageview11);
		textview40 = findViewById(R.id.textview40);
		imageview13 = findViewById(R.id.imageview13);
		textview42 = findViewById(R.id.textview42);
		imageview15 = findViewById(R.id.imageview15);
		linear65 = findViewById(R.id.linear65);
		textview44 = findViewById(R.id.textview44);
		textview48 = findViewById(R.id.textview48);
		imageview16 = findViewById(R.id.imageview16);
		linear64 = findViewById(R.id.linear64);
		textview45 = findViewById(R.id.textview45);
		textview46 = findViewById(R.id.textview46);
		imageview17 = findViewById(R.id.imageview17);
		linear69 = findViewById(R.id.linear69);
		textview53 = findViewById(R.id.textview53);
		textview54 = findViewById(R.id.textview54);
		linear70 = findViewById(R.id.linear70);
		linear73 = findViewById(R.id.linear73);
		linear77 = findViewById(R.id.linear77);
		linear79 = findViewById(R.id.linear79);
		linear84 = findViewById(R.id.linear84);
		linear75 = findViewById(R.id.linear75);
		linear82 = findViewById(R.id.linear82);
		linear81 = findViewById(R.id.linear81);
		imageview88 = findViewById(R.id.imageview88);
		textview56 = findViewById(R.id.textview56);
		textview66 = findViewById(R.id.textview66);
		imageview89 = findViewById(R.id.imageview89);
		nwi1_1 = findViewById(R.id.nwi1_1);
		linear74 = findViewById(R.id.linear74);
		textview59 = findViewById(R.id.textview59);
		textview60 = findViewById(R.id.textview60);
		nwi2_1 = findViewById(R.id.nwi2_1);
		linear78 = findViewById(R.id.linear78);
		textview63 = findViewById(R.id.textview63);
		nwi3_1 = findViewById(R.id.nwi3_1);
		linear80 = findViewById(R.id.linear80);
		textview65 = findViewById(R.id.textview65);
		imageview90 = findViewById(R.id.imageview90);
		linear85 = findViewById(R.id.linear85);
		textview67 = findViewById(R.id.textview67);
		nwi4_1 = findViewById(R.id.nwi4_1);
		linear76 = findViewById(R.id.linear76);
		textview61 = findViewById(R.id.textview61);
		textview62 = findViewById(R.id.textview62);
		ph_info = new AlertDialog.Builder(this);
		battery_info = new AlertDialog.Builder(this);
		b_battery_level = new AlertDialog.Builder(this);
		option = getSharedPreferences("option", Activity.MODE_PRIVATE);
		settings = getSharedPreferences("settings", Activity.MODE_PRIVATE);
		alert = new AlertDialog.Builder(this);
		
		linear52.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				linear52.setBackgroundResource(R.drawable.material_7);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								linear52.setBackgroundResource(0);
							}
						});
					}
				};
				_timer.schedule(t, (int)(500));
				return true;
			}
		});
		
		linear52.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), CreateDialogActivity.class);
				startActivity(i);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			}
		});
		
		linear54.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				linear54.setBackgroundResource(R.drawable.material_7);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								linear54.setBackgroundResource(0);
							}
						});
					}
				};
				_timer.schedule(t, (int)(500));
				return true;
			}
		});
		
		linear54.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				batterytemperature.setClass(getApplicationContext(), PhoneInfoActivity.class);
				startActivity(batterytemperature);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			}
		});
		
		linear56.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				linear56.setBackgroundResource(R.drawable.material_7);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								linear56.setBackgroundResource(0);
							}
						});
					}
				};
				_timer.schedule(t, (int)(500));
				return true;
			}
		});
		
		linear56.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				baterylevel.setClass(getApplicationContext(), BatteryInfoActivity.class);
				startActivity(baterylevel);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			}
		});
		
		linear60.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				linear60.setBackgroundResource(R.drawable.material_7);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								linear60.setBackgroundResource(0);
							}
						});
					}
				};
				_timer.schedule(t, (int)(500));
				return true;
			}
		});
		
		linear60.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SourceCodeActivity.class);
				startActivity(i);
			}
		});
		
		linear62.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				linear62.setBackgroundResource(R.drawable.material_7);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								linear62.setBackgroundResource(0);
							}
						});
					}
				};
				_timer.schedule(t, (int)(500));
				return true;
			}
		});
		
		linear62.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				alert.setTitle("ㅤ");
				alert.setMessage("You have to wait a bit for the apps to load... it is possible that phone freezes or crashing!");
				alert.setPositiveButton("Continue ", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						i.setClass(getApplicationContext(), AppExtractorActivity.class);
						startActivity(i);
					}
				});
				alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				_CustomDialogMaterial(alert, true);
			}
		});
		
		linear63.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				linear63.setBackgroundResource(R.drawable.material_7);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								linear63.setBackgroundResource(0);
							}
						});
					}
				};
				_timer.schedule(t, (int)(500));
				return true;
			}
		});
		
		linear63.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), AppIcActivity.class);
				startActivity(i);
			}
		});
		
		linear68.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				linear68.setBackgroundResource(R.drawable.material_7);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								linear68.setBackgroundResource(0);
							}
						});
					}
				};
				_timer.schedule(t, (int)(500));
				return true;
			}
		});
		
		linear68.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), WebSourcecodeActivity.class);
				startActivity(i);
			}
		});
		
		linear73.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				linear73.setBackgroundResource(R.drawable.material_7);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								linear73.setBackgroundResource(0);
							}
						});
					}
				};
				_timer.schedule(t, (int)(500));
				return true;
			}
		});
		
		linear73.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (settings.getString("legacy", "").equals("t")) {
					
				}
				else {
					i.setClass(getApplicationContext(), TerminalActivity.class);
					startActivity(i);
				}
			}
		});
		
		linear77.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				linear77.setBackgroundResource(R.drawable.material_7);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								linear77.setBackgroundResource(0);
							}
						});
					}
				};
				_timer.schedule(t, (int)(500));
				return true;
			}
		});
		
		linear77.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (settings.getString("legacy", "").equals("t")) {
					
				}
				else {
					i.setClass(getApplicationContext(), TextRepeaterActivity.class);
					startActivity(i);
				}
			}
		});
		
		linear79.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				linear79.setBackgroundResource(R.drawable.material_7);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								linear79.setBackgroundResource(0);
							}
						});
					}
				};
				_timer.schedule(t, (int)(500));
				return true;
			}
		});
		
		linear79.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (settings.getString("legacy", "").equals("t")) {
					
				}
				else {
					i.setClass(getApplicationContext(), BinTranslatorActivity.class);
					startActivity(i);
				}
			}
		});
		
		linear84.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				linear84.setBackgroundResource(R.drawable.material_7);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								linear84.setBackgroundResource(0);
							}
						});
					}
				};
				_timer.schedule(t, (int)(500));
				return true;
			}
		});
		
		linear84.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				run.setClass(getApplicationContext(), HtmlPreviewActivity.class);
				run.putExtra("name", "nohtml");
				startActivity(run);
			}
		});
		
		linear75.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				linear75.setBackgroundResource(R.drawable.material_7);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								linear75.setBackgroundResource(0);
							}
						});
					}
				};
				_timer.schedule(t, (int)(500));
				return true;
			}
		});
		
		linear75.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (settings.getString("legacy", "").equals("t")) {
					
				}
				else {
					i.setClass(getApplicationContext(), HelpActivity.class);
					startActivity(i);
				}
			}
		});
		
		imageview89.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				linear81.setBackgroundResource(R.drawable.material_7);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								linear81.setBackgroundResource(0);
							}
						});
					}
				};
				_timer.schedule(t, (int)(500));
				return true;
			}
		});
		
		imageview89.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (settings.getString("legacy", "").equals("t")) {
					
				}
				else {
					option.edit().putString("hide", "t").commit();
					linear70.setVisibility(View.GONE);
				}
			}
		});
	}
	
	private void initializeLogic() {
		ph_info = new AlertDialog.Builder(this,AlertDialog.THEME_DEVICE_DEFAULT_DARK);
		setTitle("More tools");
		_initSlideActivity();
		
		vscroll1.setVerticalScrollBarEnabled(false);
		
		vscroll1.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
		
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (!option.getString("hide", "").equals("t")) {
			linear70.setVisibility(View.VISIBLE);
		}
		else {
			linear70.setVisibility(View.GONE);
		}
		if (settings.getString("beta", "").equals("t")) {
			linear83.setVisibility(View.VISIBLE);
		}
		else {
			linear83.setVisibility(View.GONE);
		}
	}
	public void _initSlideActivity() {
		getWindow().getDecorView().setBackgroundResource(android.R.color.transparent);
		ViewConfiguration vc = ViewConfiguration.get(this);
		MIN_DISTANCE = vc.getScaledTouchSlop();
		
		rootView =(ViewGroup)getWindow().findViewById(Window.ID_ANDROID_CONTENT);
		//converts percent to 0-225 range .
		maxAlpha =(int) ((225.0d/100.0d)* MAX_SCRIM_ALPHA); 
		try{
			convertFromTranslucent = Activity.class.getDeclaredMethod("convertFromTranslucent");         convertFromTranslucent.setAccessible(true);
			java.lang.reflect.Method getActivityOptions = Activity.class.getDeclaredMethod("getActivityOptions"); 	getActivityOptions.setAccessible(true);
			options = getActivityOptions.invoke(this);
				Class<?>[] classes = Activity.class.getDeclaredClasses();
			 Class<?> translucentConversionListenerClazz = null;
				for (Class clazz : classes) {
						if (clazz.getSimpleName().contains("TranslucentConversionListener")) {
								translucentConversionListenerClazz = clazz; 
						} 
				} 
				 convertToTranslucent = Activity.class.getDeclaredMethod("convertToTranslucent", translucentConversionListenerClazz, ActivityOptions.class);
				convertToTranslucent.setAccessible(true);
		} catch (Exception e) {
			showMessage(e.toString());
			 }
	}
	// Custom Variables
	//You can change it to color of your choice 
	private static final int SCRIM_COLOR = 0xFF000000;
	//Alpha is not taken into consideration while calculating scrim color  so it dosent matter .
	
	private static final int  SCRIM_R = Color.red(SCRIM_COLOR);
	private static final int SCRIM_G = Color.green(SCRIM_COLOR);
	private static final int  SCRIM_B = Color.blue(SCRIM_COLOR);
	private static final int MAX_SCRIM_ALPHA= 80;
	//in percentage
	private ViewGroup rootView ;
	private boolean enableSwipe= false;
	private boolean lockSwipe = false;
	private float downX;
	private float downY;
	private float MIN_DISTANCE ;
	private int maxAlpha;
	private java.lang.reflect.Method convertFromTranslucent;
	private java.lang.reflect.Method getActivityOptions;
	
	private Object options;
	
	private java.lang.reflect.Method convertToTranslucent;
	// Detect touch Events
	 @Override public boolean dispatchTouchEvent(MotionEvent event) { 
		switch(event.getAction()) { 
			case MotionEvent.ACTION_DOWN: 
			downX = event.getRawX();
			downY =event.getRawY();
			enableSwipe = false;
			lockSwipe = false;
			//convert activity to transparent
			try {
					convertToTranslucent.invoke(this, null, options); 
			} catch (Throwable t) {
			}
			break; 
			case MotionEvent.ACTION_MOVE: 
			if (!lockSwipe){
				if(enableSwipe){
					float translation = event.getRawX() -downX - MIN_DISTANCE;
					if (translation >= rootView.getWidth() || translation<= 0){
						rootView.setTranslationX(0);
					}else{
						rootView.setTranslationX(translation);
						//calculate distance scrolled in percentage
						int distanceInPercentage =(int)( ((double)translation/(double)rootView.getWidth())*100);
						
						//calculate alpha from distance in range 0 - maxAlpha
						
						int alpha =(int) ( ((double)maxAlpha/100.0d)*distanceInPercentage);
						
						//alpha will be greater when it is scrolled more this we do not need this but we need the inverse of it so subtract it from maxAlpha
						alpha = maxAlpha - alpha;
						
						int scrimColor = Color.argb(alpha,SCRIM_R,SCRIM_G,SCRIM_B);
						
						getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(scrimColor));
					}
				}else{
					if(Math.abs(event.getRawY() - downY) >= MIN_DISTANCE){
						enableSwipe = false;
						lockSwipe = true;
					}else{
						enableSwipe = event.getRawX() -downX >= MIN_DISTANCE;
					}
				}
			}
			break; 
			case MotionEvent.ACTION_UP: 
			if(rootView.getTranslationX() > rootView.getWidth() / 5){
				rootView.animate() 
				.translationX(rootView.getWidth())
				.setListener(
				new AnimatorListenerAdapter() { 
							@Override public void onAnimationEnd(Animator animation) { 
						
							super.onAnimationEnd(animation);
						finish();
						overridePendingTransition(0, 0);
						
					} });
			}else{
				rootView.animate() 
				.translationX(0)
				.setListener(
				new AnimatorListenerAdapter() { 
							@Override public void onAnimationEnd(Animator animation) { 
						super.onAnimationEnd(animation);
						// convert activity back to normal
						try {
							 convertFromTranslucent.invoke(this);
							        } catch (Throwable t) {}
					} });
				enableSwipe =false;
				lockSwipe = false;
			}
			break; 
			default:
			enableSwipe =false;
			lockSwipe = false;
			break; 
		}
		if (enableSwipe){
			event.setAction(MotionEvent.ACTION_CANCEL);
		}
		return super.dispatchTouchEvent(event);
	}
	
	{
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				}
				else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					}
					else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _blurTextView(final TextView _textview, final boolean _active) {
		//Code by X-Droid - This block is created by InfLps
		
		if (_active) {
				if (Build.VERSION.SDK_INT >= 11) {
						     _textview.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
				}
				float radius = _textview.getTextSize() / 3;
				BlurMaskFilter filter = new BlurMaskFilter(radius, BlurMaskFilter.Blur.NORMAL);
				_textview.getPaint().setMaskFilter(filter);
		}
		else {
				if (Build.VERSION.SDK_INT >= 11) {
						     _textview.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
				}
				float radius = _textview.getTextSize() / 1000;
				BlurMaskFilter filter = new BlurMaskFilter(radius, BlurMaskFilter.Blur.NORMAL);
				_textview.getPaint().setMaskFilter(filter);
		}
	}
	
	
	public void _MENU() {
	}
	@Override
	public boolean onCreateOptionsMenu (Menu menu){
		
		menu.add(0, 0, 0, "Settings").setIcon(R.drawable.ic_settings_white).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item){
		switch (item.getItemId()){
			case 0:
			ii.setClass(getApplicationContext(), SettingsActivity.class);
			startActivity(ii);
			overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			break;
		}
		return super.onOptionsItemSelected(item);
	}
	
	
	public void _CustomDialogMaterial(final AlertDialog.Builder _dial, final boolean _booleann) {
		
		setTheme(android.R.style.Theme_Material);
		_dial.setCancelable(_booleann);
		AlertDialog alert = _dial.show();
		alert.getWindow().getDecorView().setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, Color.parseColor("#252525")));
			alert.getWindow().getDecorView().setPadding(8,8,8,8);
		alert.show();
		
		alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#ff0000"));
			alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#ff0000"));
			alert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.parseColor("#ff0000"));
		alert.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
		alert.getWindow().getDecorView().setTranslationY(-20);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}