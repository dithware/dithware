package com.inflps.codexyz;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class PhoneInfoActivity extends AppCompatActivity {
	
	private LinearLayout linear99;
	private LinearLayout bg;
	private TextView textview1;
	private ScrollView vscroll1;
	private LinearLayout linear3;
	private LinearLayout linear1;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear81;
	private LinearLayout linear82;
	private LinearLayout linear83;
	private LinearLayout linear84;
	private LinearLayout linear85;
	private LinearLayout linear86;
	private LinearLayout linear87;
	private LinearLayout linear88;
	private LinearLayout linear89;
	private LinearLayout linear90;
	private LinearLayout linear91;
	private LinearLayout linear92;
	private LinearLayout linear93;
	private LinearLayout linear94;
	private LinearLayout linear95;
	private LinearLayout linear96;
	private LinearLayout linear97;
	private TextView textview6;
	private TextView b_type;
	private TextView textview8;
	private TextView b_tags;
	private TextView textview10;
	private TextView b_user;
	private TextView textview12;
	private TextView b_unknown;
	private TextView textview65;
	private TextView b_id;
	private TextView textview66;
	private TextView b_product;
	private TextView textview68;
	private TextView b_dispray;
	private TextView textview70;
	private TextView b_fingerprint;
	private TextView textview72;
	private TextView b_cpu_abi;
	private TextView textview74;
	private TextView b_host;
	private TextView textview76;
	private TextView b_hardware;
	private TextView textview78;
	private TextView b_serial;
	private TextView textview80;
	private TextView b_radio;
	private TextView textview82;
	private TextView b_bootloader;
	private TextView textview84;
	private TextView b_board;
	private TextView textview86;
	private TextView b_security_patch;
	private TextView textview88;
	private TextView b_brand;
	private TextView textview90;
	private TextView b_version_sdk;
	private TextView textview92;
	private TextView b_model;
	private TextView textview94;
	private TextView b_relase;
	private TextView textview96;
	private TextView d_language;
	private Button button1;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.phone_info);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear99 = findViewById(R.id.linear99);
		bg = findViewById(R.id.bg);
		textview1 = findViewById(R.id.textview1);
		vscroll1 = findViewById(R.id.vscroll1);
		linear3 = findViewById(R.id.linear3);
		linear1 = findViewById(R.id.linear1);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		linear81 = findViewById(R.id.linear81);
		linear82 = findViewById(R.id.linear82);
		linear83 = findViewById(R.id.linear83);
		linear84 = findViewById(R.id.linear84);
		linear85 = findViewById(R.id.linear85);
		linear86 = findViewById(R.id.linear86);
		linear87 = findViewById(R.id.linear87);
		linear88 = findViewById(R.id.linear88);
		linear89 = findViewById(R.id.linear89);
		linear90 = findViewById(R.id.linear90);
		linear91 = findViewById(R.id.linear91);
		linear92 = findViewById(R.id.linear92);
		linear93 = findViewById(R.id.linear93);
		linear94 = findViewById(R.id.linear94);
		linear95 = findViewById(R.id.linear95);
		linear96 = findViewById(R.id.linear96);
		linear97 = findViewById(R.id.linear97);
		textview6 = findViewById(R.id.textview6);
		b_type = findViewById(R.id.b_type);
		textview8 = findViewById(R.id.textview8);
		b_tags = findViewById(R.id.b_tags);
		textview10 = findViewById(R.id.textview10);
		b_user = findViewById(R.id.b_user);
		textview12 = findViewById(R.id.textview12);
		b_unknown = findViewById(R.id.b_unknown);
		textview65 = findViewById(R.id.textview65);
		b_id = findViewById(R.id.b_id);
		textview66 = findViewById(R.id.textview66);
		b_product = findViewById(R.id.b_product);
		textview68 = findViewById(R.id.textview68);
		b_dispray = findViewById(R.id.b_dispray);
		textview70 = findViewById(R.id.textview70);
		b_fingerprint = findViewById(R.id.b_fingerprint);
		textview72 = findViewById(R.id.textview72);
		b_cpu_abi = findViewById(R.id.b_cpu_abi);
		textview74 = findViewById(R.id.textview74);
		b_host = findViewById(R.id.b_host);
		textview76 = findViewById(R.id.textview76);
		b_hardware = findViewById(R.id.b_hardware);
		textview78 = findViewById(R.id.textview78);
		b_serial = findViewById(R.id.b_serial);
		textview80 = findViewById(R.id.textview80);
		b_radio = findViewById(R.id.b_radio);
		textview82 = findViewById(R.id.textview82);
		b_bootloader = findViewById(R.id.b_bootloader);
		textview84 = findViewById(R.id.textview84);
		b_board = findViewById(R.id.b_board);
		textview86 = findViewById(R.id.textview86);
		b_security_patch = findViewById(R.id.b_security_patch);
		textview88 = findViewById(R.id.textview88);
		b_brand = findViewById(R.id.b_brand);
		textview90 = findViewById(R.id.textview90);
		b_version_sdk = findViewById(R.id.b_version_sdk);
		textview92 = findViewById(R.id.textview92);
		b_model = findViewById(R.id.b_model);
		textview94 = findViewById(R.id.textview94);
		b_relase = findViewById(R.id.b_relase);
		textview96 = findViewById(R.id.textview96);
		d_language = findViewById(R.id.d_language);
		button1 = findViewById(R.id.button1);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
	}
	
	private void initializeLogic() {
		_dialogTheme();
		_initSlideActivity();
		bg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFF262626));
		_more();
		b_type.setText(Build.TYPE);
		b_tags.setText(Build.TAGS);
		b_user.setText(Build.USER);
		b_unknown.setText(Build.UNKNOWN);
		b_id.setText(Build.ID);
		b_product.setText(Build.PRODUCT);
		b_dispray.setText(Build.DISPLAY);
		b_fingerprint.setText(Build.FINGERPRINT);
		b_cpu_abi.setText(Build.CPU_ABI);
		b_host.setText(Build.HOST);
		b_hardware.setText(Build.HARDWARE);
		b_serial.setText(Build.SERIAL);
		b_radio.setText(Build.RADIO);
		b_bootloader.setText(Build.BOOTLOADER);
		b_board.setText(Build.BOARD);
		b_security_patch.setText(Build.VERSION.SECURITY_PATCH);
		b_brand.setText(Build.BRAND);
		b_version_sdk.setText(Build.VERSION.SDK);
		b_model.setText(Build.MANUFACTURER.concat(" ".concat(Build.MODEL)));
		b_relase.setText(Build.VERSION.RELEASE);
		d_language.setText(Locale.getDefault().getDisplayLanguage());
		
		
		vscroll1.setVerticalScrollBarEnabled(false);
		
		vscroll1.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
		
	}
	
	public void _dialogTheme() {
	}
	// setTheme() should be set before setContentView() so a small hack to do this in sketchware
	 @Override 
	    public void setContentView( int layoutResID) {
		if(getIntent().getBooleanExtra("dialogTheme",true)){
			supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
			setTheme(R.style.Theme_AppCompat_Light_Dialog);
			setFinishOnTouchOutside(false);
			
			//change true to false if you want to make dialog non cancellable when clicked outside
			//if you want to use this without app compat  change supportRequestWindowFeature() and setTheme() to below codes.
			/*
requestWindowFeature(Window.FEATURE_NO_TITLE);
setTheme(android.R.style.Theme_Dialog);
*/
			// Calling this allows the Activity behind this one to be seen again. Once all such Activities have been redrawn
			try {
				 	java.lang.reflect.Method getActivityOptions = Activity.class.getDeclaredMethod("getActivityOptions"); getActivityOptions.setAccessible(true);
				 Object options = getActivityOptions.invoke(this); Class<?>[] classes = Activity.class.getDeclaredClasses(); Class<?> translucentConversionListenerClazz = null; 
				for (Class clazz : classes) { if (clazz.getSimpleName().contains("TranslucentConversionListener")) { translucentConversionListenerClazz = clazz; } } 
				java.lang.reflect.Method convertToTranslucent = Activity.class.getDeclaredMethod("convertToTranslucent", translucentConversionListenerClazz, ActivityOptions.class); convertToTranslucent.setAccessible(true); convertToTranslucent.invoke(this, null, options); } catch (Throwable t) {
			}
		}
		super.setContentView(layoutResID);  
	}
	{
	}
	
	
	public void _initSlideActivity() {
		getWindow().getDecorView().setBackgroundResource(android.R.color.transparent);
		ViewConfiguration vc = ViewConfiguration.get(this);
		MIN_DISTANCE = vc.getScaledTouchSlop();
		
		rootView =(ViewGroup)getWindow().findViewById(Window.ID_ANDROID_CONTENT);
		//converts percent to 0-225 range .
		maxAlpha =(int) ((225.0d/100.0d)* MAX_SCRIM_ALPHA); 
		try{
			convertFromTranslucent = Activity.class.getDeclaredMethod("convertFromTranslucent");         convertFromTranslucent.setAccessible(true);
			java.lang.reflect.Method getActivityOptions = Activity.class.getDeclaredMethod("getActivityOptions"); 	getActivityOptions.setAccessible(true);
			options = getActivityOptions.invoke(this);
				Class<?>[] classes = Activity.class.getDeclaredClasses();
			 Class<?> translucentConversionListenerClazz = null;
				for (Class clazz : classes) {
						if (clazz.getSimpleName().contains("TranslucentConversionListener")) {
								translucentConversionListenerClazz = clazz; 
						} 
				} 
				 convertToTranslucent = Activity.class.getDeclaredMethod("convertToTranslucent", translucentConversionListenerClazz, ActivityOptions.class);
				convertToTranslucent.setAccessible(true);
		} catch (Exception e) {
			showMessage(e.toString());
			 }
	}
	// Custom Variables
	//You can change it to color of your choice 
	private static final int SCRIM_COLOR = 0xFF000000;
	//Alpha is not taken into consideration while calculating scrim color  so it dosent matter .
	
	private static final int  SCRIM_R = Color.red(SCRIM_COLOR);
	private static final int SCRIM_G = Color.green(SCRIM_COLOR);
	private static final int  SCRIM_B = Color.blue(SCRIM_COLOR);
	private static final int MAX_SCRIM_ALPHA= 80;
	//in percentage
	private ViewGroup rootView ;
	private boolean enableSwipe= false;
	private boolean lockSwipe = false;
	private float downX;
	private float downY;
	private float MIN_DISTANCE ;
	private int maxAlpha;
	private java.lang.reflect.Method convertFromTranslucent;
	private java.lang.reflect.Method getActivityOptions;
	
	private Object options;
	
	private java.lang.reflect.Method convertToTranslucent;
	// Detect touch Events
	 @Override public boolean dispatchTouchEvent(MotionEvent event) { 
		switch(event.getAction()) { 
			case MotionEvent.ACTION_DOWN: 
			downX = event.getRawX();
			downY =event.getRawY();
			enableSwipe = false;
			lockSwipe = false;
			//convert activity to transparent
			try {
					convertToTranslucent.invoke(this, null, options); 
			} catch (Throwable t) {
			}
			break; 
			case MotionEvent.ACTION_MOVE: 
			if (!lockSwipe){
				if(enableSwipe){
					float translation = event.getRawX() -downX - MIN_DISTANCE;
					if (translation >= rootView.getWidth() || translation<= 0){
						rootView.setTranslationX(0);
					}else{
						rootView.setTranslationX(translation);
						//calculate distance scrolled in percentage
						int distanceInPercentage =(int)( ((double)translation/(double)rootView.getWidth())*100);
						
						//calculate alpha from distance in range 0 - maxAlpha
						
						int alpha =(int) ( ((double)maxAlpha/100.0d)*distanceInPercentage);
						
						//alpha will be greater when it is scrolled more this we do not need this but we need the inverse of it so subtract it from maxAlpha
						alpha = maxAlpha - alpha;
						
						int scrimColor = Color.argb(alpha,SCRIM_R,SCRIM_G,SCRIM_B);
						
						getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(scrimColor));
					}
				}else{
					if(Math.abs(event.getRawY() - downY) >= MIN_DISTANCE){
						enableSwipe = false;
						lockSwipe = true;
					}else{
						enableSwipe = event.getRawX() -downX >= MIN_DISTANCE;
					}
				}
			}
			break; 
			case MotionEvent.ACTION_UP: 
			if(rootView.getTranslationX() > rootView.getWidth() / 5){
				rootView.animate() 
				.translationX(rootView.getWidth())
				.setListener(
				new AnimatorListenerAdapter() { 
							@Override public void onAnimationEnd(Animator animation) { 
						
							super.onAnimationEnd(animation);
						finish();
						overridePendingTransition(0, 0);
						
					} });
			}else{
				rootView.animate() 
				.translationX(0)
				.setListener(
				new AnimatorListenerAdapter() { 
							@Override public void onAnimationEnd(Animator animation) { 
						super.onAnimationEnd(animation);
						// convert activity back to normal
						try {
							 convertFromTranslucent.invoke(this);
							        } catch (Throwable t) {}
					} });
				enableSwipe =false;
				lockSwipe = false;
			}
			break; 
			default:
			enableSwipe =false;
			lockSwipe = false;
			break; 
		}
		if (enableSwipe){
			event.setAction(MotionEvent.ACTION_CANCEL);
		}
		return super.dispatchTouchEvent(event);
	}
	
	{
	}
	
	
	public void _more() {
		//select text
		b_type.setTextIsSelectable(true);
		b_tags.setTextIsSelectable(true);
		b_user.setTextIsSelectable(true);
		b_unknown.setTextIsSelectable(true);
		b_id.setTextIsSelectable(true);
		b_product.setTextIsSelectable(true);
		b_dispray.setTextIsSelectable(true);
		b_fingerprint.setTextIsSelectable(true);
		b_cpu_abi.setTextIsSelectable(true);
		b_host.setTextIsSelectable(true);
		b_hardware.setTextIsSelectable(true);
		b_serial.setTextIsSelectable(true);
		b_radio.setTextIsSelectable(true);
		b_bootloader.setTextIsSelectable(true);
		b_board.setTextIsSelectable(true);
		b_security_patch.setTextIsSelectable(true);
		b_brand.setTextIsSelectable(true);
		b_version_sdk.setTextIsSelectable(true);
		b_model.setTextIsSelectable(true);
		b_relase.setTextIsSelectable(true);
		d_language.setTextIsSelectable(true);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}