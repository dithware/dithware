package com.inflps.codexyz;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class MigrationActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private double number = 0;
	
	private LinearLayout content;
	private LinearLayout linear1;
	private TextView textview1;
	private LinearLayout linear9;
	private LinearLayout linear7;
	private LinearLayout linear3;
	private TextView textview2;
	private LinearLayout linear_box_b;
	private Button button1;
	private Button button4;
	
	private TimerTask timer;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.migration);
		initialize(_savedInstanceState);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		content = findViewById(R.id.content);
		linear1 = findViewById(R.id.linear1);
		textview1 = findViewById(R.id.textview1);
		linear9 = findViewById(R.id.linear9);
		linear7 = findViewById(R.id.linear7);
		linear3 = findViewById(R.id.linear3);
		textview2 = findViewById(R.id.textview2);
		linear_box_b = findViewById(R.id.linear_box_b);
		button1 = findViewById(R.id.button1);
		button4 = findViewById(R.id.button4);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				try {
					timer.cancel();
					finish();
				}
				catch (Exception e) {}
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/CodeX"));
				finish();
			}
		});
	}
	
	private void initializeLogic() {
		_dialogTheme();
		button1.setEnabled(true);
		button4.setEnabled(false);
		button1.setAlpha((float)(1));
		button4.setAlpha((float)(0.4d));
		rpb_b = new RingProgressBar(this);
		_ReplaceView(linear_box_b, rpb_b);
		{
					TableLayout.LayoutParams params = new TableLayout.LayoutParams();
					//params.height = android.widget.LinearLayout.LayoutParams.WRAP_CONTENT;
					//params.width = android.widget.LinearLayout.LayoutParams.WRAP_CONTENT;
					params.height = 75;
					params.width = 75;
					rpb_b.setLayoutParams(params);
		}
		rpb_b.setMax(100);
		rpb_b.setStyle(RingProgressBar.FILL);
		rpb_b.setRingColor(0xFFF00000);
		rpb_b.setRingProgressColor(0xFFF00000);
		rpb_b.setOnProgressListener(new RingProgressBar.OnProgressListener() {
					@Override
					public void progressToComplete() {
								showMessage("Complete");
					}
		});
	}
	RingProgressBar rpb_b;
	{
		//Progress begins
		try {
			timer.cancel();
		}
		catch (Exception e) {}
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (rpb_b.getProgress() == rpb_b.getMax()) {
							timer.cancel();
							button1.setEnabled(false);
							button4.setEnabled(true);
							button4.setAlpha((float)(1));
							button1.setAlpha((float)(0.4d));
							FileUtil.copyDir(FileUtil.getExternalStorageDir().concat("/CodeX/SWB"), FileUtil.getExternalStorageDir().concat("/CodeXYZ/Backups/SWB"));
						}
						else {
							if (rpb_b.getProgress() == 25) {
								rpb_b.setProgress((int)number);
								FileUtil.copyDir(FileUtil.getExternalStorageDir().concat("/CodeX/AppExtracted"), FileUtil.getExternalStorageDir().concat("/CodeXYZ/Backups/AppExtracted"));
								number++;
							}
							else {
								if (rpb_b.getProgress() == 50) {
									rpb_b.setProgress((int)number);
									FileUtil.copyDir(FileUtil.getExternalStorageDir().concat("/CodeX/Package"), FileUtil.getExternalStorageDir().concat("/CodeXYZ/Backups/Package"));
									number++;
								}
								else {
									if (rpb_b.getProgress() == 75) {
										rpb_b.setProgress((int)number);
										FileUtil.copyDir(FileUtil.getExternalStorageDir().concat("/CodeX/Projects"), FileUtil.getExternalStorageDir().concat("/CodeXYZ/Backups/Projects"));
										number++;
									}
									else {
										rpb_b.setProgress((int)number);
										number++;
									}
								}
							}
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(timer, (int)(0), (int)(100));
	}
	
	@Override
	public void onBackPressed() {
		
	}
	public void _Library() {
	}
	public static class RingProgressBar extends View {
				
				private Paint paint;
				private int width;
				private int height;
				private int result = 0;
				private float padding = 0;
				private int ringColor;
				private int ringProgressColor;
				private int textColor;
				private float textSize;
				private float ringWidth;
				private int max;
				private int progress;
				private boolean textIsShow;
				private int style;
				public static final int STROKE = 0;
				public static final int FILL = 1;
				private OnProgressListener mOnProgressListener;
				private int centre;
				private int radius;
				
				// styleable
				public final int[] RingProgressBar = new int[]{2130771968, 2130771969, 2130771970, 2130771971, 2130771972, 2130771973, 2130771974, 2130771975};
				public int RingProgressBar_max = 5;
				public int RingProgressBar_progress = 7;
				public int RingProgressBar_ringColor = 0;
				public int RingProgressBar_ringPadding = 8;
				public int RingProgressBar_ringProgressColor = 1;
				public int RingProgressBar_ringWidth = 2;
				public int RingProgressBar_style = 7;
				public int RingProgressBar_textColor = 3;
				public int RingProgressBar_textIsShow = 6;
				public int RingProgressBar_textSize = 4;
				
				public RingProgressBar(Context context) {
							
							this(context, null);
				}
				
				
				public RingProgressBar(Context context, AttributeSet attrs) {
							
							this(context, attrs, 0);
				}
				
				
				public RingProgressBar(Context context, AttributeSet attrs, int defStyle) {
							
							super(context, attrs, defStyle);
							paint = new Paint();
							result = dp2px(100);
							android.content.res.TypedArray mTypedArray = context.obtainStyledAttributes(attrs, RingProgressBar);
							
							ringColor = mTypedArray.getColor(RingProgressBar_ringColor, Color.BLACK);
							ringProgressColor = mTypedArray.getColor(RingProgressBar_ringProgressColor,
							Color.WHITE);
							textColor = mTypedArray.getColor(RingProgressBar_textColor, Color.BLACK);
							textSize = mTypedArray.getDimension(RingProgressBar_textSize, 16);
							ringWidth = mTypedArray.getDimension(RingProgressBar_ringWidth, 5);
							max = mTypedArray.getInteger(RingProgressBar_max, 100);
							textIsShow = mTypedArray.getBoolean(RingProgressBar_textIsShow, true);
							style = mTypedArray.getInt(RingProgressBar_style, 0);
							progress = mTypedArray.getInteger(RingProgressBar_progress, 0);
							padding = mTypedArray.getDimension(RingProgressBar_ringPadding, 5);
							
							mTypedArray.recycle();
				}
				
				@Override
				protected void onDraw(Canvas canvas) {
							
							super.onDraw(canvas);
							
							centre = getWidth() / 2;
							radius = (int) (centre - ringWidth / 2);
							drawCircle(canvas);
							drawTextContent(canvas);
							drawProgress(canvas);
				}
				
				private void drawCircle(Canvas canvas) {
							paint.setColor(ringColor);
							paint.setStyle(Paint.Style.STROKE);
							paint.setStrokeWidth(ringWidth);
							paint.setAntiAlias(true);
							canvas.drawCircle(centre, centre, radius, paint);
				}
				
				private void drawTextContent(Canvas canvas) {
							paint.setStrokeWidth(0);
							paint.setColor(textColor);
							paint.setTextSize(textSize);
							paint.setTypeface(Typeface.DEFAULT);
							int percent = (int) (((float) progress / (float) max) * 100);
							float textWidth = paint.measureText(percent + "%");
							if (textIsShow && /*percent != 0 &&*/ style == STROKE) {
										canvas.drawText(percent + "%", centre - textWidth / 2, centre + textSize / 2, paint);
							}
				}
				
				private void drawProgress(Canvas canvas) {
							paint.setStrokeWidth(ringWidth);
							paint.setColor(ringProgressColor);
							
							RectF strokeOval = new RectF(centre - radius, centre - radius, centre + radius,
							centre + radius);
							RectF fillOval = new RectF(centre - radius + ringWidth + padding,
							centre - radius + ringWidth + padding, centre + radius - ringWidth - padding,
							centre + radius - ringWidth - padding);
							
							switch (style) {
										case STROKE: {
													paint.setStyle(Paint.Style.STROKE);
													paint.setStrokeCap(Paint.Cap.ROUND);
													canvas.drawArc(strokeOval, -90, 360 * progress / max, false, paint);
													break;
										}
										case FILL: {
													paint.setStyle(Paint.Style.FILL_AND_STROKE);
													paint.setStrokeCap(Paint.Cap.ROUND);
													if (progress != 0) {
																canvas.drawArc(fillOval, -90, 360 * progress / max, true, paint);
													}
													break;
										}
							}
				}
				
				
				@Override
				protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
							
							super.onMeasure(widthMeasureSpec, heightMeasureSpec);
							int widthMode = MeasureSpec.getMode(widthMeasureSpec);
							int widthSize = MeasureSpec.getSize(widthMeasureSpec);
							int heightMode = MeasureSpec.getMode(heightMeasureSpec);
							int heightSize = MeasureSpec.getSize(heightMeasureSpec);
							
							if (widthMode == MeasureSpec.AT_MOST) {
										width = result;
							} else {
										width = widthSize;
							}
							
							if (heightMode == MeasureSpec.AT_MOST) {
										height = result;
							} else {
										height = heightSize;
							}
							setMeasuredDimension(width, height);
				}
				
				
				@Override
				protected void onSizeChanged(int w, int h, int oldw, int oldh) {
							
							super.onSizeChanged(w, h, oldw, oldh);
							width = w;
							height = h;
				}
				
				public synchronized int getMax() {
							
							return max;
				}
				
				public synchronized void setMax(int max) {
							
							if (max < 0) {
										throw new IllegalArgumentException("The max progress of 0");
							}
							this.max = max;
				}
				
				public synchronized int getProgress() {
							
							return progress;
				}
				
				public synchronized void setProgress(int progress) {
							
							if (progress < 0) {
										throw new IllegalArgumentException("The progress of 0");
							}
							if (progress > max) {
										progress = max;
							}
							if (progress <= max) {
										this.progress = progress;
										postInvalidate();
							}
							if (progress == max) {
										if (mOnProgressListener != null) {
													mOnProgressListener.progressToComplete();
										}
							}
				}
				
				public int getRingColor() {
							
							return ringColor;
				}
				
				public void setRingColor(int ringColor) {
							
							this.ringColor = ringColor;
				}
				
				public int getRingProgressColor() {
							
							return ringProgressColor;
				}
				
				public void setRingProgressColor(int ringProgressColor) {
							
							this.ringProgressColor = ringProgressColor;
				}
				
				public int getTextColor() {
							
							return textColor;
				}
				
				public void setTextColor(int textColor) {
							
							this.textColor = textColor;
				}
				
				public float getTextSize() {
							
							return textSize;
				}
				
				public void setTextSize(float textSize) {
							
							this.textSize = textSize;
				}
				
				public float getRingWidth() {
							
							return ringWidth;
				}
				
				public void setRingWidth(float ringWidth) {
							
							this.ringWidth = ringWidth;
				}
				
				public void setStyle(int style) {
					    
					    this.style = style;
				}
				
				public void setTextIsShow(boolean show) {
					    
					    this.textIsShow = show;
				}
				
				public int dp2px(int dp) {
							
							float density = getContext().getResources().getDisplayMetrics().density;
							return (int) (dp * density + 0.5f);
				}
				
				public interface OnProgressListener {
							
							void progressToComplete();
				}
				
				
				public void setOnProgressListener(OnProgressListener mOnProgressListener) {
							
							this.mOnProgressListener = mOnProgressListener;
				}
	}
	
	{
	}
	
	
	public void _ReplaceView(final View _from, final View _to) {
		ViewGroup parent = (ViewGroup) _from.getParent();
		int index = parent.indexOfChild(_from);
		parent.removeView(_from);
		parent.addView(_to, index);
	}
	
	
	public void _dialogTheme() {
	}
	// setTheme() should be set before setContentView() so a small hack to do this in sketchware
	 @Override 
	    public void setContentView( int layoutResID) {
		if(getIntent().getBooleanExtra("dialogTheme",true)){
			supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
			setTheme(R.style.Theme_AppCompat_Light_Dialog);
			setFinishOnTouchOutside(false);
			
			//change true to false if you want to make dialog non cancellable when clicked outside
			//if you want to use this without app compat  change supportRequestWindowFeature() and setTheme() to below codes.
			/*
requestWindowFeature(Window.FEATURE_NO_TITLE);
setTheme(android.R.style.Theme_Dialog);
*/
			// Calling this allows the Activity behind this one to be seen again. Once all such Activities have been redrawn
			try {
				 	java.lang.reflect.Method getActivityOptions = Activity.class.getDeclaredMethod("getActivityOptions"); getActivityOptions.setAccessible(true);
				 Object options = getActivityOptions.invoke(this); Class<?>[] classes = Activity.class.getDeclaredClasses(); Class<?> translucentConversionListenerClazz = null; 
				for (Class clazz : classes) { if (clazz.getSimpleName().contains("TranslucentConversionListener")) { translucentConversionListenerClazz = clazz; } } 
				java.lang.reflect.Method convertToTranslucent = Activity.class.getDeclaredMethod("convertToTranslucent", translucentConversionListenerClazz, ActivityOptions.class); convertToTranslucent.setAccessible(true); convertToTranslucent.invoke(this, null, options); } catch (Throwable t) {
			}
		}
		super.setContentView(layoutResID);  
	}
	{
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}