package com.inflps.codexyz;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import com.google.android.material.appbar.AppBarLayout;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class BinTranslatorActivity extends AppCompatActivity {
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private boolean mode = false;
	
	private LinearLayout linear1;
	private LinearLayout bgtoolbar;
	private LinearLayout linear8;
	private LinearLayout linear2;
	private LinearLayout toolbar;
	private ImageView imageview4;
	private ScrollView vscroll2;
	private LinearLayout linear4;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private TextView textview6;
	private LinearLayout materialbtn_withicon_bg;
	private TextView textview1;
	private ImageView imageview2;
	private TextView textview4;
	private EditText insert;
	private LinearLayout result;
	private TextView textview5;
	private EditText edittext2;
	private LinearLayout linear9;
	private ImageView imageview3;
	private ImageView imageview1;
	private ImageView materialbtn_icon;
	private TextView materialbtn_text;
	private TextView textview3;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.bin_translator);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = findViewById(R.id.linear1);
		bgtoolbar = findViewById(R.id.bgtoolbar);
		linear8 = findViewById(R.id.linear8);
		linear2 = findViewById(R.id.linear2);
		toolbar = findViewById(R.id.toolbar);
		imageview4 = findViewById(R.id.imageview4);
		vscroll2 = findViewById(R.id.vscroll2);
		linear4 = findViewById(R.id.linear4);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		textview6 = findViewById(R.id.textview6);
		materialbtn_withicon_bg = findViewById(R.id.materialbtn_withicon_bg);
		textview1 = findViewById(R.id.textview1);
		imageview2 = findViewById(R.id.imageview2);
		textview4 = findViewById(R.id.textview4);
		insert = findViewById(R.id.insert);
		result = findViewById(R.id.result);
		textview5 = findViewById(R.id.textview5);
		edittext2 = findViewById(R.id.edittext2);
		linear9 = findViewById(R.id.linear9);
		imageview3 = findViewById(R.id.imageview3);
		imageview1 = findViewById(R.id.imageview1);
		materialbtn_icon = findViewById(R.id.materialbtn_icon);
		materialbtn_text = findViewById(R.id.materialbtn_text);
		textview3 = findViewById(R.id.textview3);
		
		materialbtn_withicon_bg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Toast.makeText(getApplicationContext(), "Tutorial/Tips:\n• Enter text to convert your text to binary code.\n• Click swap button (←→) to convert otherwise.\n• Click Copy button to copy result/converted text/binary\n• Click Delete button to clear the result/converted text or binary.", Toast.LENGTH_LONG).show();
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!mode) {
					mode = true;
					textview4.setText("Binary");
					textview1.setText("Text");
					insert.setHint("Add text");
				}
				else {
					mode = false;
					textview4.setText("Text");
					textview1.setText("Binary");
					insert.setHint("Add binary code");
				}
				try {
					if (insert.getText().toString().equals("")) {
						_autoTransitionScroll(vscroll2);
						result.setVisibility(View.GONE);
					}
					else {
						_autoTransitionScroll(vscroll2);
						result.setVisibility(View.VISIBLE);
						if (mode) {
							String text = insert.getText().toString(); byte[] bytes = text.getBytes(); StringBuilder binary = new StringBuilder();
							
							for (byte b : bytes) {
								   int val = b;
								 	for (int i = 0; i < 8; i++) { 
									      binary.append((val & 128) == 0
									? 0 : 1);
									 		val <<= 1; }
								 	 	binary.append(' ');
							}
							
							edittext2.setText(binary);
							edittext2.setHint("Converted text/binary will appear here");
						}
						else {
							String biner = insert.getText().toString(); String hasil = ""; char nextChar;
							
							for(int i = 0; i <= biner.length()-8; i += 9) { 	nextChar = (char)Integer.parseInt(biner.substring(i, i+8), 2); 	hasil += nextChar; }
							
							edittext2.setText(String.valueOf(hasil)); 
							edittext2.setHint("Converted text/binary will appear here");
						}
					}
				}catch(Exception e){
					SketchwareUtil.showMessage(getApplicationContext(), "[Error/Wrong Input]\nCannot convert the binary code!");
					edittext2.setHint("[ERROR] Cannot convert the text/binary.");
				}
			}
		});
		
		insert.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				try {
					if (_charSeq.equals("")) {
						_autoTransitionScroll(vscroll2);
						result.setVisibility(View.GONE);
					}
					else {
						_autoTransitionScroll(vscroll2);
						result.setVisibility(View.VISIBLE);
						if (mode) {
							String text = insert.getText().toString(); byte[] bytes = text.getBytes(); StringBuilder binary = new StringBuilder();
							
							for (byte b : bytes) {
								   int val = b;
								 	for (int i = 0; i < 8; i++) { 
									      binary.append((val & 128) == 0
									? 0 : 1);
									 		val <<= 1; }
								 	 	binary.append(' ');
							}
							
							edittext2.setText(binary);
							edittext2.setHint("Converted text/binary will appear here");
						}
						else {
							String biner = insert.getText().toString(); String hasil = ""; char nextChar;
							
							for(int i = 0; i <= biner.length()-8; i += 9) { 	nextChar = (char)Integer.parseInt(biner.substring(i, i+8), 2); 	hasil += nextChar; }
							
							edittext2.setText(String.valueOf(hasil)); 
							edittext2.setHint("Converted text/binary will appear here");
						}
					}
				}catch(Exception e){
					SketchwareUtil.showMessage(getApplicationContext(), "[Error/Wrong Input]\nCannot convert the binary code!");
					edittext2.setHint("[ERROR] Cannot convert the text/binary.");
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				insert.setText("");
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", edittext2.getText().toString()));
				SketchwareUtil.showMessage(getApplicationContext(), "Copied to clipboard!");
			}
		});
	}
	
	private void initializeLogic() {
		setTitle("Binary converter");
		edittext2.setFocusable(false);
		insert.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, 0xFF558B2F));
		result.setVisibility(View.GONE);
		mode = true;
		_GradientDrawable(materialbtn_withicon_bg, 100, 0, 0, "#33691E", "#212121", true, false, 0);
		_advancedCorners(result, "#33691E", 0, 0, 50, 50);
		_SetCornerRadius(linear7, 50, 0, "#33691E");
	}
	
	public void _GradientDrawable(final View _view, final double _radius, final double _stroke, final double _shadow, final String _color, final String _borderColor, final boolean _ripple, final boolean _clickAnim, final double _animDuration) {
		if (_ripple) {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
			android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor("#82B1FF")});
			android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
			_view.setClickable(true);
			_view.setBackground(ripdrb);
		}
		else {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			_view.setBackground(gd);
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
		}
		if (_clickAnim) {
			_view.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()){
						case MotionEvent.ACTION_DOWN:{
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues(0.9f);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues(0.9f);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							break;
						}
						case MotionEvent.ACTION_UP:{
							
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues((float)1);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues((float)1);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							
							break;
						}
					}
					return false;
				}
			});
		}
	}
	
	
	public void _autoTransitionScroll(final View _scroll) {
		android.transition.TransitionManager.beginDelayedTransition((ScrollView)_scroll, new android.transition.AutoTransition());
	}
	
	
	public void _SetCornerRadius(final View _view, final double _radius, final double _shadow, final String _color) {
		android.graphics.drawable.GradientDrawable ab = new android.graphics.drawable.GradientDrawable();
		
		ab.setColor(Color.parseColor(_color));
		ab.setCornerRadius((float) _radius);
		_view.setElevation((float) _shadow);
		_view.setBackground(ab);
		
		
	}
	
	
	public void _advancedCorners(final View _view, final String _color, final double _n1, final double _n2, final double _n3, final double _n4) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		
		gd.setCornerRadii(new float[]{(int)_n1,(int)_n1,(int)_n2,(int)_n2,(int)_n4,(int)_n4,(int)_n3,(int)_n3});
		
		_view.setBackground(gd);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}