package com.inflps.codexyz;

import android.Manifest;
import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.media.SoundPool;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import com.bumptech.glide.Glide;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import com.arsenax.intentFilter.AIntentFilter;
import android.provider.*;

public class HomeActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private FloatingActionButton _fab;
	private DrawerLayout _drawer;
	private String info = "";
	private String Folder = "";
	private String UpFolder = "";
	private String AppPath = "";
	private String ACTIVATION_CODE = "";
	private String subtitle = "";
	private double position = 0;
	private String FileName = "";
	private String NewFile = "";
	private String inList = "";
	private String currentdir = "";
	private String fontName = "";
	private String typeace = "";
	private String DownFolder = "";
	private double sound = 0;
	private double appcheck = 0;
	private String package_Name = "";
	private String q = "";
	private String message1 = "";
	private String errormessage = "";
	private String ta = "";
	private String String_ta = "";
	
	private ArrayList<String> liststring = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> File_map = new ArrayList<>();
	
	private LinearLayout linear9;
	private LinearLayout linear11;
	private LinearLayout linear1;
	private LinearLayout actionbar2;
	private LinearLayout layout_main;
	private ImageView imageview9;
	private TextView textview22;
	private ImageView imageview10;
	private ImageView imageview1;
	private TextView textview1;
	private LinearLayout linear121;
	private ImageView imageview88;
	private TextView st;
	private ListView listview1;
	private LinearLayout linear12;
	private ImageView imageview11;
	private TextView textview23;
	private LinearLayout _drawer_linear1;
	private ScrollView _drawer_vscroll1;
	private LinearLayout _drawer_linear30;
	private LinearLayout _drawer_linear29;
	private LinearLayout _drawer_linear4;
	private LinearLayout _drawer_linear24;
	private LinearLayout _drawer_linear18;
	private LinearLayout _drawer_change_log;
	private LinearLayout _drawer_acknowledgement;
	private LinearLayout _drawer_report;
	private LinearLayout _drawer_about;
	private LinearLayout _drawer_buglog;
	private LinearLayout _drawer_clearcache;
	private ImageView _drawer_imageview1;
	private LinearLayout _drawer_linear26;
	private LinearLayout _drawer_linear28;
	private LinearLayout _drawer_linear25;
	private TextView _drawer_textview12;
	private TextView _drawer_textview13;
	private ImageView _drawer_YouTube;
	private ImageView _drawer_telegram;
	private ImageView _drawer_i4;
	private TextView _drawer_textview4;
	private ImageView _drawer_imageview2;
	private TextView _drawer_textview16;
	private ImageView _drawer_imageview8;
	private TextView _drawer_textview22;
	private ImageView _drawer_imageview5;
	private TextView _drawer_textview19;
	private ImageView _drawer_imageview11;
	private TextView _drawer_textview25;
	private ImageView _drawer_imageview10;
	private TextView _drawer_textview24;
	private TextView _drawer_tac;
	private LinearLayout _drawer_linear31;
	private TextView _drawer_privacy;
	private LinearLayout _drawer_linear32;
	private ImageView _drawer_settings_icon;
	
	private TimerTask timer;
	private AlertDialog.Builder PERMISSION;
	private Intent intent = new Intent();
	private SharedPreferences path;
	private AlertDialog.Builder CN;
	private Intent CText = new Intent();
	private AlertDialog.Builder DelFP;
	private AlertDialog.Builder RENAME;
	private TimerTask bb;
	private AlertDialog.Builder INFO;
	private AlertDialog.Builder DelP;
	private SharedPreferences ed;
	private Intent intent2 = new Intent();
	private AlertDialog.Builder CREATEFOLDER;
	private Intent i2 = new Intent();
	private Intent i = new Intent();
	private TimerTask refresh;
	private TimerTask refrh;
	private AlertDialog.Builder CREATEFOLDERP;
	private Intent n = new Intent();
	private AlertDialog.Builder sthx;
	private Intent ii = new Intent();
	private TimerTask t;
	private AlertDialog.Builder COMPRESS;
	private AlertDialog.Builder UNZIP;
	private Intent share = new Intent();
	private SharedPreferences settings;
	private AlertDialog.Builder p;
	private SoundPool soundpool;
	private Intent i3 = new Intent();
	private SharedPreferences ws;
	private AlertDialog.Builder info1;
	private ObjectAnimator load_fab = new ObjectAnimator();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_fab = findViewById(R.id._fab);
		
		_drawer = findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(HomeActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = findViewById(R.id._nav_view);
		
		linear9 = findViewById(R.id.linear9);
		linear11 = findViewById(R.id.linear11);
		linear1 = findViewById(R.id.linear1);
		actionbar2 = findViewById(R.id.actionbar2);
		layout_main = findViewById(R.id.layout_main);
		imageview9 = findViewById(R.id.imageview9);
		textview22 = findViewById(R.id.textview22);
		imageview10 = findViewById(R.id.imageview10);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		linear121 = findViewById(R.id.linear121);
		imageview88 = findViewById(R.id.imageview88);
		st = findViewById(R.id.st);
		listview1 = findViewById(R.id.listview1);
		linear12 = findViewById(R.id.linear12);
		imageview11 = findViewById(R.id.imageview11);
		textview23 = findViewById(R.id.textview23);
		_drawer_linear1 = _nav_view.findViewById(R.id.linear1);
		_drawer_vscroll1 = _nav_view.findViewById(R.id.vscroll1);
		_drawer_linear30 = _nav_view.findViewById(R.id.linear30);
		_drawer_linear29 = _nav_view.findViewById(R.id.linear29);
		_drawer_linear4 = _nav_view.findViewById(R.id.linear4);
		_drawer_linear24 = _nav_view.findViewById(R.id.linear24);
		_drawer_linear18 = _nav_view.findViewById(R.id.linear18);
		_drawer_change_log = _nav_view.findViewById(R.id.change_log);
		_drawer_acknowledgement = _nav_view.findViewById(R.id.acknowledgement);
		_drawer_report = _nav_view.findViewById(R.id.report);
		_drawer_about = _nav_view.findViewById(R.id.about);
		_drawer_buglog = _nav_view.findViewById(R.id.buglog);
		_drawer_clearcache = _nav_view.findViewById(R.id.clearcache);
		_drawer_imageview1 = _nav_view.findViewById(R.id.imageview1);
		_drawer_linear26 = _nav_view.findViewById(R.id.linear26);
		_drawer_linear28 = _nav_view.findViewById(R.id.linear28);
		_drawer_linear25 = _nav_view.findViewById(R.id.linear25);
		_drawer_textview12 = _nav_view.findViewById(R.id.textview12);
		_drawer_textview13 = _nav_view.findViewById(R.id.textview13);
		_drawer_YouTube = _nav_view.findViewById(R.id.YouTube);
		_drawer_telegram = _nav_view.findViewById(R.id.telegram);
		_drawer_i4 = _nav_view.findViewById(R.id.i4);
		_drawer_textview4 = _nav_view.findViewById(R.id.textview4);
		_drawer_imageview2 = _nav_view.findViewById(R.id.imageview2);
		_drawer_textview16 = _nav_view.findViewById(R.id.textview16);
		_drawer_imageview8 = _nav_view.findViewById(R.id.imageview8);
		_drawer_textview22 = _nav_view.findViewById(R.id.textview22);
		_drawer_imageview5 = _nav_view.findViewById(R.id.imageview5);
		_drawer_textview19 = _nav_view.findViewById(R.id.textview19);
		_drawer_imageview11 = _nav_view.findViewById(R.id.imageview11);
		_drawer_textview25 = _nav_view.findViewById(R.id.textview25);
		_drawer_imageview10 = _nav_view.findViewById(R.id.imageview10);
		_drawer_textview24 = _nav_view.findViewById(R.id.textview24);
		_drawer_tac = _nav_view.findViewById(R.id.tac);
		_drawer_linear31 = _nav_view.findViewById(R.id.linear31);
		_drawer_privacy = _nav_view.findViewById(R.id.privacy);
		_drawer_linear32 = _nav_view.findViewById(R.id.linear32);
		_drawer_settings_icon = _nav_view.findViewById(R.id.settings_icon);
		PERMISSION = new AlertDialog.Builder(this);
		path = getSharedPreferences("path", Activity.MODE_PRIVATE);
		CN = new AlertDialog.Builder(this);
		DelFP = new AlertDialog.Builder(this);
		RENAME = new AlertDialog.Builder(this);
		INFO = new AlertDialog.Builder(this);
		DelP = new AlertDialog.Builder(this);
		ed = getSharedPreferences("ed", Activity.MODE_PRIVATE);
		CREATEFOLDER = new AlertDialog.Builder(this);
		CREATEFOLDERP = new AlertDialog.Builder(this);
		sthx = new AlertDialog.Builder(this);
		COMPRESS = new AlertDialog.Builder(this);
		UNZIP = new AlertDialog.Builder(this);
		settings = getSharedPreferences("settings", Activity.MODE_PRIVATE);
		p = new AlertDialog.Builder(this);
		ws = getSharedPreferences("ws", Activity.MODE_PRIVATE);
		info1 = new AlertDialog.Builder(this);
		
		linear11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				View popupView = getLayoutInflater().inflate(R.layout.popup, null);
				
				final PopupWindow popup = new PopupWindow(popupView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
				LinearLayout lin_codex = popupView.findViewById(R.id.lin_codex);
				
				LinearLayout lin_documents = popupView.findViewById(R.id.lin_documents);
				
				LinearLayout lin_download = popupView.findViewById(R.id.lin_download);
				
				LinearLayout lin_pictures = popupView.findViewById(R.id.lin_pictures);
				
				LinearLayout lin_music = popupView.findViewById(R.id.lin_music);
				
				LinearLayout lin_internal = popupView.findViewById(R.id.lin_internal);
				lin_codex.setOnClickListener(new OnClickListener() { public void onClick(View view) {
						Folder = FileUtil.getExternalStorageDir().concat("/CodeXYZ");
						_RefreshData();
						if (settings.getString("sound", "").equals("t")) {
							sound = soundpool.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);
						}
						else {
							
						}
						popup.dismiss();
					} });
				
				lin_documents.setOnClickListener(new OnClickListener() { public void onClick(View view) {
						Folder = FileUtil.getExternalStorageDir().concat("/Documents");
						_RefreshData();
						if (settings.getString("sound", "").equals("t")) {
							sound = soundpool.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);
						}
						else {
							
						}
						popup.dismiss();
					} });
				
				lin_download.setOnClickListener(new OnClickListener() { public void onClick(View view) {
						Folder = FileUtil.getPublicDir(Environment.DIRECTORY_DOWNLOADS);
						_RefreshData();
						if (settings.getString("sound", "").equals("t")) {
							sound = soundpool.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);
						}
						else {
							
						}
						popup.dismiss();
					} });
				
				lin_pictures.setOnClickListener(new OnClickListener() { public void onClick(View view) {
						Folder = FileUtil.getPublicDir(Environment.DIRECTORY_PICTURES);
						if (liststring.size() == 0) {
								linear12.setVisibility(View.VISIBLE);
								listview1.setVisibility(View.GONE);
						}
						else {
								linear12.setVisibility(View.GONE);
								listview1.setVisibility(View.VISIBLE);
						}
						_RefreshData();
						if (settings.getString("sound", "").equals("t")) {
							sound = soundpool.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);
						}
						else {
							
						}
						popup.dismiss();
					} });
				
				lin_music.setOnClickListener(new OnClickListener() { public void onClick(View view) {
						Folder = FileUtil.getPublicDir(Environment.DIRECTORY_MUSIC);
						_RefreshData();
						if (settings.getString("sound", "").equals("t")) {
							sound = soundpool.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);
						}
						else {
							
						}
						popup.dismiss();
					} });
				
				lin_internal.setOnClickListener(new OnClickListener() { public void onClick(View view) {
						Folder = FileUtil.getExternalStorageDir();
						_RefreshData();
						if (settings.getString("sound", "").equals("t")) {
							sound = soundpool.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);
						}
						else {
							
						}
						popup.dismiss();
					} });
				
				popup.setAnimationStyle(android.R.style.Animation_Dialog);
				
				popup.showAsDropDown(imageview10, 0,0);
			}
		});
		
		linear1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				if (Folder.equals(FileUtil.getExternalStorageDir())) {
					_RefreshData();
				}
				else {
					Folder = FileUtil.getExternalStorageDir();
					if (liststring.size() == 0) {
							linear12.setVisibility(View.VISIBLE);
							listview1.setVisibility(View.GONE);
					}
					else {
							linear12.setVisibility(View.GONE);
							listview1.setVisibility(View.VISIBLE);
					}
					imageview88.setAlpha((float)(1));
					_RefreshData();
					if (settings.getString("sound", "").equals("t")) {
						sound = soundpool.play((int)(2), 1.0f, 1.0f, 1, (int)(2), 1.0f);
					}
					else {
						
					}
				}
				return true;
			}
		});
		
		linear1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Folder.equals(FileUtil.getExternalStorageDir())) {
					if (settings.getString("sound", "").equals("t")) {
						sound = soundpool.play((int)(4), 1.0f, 1.0f, 1, (int)(0), 1.0f);
					}
					else {
						
					}
				}
				else {
					DownFolder = Folder;
					UpFolder = Folder.substring((int)(0), (int)(Folder.lastIndexOf("/")));
					Folder = UpFolder;
					_RefreshData();
					imageview88.setAlpha((float)(1));
					if (settings.getString("sound", "").equals("t")) {
						sound = soundpool.play((int)(2), 1.0f, 1.0f, 1, (int)(0), 1.0f);
					}
					else {
						
					}
				}
			}
		});
		
		imageview88.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (DownFolder.equals("")) {
					
				}
				else {
					Folder = DownFolder;
					_RefreshData();
					imageview88.setAlpha((float)(0.5d));
				}
				if (settings.getString("sound", "").equals("t")) {
					sound = soundpool.play((int)(4), 1.0f, 1.0f, 1, (int)(0), 1.0f);
				}
				else {
					
				}
			}
		});
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				position = _position;
				if (FileUtil.isDirectory(liststring.get((int)(_position)))) {
					Folder = liststring.get((int)(_position));
					_openDir(Folder);
					DownFolder = Folder;
					imageview88.setAlpha((float)(0.5d));
				}
				else {
					if (liststring.get((int)(_position)).endsWith(".apk")) {
						try{
							_Intent_filter(liststring.get((int)(_position)), "application/vnd.android.package-archive");
						}catch(Exception e){
							SketchwareUtil.showMessage(getApplicationContext(), "app error");
						}
					}
					else {
						if (liststring.get((int)(_position)).endsWith(".zip")) {
							_Intent_filter(liststring.get((int)(_position)), "application/archive");
						}
						else {
							if (liststring.get((int)(_position)).endsWith(".pdf")) {
								try{
									_Intent_filter(liststring.get((int)(_position)), "application/pdf");
								}catch(Exception e){
									SketchwareUtil.showMessage(getApplicationContext(), "Could not open file...");
								}
							}
							else {
								intent.setClass(getApplicationContext(), PreviewActivity.class);
								startActivity(intent);
								path.edit().putString("title", Uri.parse(liststring.get((int)(_position))).getLastPathSegment()).commit();
								path.edit().putString("dat", liststring.get((int)(_position))).commit();
							}
						}
					}
				}
				if (settings.getString("sound", "").equals("t")) {
					sound = soundpool.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);
				}
				else {
					
				}
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				final
				com.google.android.material.bottomsheet.BottomSheetDialog bottomsheet = new com.google.android.material.bottomsheet.BottomSheetDialog(HomeActivity.this);
				
				View layout = getLayoutInflater().inflate(R.layout.bottom_sheet, null);
				
				bottomsheet.setContentView(layout);
				
				bottomsheet.show();
				
				LinearLayout base1 = (LinearLayout)layout.findViewById(R.id.base1);
				LinearLayout delete = (LinearLayout)layout.findViewById(R.id.delete);
				LinearLayout rename = (LinearLayout)layout.findViewById(R.id.rename);
				LinearLayout view = (LinearLayout)layout.findViewById(R.id.view);
				LinearLayout info = (LinearLayout)layout.findViewById(R.id.info);
				LinearLayout edit = (LinearLayout)layout.findViewById(R.id.edit);
				LinearLayout dirp = (LinearLayout)layout.findViewById(R.id.dirp);
				LinearLayout df = (LinearLayout)layout.findViewById(R.id.df);
				LinearLayout iff = (LinearLayout)layout.findViewById(R.id.iff);
				LinearLayout head = (LinearLayout)layout.findViewById(R.id.head);
				LinearLayout share = (LinearLayout)layout.findViewById(R.id.share);
				TextView t1 = (TextView)layout.findViewById(R.id.pathname);
				
				//UI
				_SX_CornerRadius_4(head, "#262626", "#262626", 0, 0, 0, 0, 0);
				
				
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				SketchUi.setColor(0xFF262626);SketchUi.setCornerRadii(new float[]{
					d*0,d*0,d*0 ,d*0,d*0,d*0 ,d*0,d*0});
				base1.setElevation(d*5);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFE0E0E0}), SketchUi, null);
				base1.setBackground(SketchUiRD);
				base1.setClickable(true);
				
				if (FileUtil.isDirectory(liststring.get((int)(_position)))) {
						base1.setVisibility(View.GONE);dirp.setVisibility(View.VISIBLE);
				}
				else {
							base1.setVisibility(View.VISIBLE);dirp.setVisibility(View.GONE);
				}
				
				if (settings.getString("beta", "").equals("t")) {
						edit.setVisibility(View.VISIBLE);
						share.setVisibility(View.VISIBLE);
				}
				else {
						edit.setVisibility(View.GONE);
						share.setVisibility(View.GONE);
				}
				t1.setText(Uri.parse(liststring.get((int)(_position))).getLastPathSegment());
				delete.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						bottomsheet.dismiss();
						DelFP.setTitle("Delete this file?".concat(" (".concat(Uri.parse(liststring.get((int)(_position))).getLastPathSegment().concat(")"))));
						DelFP.setMessage("It will simply be permanently deleted ...");
						DelFP.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								FileUtil.deleteFile(liststring.get((int)(_position)));
								_RefreshData();
								SketchwareUtil.showMessage(getApplicationContext(), "Deleted: ".concat(Uri.parse(liststring.get((int)(_position))).getLastPathSegment()));
								if (settings.getString("sound", "").equals("t")) {
									sound = soundpool.play((int)(5), 1.0f, 1.0f, 1, (int)(0), 1.0f);
								}
								else {
									
								}
							}
						});
						DelFP.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						_CustomDialogMaterial(DelFP, true);
					}
				});
				rename.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						
						bottomsheet.dismiss();
						
						RENAME.setTitle("Rename: ".concat(Uri.parse(liststring.get((int)(_position))).getLastPathSegment()));
						LinearLayout mylayout = new LinearLayout(HomeActivity.this);
						LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
						
						mylayout.setLayoutParams(params); mylayout.setOrientation(LinearLayout.VERTICAL);
						
						final EditText myedittext = new EditText(HomeActivity.this);
						myedittext.setLayoutParams(new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
						 
						mylayout.addView(myedittext);
						RENAME.setView(mylayout);
						myedittext.setHint("...");
						myedittext.setHintTextColor(0xFFE0E0E0);
						myedittext.setTextColor(0xFFFFFFFF);
						RENAME.setPositiveButton("Rename", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								NewFile = myedittext.getText().toString();
								FileUtil.moveFile(liststring.get((int)(_position)), Folder.concat("/").concat(NewFile));
								_RefreshData();
							}
						});
						RENAME.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						_CustomDialogMaterial(RENAME, false);
					}
				});
				share.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						
						bottomsheet.dismiss();
						
						if (FileUtil.isFile(liststring.get((int)(_position)))) {
							Intent share = new Intent(Intent.ACTION_SEND);
							share.setType("*/*");
							share.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new java.io.File(liststring.get((int)(_position)))));
							startActivity(Intent.createChooser(share, "Share File"));
						}
					}
				});
				view.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						
						bottomsheet.dismiss();
						
						intent.setClass(getApplicationContext(), PreviewActivity.class);
						startActivity(intent);
						path.edit().putString("title", Uri.parse(liststring.get((int)(_position))).getLastPathSegment()).commit();
						path.edit().putString("dat", liststring.get((int)(_position))).commit();
					}
				});
				info.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						
						bottomsheet.dismiss();
						
						INFO.setTitle("Info");
						INFO.setMessage("File name: ".concat(Uri.parse(liststring.get((int)(_position))).getLastPathSegment().concat("\n\nData: ".concat(liststring.get((int)(_position)).concat("")))));
						INFO.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						_CustomDialogMaterial(INFO, true);
					}
				});
				df.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						
						bottomsheet.dismiss();
						
						DelP.setTitle("Delete this folder?".concat(" (".concat(Uri.parse(liststring.get((int)(_position))).getLastPathSegment().concat(")"))));
						DelP.setMessage("This action cannot be undone!");
						DelP.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								FileUtil.deleteFile(liststring.get((int)(_position)));
								_RefreshData();
								SketchwareUtil.showMessage(getApplicationContext(), "Deleted");
								if (settings.getString("sound", "").equals("t")) {
									sound = soundpool.play((int)(5), 1.0f, 1.0f, 1, (int)(0), 1.0f);
								}
								else {
									
								}
							}
						});
						DelP.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						_CustomDialogMaterial(DelP, true);
					}
				});
				edit.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						
						bottomsheet.dismiss();
						
						intent.putExtra("Content", liststring.get((int)(_position)));
						intent.putExtra("Name", Uri.parse(liststring.get((int)(_position))).getLastPathSegment());
						intent.putExtra("Path", Folder);
						intent.setClass(getApplicationContext(), QuickEditorActivity.class);
						startActivity(intent);
					}
				});
				iff.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						
						bottomsheet.dismiss();
						
						INFO.setTitle("Info");
						INFO.setMessage("Folder name: ".concat(Uri.parse(liststring.get((int)(_position))).getLastPathSegment()));
						INFO.setPositiveButton("OK", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						_CustomDialogMaterial(INFO, true);
					}
				});
				return true;
			}
		});
		
		_fab.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				_RefreshData();
				if (settings.getString("sound", "").equals("t")) {
					sound = soundpool.play((int)(4), 1.0f, 1.0f, 1, (int)(0), 1.0f);
				}
				else {
					
				}
				_FabProgress(true);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								_FabProgress(false);
							}
						});
					}
				};
				_timer.schedule(t, (int)(750));
				return true;
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (_fab.getRotation()==0) {
					_showCustom(true);
				} else {
					_showCustom(false);
				};
			}
		});
		
		_drawer_change_log.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), ChangedLogActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			}
		});
		
		_drawer_acknowledgement.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), AcknowledgementsActivity.class);
				startActivity(intent);
			}
		});
		
		_drawer_report.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), ReportActivity.class);
				startActivity(intent);
			}
		});
		
		_drawer_about.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), AboutActivity.class);
				startActivity(intent);
			}
		});
		
		_drawer_buglog.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Folder = FileUtil.getExternalStorageDir().concat("/.inflps/CodeXYZ/LogBug");
				_RefreshData();
			}
		});
		
		_drawer_clearcache.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/CodeX/Temp"))) {
					FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/CodeX/Sketchware"));
					FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/CodeX/Temp"));
					_snackbar("Cleaned", "Dismiss");
				}
				else {
					_snackbar("There is no temporary file", "Dismiss");
				}
			}
		});
		
		_drawer_YouTube.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ii.setAction(Intent.ACTION_VIEW);
				ii.setData(Uri.parse("https://youtube.com/channel/UCPSmEt3ipljg69oeLRKBvxw"));
				startActivity(ii);
			}
		});
		
		_drawer_telegram.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ii.setAction(Intent.ACTION_VIEW);
				ii.setData(Uri.parse("https://t.me/infloops0000"));
				startActivity(ii);
			}
		});
		
		_drawer_tac.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), TacActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			}
		});
		
		_drawer_privacy.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), PrivacyActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			}
		});
		
		_drawer_settings_icon.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), SettingsActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			}
		});
	}
	
	private void initializeLogic() {
		_drawer.setScrimColor(Color.TRANSPARENT); ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(this, _drawer, R.string.app_name,
		R.string.app_name) {
			
			@Override
			public void onDrawerSlide (View drawerView, float slideOffset) {
				
				super.onDrawerSlide(drawerView, slideOffset);
				float slideX = drawerView.getWidth()
				* slideOffset; _coordinator.setTranslationX(slideX);
				;
			}
		};
		_drawer.addDrawerListener(_toggle);
		appcheck = SketchwareUtil.getRandom((int)(0), (int)(7));
		Folder = FileUtil.getExternalStorageDir().concat(AppPath);
		AppPath = "/CodeXYZ/Projects";
		if (!FileUtil.isExistFile(AppPath)) {
			FileUtil.makeDir(AppPath);
		}
		StrictMode.setVmPolicy(new
		StrictMode.VmPolicy.Builder().build());
		if(Build. VERSION.SDK_INT>=24){
			try{
				java.lang.reflect.Method
				m=StrictMode.class.getMethod(
				"disableDeathOnFileUriExposure");
				m.invoke(null);
			}
			catch(Exception e) {
				showMessage(e.toString());
			}
		}
		
		sthx = new AlertDialog.Builder(this,AlertDialog.THEME_DEVICE_DEFAULT_DARK);
		View cv = getLayoutInflater().inflate(R.layout.custom_fabs_view, null);
		
		linFab1 = (LinearLayout)cv.findViewById(R.id.lin1);
		linFab2 = (LinearLayout)cv.findViewById(R.id.lin2);
		linFab3 = (LinearLayout)cv.findViewById(R.id.lin3);
		
		
		textFab1 = (TextView)cv.findViewById(R.id.textview1);
		textFab2 = (TextView)cv.findViewById(R.id.textview2);
		textFab3 = (TextView)cv.findViewById(R.id.textview3);
		
		
		imgFab1 = (ImageView)cv.findViewById(R.id.imageview1);
		imgFab2 = (ImageView)cv.findViewById(R.id.imageview2);
		imgFab3 = (ImageView)cv.findViewById(R.id.imageview3);
		
		
		final LinearLayout l1 = (LinearLayout)cv.findViewById(R.id.linear1);
		
		_removeView(l1);
		
		((ViewGroup)_fab.getParent()).addView(l1);
		_setup(textFab1, "#CB0000");
		_setup(textFab2, "#CB0000");
		_setup(textFab3, "#CB0000");
		
		_setup(imgFab1, "#FF0000");
		_setup(imgFab2, "#FF0000");
		_setup(imgFab3, "#FF0000");
		textFab1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				i2.setClass(getApplicationContext(), MoreToolsActivity.class);
				startActivity(i2);
			}
		});
		
		imgFab1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				i2.setClass(getApplicationContext(), MoreToolsActivity.class);
				startActivity(i2);
			}
		});
		textFab2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				intent.putExtra("pathLocation", Folder);
				intent.putExtra("cl", "t");
				intent.setClass(getApplicationContext(), CreateFolderActivity.class);
				startActivity(intent);
			}
		});
		
		imgFab2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				intent.putExtra("pathLocation", Folder);
				intent.putExtra("cl", "t");
				intent.setClass(getApplicationContext(), CreateFolderActivity.class);
				startActivity(intent);
			}
		});
		textFab3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				intent.putExtra("path", Folder);
				intent.putExtra("cl", "t");
				intent.setClass(getApplicationContext(), CreateDialogActivity.class);
				startActivity(intent);
			}
		});
		
		imgFab3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				intent.putExtra("path", Folder);
				intent.putExtra("cl", "t");
				intent.setClass(getApplicationContext(), CreateDialogActivity.class);
				startActivity(intent);
			}
		});
		linFab1.setTranslationY(getDip(50));
		linFab1.setAlpha(0);
		linFab2.setTranslationY(getDip(50));
		linFab2.setAlpha(0);
		linFab3.setTranslationY(getDip(50));
		linFab3.setAlpha(0);
		_collapsingToolbar(listview1);
		final androidx.swiperefreshlayout.widget.SwipeRefreshLayout refreshable = new androidx.swiperefreshlayout.widget.SwipeRefreshLayout(HomeActivity.this);
		refreshable.setLayoutParams(
		new LinearLayout.LayoutParams(
		LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT)
		);
		layout_main.addView(refreshable);
		layout_main.removeView(listview1);
		refreshable.addView(listview1);
		refreshable.setOnRefreshListener(new androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener(){
			public void onRefresh(){
				_RefreshData();
				if (Build.VERSION.SDK_INT >= 30) {
					if (Environment.isExternalStorageManager()) {
						
					}
					else {
						p.setTitle("Access all files permission");
						p.setMessage("Please grant app permission to access all files");
						p.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								try {
										Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
										intent.setData(Uri.parse(String.format("package:%s", getApplicationContext().getPackageName())));
										startActivityForResult(intent, 2296);
										
								} catch (Exception e) {
										
										Intent intent = new Intent();
										intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
										startActivityForResult(intent, 2296);
								}
								
							}
						});
						_CustomDialogMaterial(p, false);
					}
				}
				refreshable.setRefreshing(false);
			}});
		imageview88.setAlpha((float)(0.5d));
		soundpool = new SoundPool((int)(4), AudioManager.STREAM_MUSIC, 0);
		sound = soundpool.load(getApplicationContext(), R.raw.open, 1);
		sound = soundpool.load(getApplicationContext(), R.raw.out, 1);
		sound = soundpool.load(getApplicationContext(), R.raw.breeb, 1);
		sound = soundpool.load(getApplicationContext(), R.raw.tick, 1);
		sound = soundpool.load(getApplicationContext(), R.raw.whoosh, 1);
		if (settings.getString("scroll", "").equals("t")) {
			listview1.setFastScrollEnabled(true);
		}
		else {
			listview1.setFastScrollEnabled(false);
		}
		if (!settings.getString("imnotgoingtounistall", "").equals("t")) {
			if (appcheck == 5) {
				// Checking if old app is still installed in this device
				_CheckIfInstalled("com.inflps.codex", "", "");
			}
		}
		else {
			
		}
		_CheckPermission();
		linear12.setVisibility(View.VISIBLE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		try{
				if (Build.VERSION.SDK_INT >= 30) {
						st.setVisibility(View.VISIBLE);
						if (_requestCode == 2296) {
								if (Environment.isExternalStorageManager()) {
										st.setTextColor(0xFF4CAF50);
								}
								else {
										st.setTextColor(0xFFF44336);
								}
						}
				}
				else {
						st.setVisibility(View.GONE);
				}
		}catch(Exception e){
				 
		}
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (Folder.equals(FileUtil.getExternalStorageDir())) {
			finishAffinity();
		}
		else {
			imageview88.setAlpha((float)(1));
			UpFolder = Folder.substring((int)(0), (int)(Folder.lastIndexOf("/")));
			Folder = UpFolder;
			_RefreshData();
			if (settings.getString("sound", "").equals("t")) {
				sound = soundpool.play((int)(2), 1.0f, 1.0f, 1, (int)(0), 1.0f);
			}
			else {
				
			}
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		appcheck = SketchwareUtil.getRandom((int)(0), (int)(5));
		_dialogTh();
		if (Build.VERSION.SDK_INT >= 30) {
			if (Environment.isExternalStorageManager()) {
				
			}
			else {
				p.setTitle("Access all files permission");
				p.setMessage("Please grant app permission to access all files");
				p.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						try {
								Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
								intent.setData(Uri.parse(String.format("package:%s", getApplicationContext().getPackageName())));
								startActivityForResult(intent, 2296);
								
						} catch (Exception e) {
								
								Intent intent = new Intent();
								intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
								startActivityForResult(intent, 2296);
						}
						
					}
				});
				_CustomDialogMaterial(p, false);
			}
		}
		if (!settings.getString("imnotgoingtounistall", "").equals("t")) {
			if (appcheck == 3) {
				// Checking if old app is still installed in this device
				_CheckIfInstalled("com.inflps.codex", "", "");
			}
		}
		else {
			
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		if (settings.getString("sound", "").equals("t")) {
			sound = soundpool.play((int)(3), 1.0f, 1.0f, 1, (int)(0), 1.0f);
		}
		else {
			
		}
		appcheck = SketchwareUtil.getRandom((int)(0), (int)(3));
		if (!settings.getString("imnotgoingtounistall", "").equals("t")) {
			if (appcheck == 2) {
				// Checking if old app is still installed in this device
				_CheckIfInstalled("com.inflps.codex", "", "");
			}
		}
		else {
			
		}
		_FabProgress(false);
	}
	
	
	@Override
	public void onPause() {
		super.onPause();
		_FabProgress(true);
	}
	
	@Override
	public void onStop() {
		super.onStop();
		_FabProgress(true);
	}
	public void _CheckPermission() {
		final AlertDialog.Builder alert = new
		AlertDialog.Builder(this);
		View pre = getLayoutInflater().inflate(R.layout.progress_dialog,null);
		alert.setView(pre); 
		final AlertDialog dialog = alert.create ();
		dialog.setCancelable (false);
		dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			dialog.show();
			timer = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							PERMISSION.setTitle("Error [109]");
							PERMISSION.setMessage("Please check always denied permission.");
							PERMISSION.setPositiveButton("Grant permission ", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface _dialog, int _which) {
									//request permission again
									requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
								}
							});
							PERMISSION.setNegativeButton("Dismiss ", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface _dialog, int _which) {
									_CheckPermission();
								}
							});
							_CustomDialogMaterial(PERMISSION, false);
						}
					});
				}
			};
			_timer.schedule(timer, (int)(3500));
		}else{
			Folder = FileUtil.getExternalStorageDir();
			ACTIVATION_CODE = String.valueOf((long)(SketchwareUtil.getRandom((int)(100000), (int)(1000000))));
			_RefreshData();
			if (listview1.getAdapter () == null) {
				
			}
			else {
				if (listview1.getAdapter ().getCount () == 0) {
					
				}
				else {
					dialog.dismiss ();
				}
			}
		}
	}
	
	
	public void _RefreshData() {
		listview1.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE); listview1.setItemsCanFocus(false);
		File_map.clear();
		subtitle = Folder;
		textview22.setText(subtitle);
		//getSupportActionBar().setSubtitle(Folder);
		FileUtil.listDir(Folder, liststring);
		Collections.sort(liststring, String.CASE_INSENSITIVE_ORDER);
		position = 0;
		for(int _repeat14 = 0; _repeat14 < (int)(liststring.size()); _repeat14++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("file", liststring.get((int)(position)));
				File_map.add(_item);
			}
			
			position++;
		}
		listview1.setAdapter(new Listview1Adapter(File_map));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	
	public void _removeView(final View _view) {
		if (_view.getParent() != null) ((ViewGroup)_view.getParent()).removeView(_view);
	}
	
	
	public void _setRipple(final View _a, final String _b, final double _c, final String _d) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_b));
		gd.setCornerRadius((float)_c);
		android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor(_d)});
		android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
		_a.setClickable(true);
		_a.setClipToOutline(true);
		_a.setBackground(ripdrb);
	}
	
	
	public void _setup(final View _a, final String _b) {
		_setRipple(_a, _b, SketchwareUtil.getDip(getApplicationContext(), (int)(18)), "#FFFFFF");
		_a.setElevation(4f);
	}
	
	
	public void _showCustom(final boolean _show) {
		_fab.clearAnimation();
		linFab1.clearAnimation();
		linFab2.clearAnimation();
		linFab3.clearAnimation();
		if (_show) {
			_fab.animate().setDuration(100).rotation(45);
			linFab1.setVisibility(View.VISIBLE);
			linFab2.setVisibility(View.VISIBLE);
			linFab3.setVisibility(View.VISIBLE);
			linFab1.animate().setDuration(100).alpha(1f).translationY(0).withEndAction(new Runnable() {
				@Override public void run() {
					
					linFab2.animate().setDuration(100).alpha(1f).translationY(0).withEndAction(new Runnable() {
						@Override public void run() {
							
							linFab3.animate().setDuration(100).alpha(1f).translationY(0);
							
						}
					});
					
				}
			});
		}
		else {
			_fab.animate().setDuration(100).rotation(0);
			linFab3.animate().setDuration(100).alpha(0).translationY(getDip(50)).withEndAction(new Runnable() {
				@Override public void run() {
					
					linFab2.animate().setDuration(100).alpha(0).translationY(getDip(50)).withEndAction(new Runnable() {
						@Override public void run() {
							
							linFab1.animate().setDuration(100).alpha(0).translationY(getDip(50)).withEndAction(new Runnable() {
								@Override public void run() {
									
									linFab1.setVisibility(View.GONE);
									linFab2.setVisibility(View.GONE);
									linFab3.setVisibility(View.GONE);
									
								}
							});
							
						}
					});
					
				}
			});
			
		}
	}
	
	
	public void _init() {
	}
	
	private LinearLayout linFab1, linFab2, linFab3;
	
	private TextView textFab1, textFab2, textFab3;
	
	private ImageView imgFab1, imgFab2, imgFab3;
	
	{
	}
	
	
	public void _dialogTh() {
		
	}
	
	
	public void _openDir(final String _path) {
		if (!_path.equals("")) {
			if (FileUtil.isExistFile(_path)) {
				if (new java.io.File(_path).canRead()) {
					if (FileUtil.isDirectory(_path)) {
						liststring.clear();
						File_map.clear();
						Folder = _path.trim();
						_RefreshData();
					}
					else {
						
					}
				}
				else {
					if (_path.trim().startsWith("/storage")) {
						textview23.setText("To access this folder,\nyou need to grant access\nto this folder");
						linear12.setVisibility(View.VISIBLE);
					}
					else {
						textview23.setText("Inaccessible directory");
						linear12.setVisibility(View.VISIBLE);
					}
				}
			}
		}
		else {
			if (FileUtil.isExistFile(_path.trim())) {
				textview23.setText("This directory doesn't even exist");
				linear12.setVisibility(View.VISIBLE);
			}
		}
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				}
				else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					}
					else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _SX_CornerRadius_4(final View _view, final String _color1, final String _color2, final double _str, final double _n1, final double _n2, final double _n3, final double _n4) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		
		gd.setColor(Color.parseColor(_color1));
		
		gd.setStroke((int)_str, Color.parseColor(_color2));
		
		gd.setCornerRadii(new float[]{(int)_n1,(int)_n1,(int)_n2,(int)_n2,(int)_n3,(int)_n3,(int)_n4,(int)_n4});
		
		_view.setBackground(gd);
		
		_view.setElevation(2);
	}
	
	
	public void _collapsingToolbar(final View _scroll) {
		try {
				com.google.android.material.appbar.AppBarLayout.LayoutParams params = (com.google.android.material.appbar.AppBarLayout.LayoutParams)_toolbar.getLayoutParams();
				params.setScrollFlags(com.google.android.material.appbar.AppBarLayout.LayoutParams.SCROLL_FLAG_SCROLL | com.google.android.material.appbar.AppBarLayout.LayoutParams.SCROLL_FLAG_ENTER_ALWAYS | com.google.android.material.appbar.AppBarLayout.LayoutParams.SCROLL_FLAG_SNAP);
				androidx.core.widget.NestedScrollView nestedScrollView = new androidx.core.widget.NestedScrollView(this);
				
				LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
				nestedScrollView.setLayoutParams(layoutParams);
				androidx.core.view.ViewCompat.setNestedScrollingEnabled(_scroll, true);
		} catch(Exception e) {
		}
	}
	
	
	public void _CustomDialogMaterial(final AlertDialog.Builder _dial, final boolean _booleann) {
		
		setTheme(android.R.style.Theme_Material);
		_dial.setCancelable(_booleann);
		AlertDialog alert = _dial.show();
		alert.getWindow().getDecorView().setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, Color.parseColor("#252525")));
			alert.getWindow().getDecorView().setPadding(8,8,8,8);
		alert.show();
		
		alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#ff0000"));
			alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#ff0000"));
			alert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.parseColor("#ff0000"));
		alert.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
		alert.getWindow().getDecorView().setTranslationY(-20);
	}
	
	
	public void _getApkIcon(final String _path, final ImageView _imageview) {
		android.content.pm.PackageManager packageManager = this.getPackageManager();
		android.content.pm.PackageInfo packageInfo = packageManager.getPackageArchiveInfo(_path, 0);
		packageInfo.applicationInfo.sourceDir = _path;
		packageInfo.applicationInfo.publicSourceDir = _path;
		_imageview.setImageDrawable(packageInfo.applicationInfo.loadIcon(packageManager));
		packageInfo = null;
		packageManager = null;
	}
	
	
	public void _setImageFromFile(final ImageView _img, final String _path) {
		
		java.io.File file = new java.io.File(_path);
		Uri imageUri = Uri.fromFile(file);
		
		Glide.with(getApplicationContext ()).load(imageUri).into(_img);
	}
	
	
	public double _getFolderSize(final String _path) {
		/*
//coded by stackoverflow
//modified and improved by arabware
//this can make mistakes on some cases , it may not give the real size of a folder
*/
		file = new java.io.File(_path);
		    if (file == null || !file.exists())
		        return 0;
		    if (!file.isDirectory())
		        return file.length();
		    final List<java.io.File> dirs = new LinkedList<>();
		    dirs.add(file);
		    long result = 0;
		    while (!dirs.isEmpty()) {
			        final java.io.File dir = dirs.remove(0);
			        if (!dir.exists())
			            continue;
			        final java.io.File[] listFiles = dir.listFiles();
			        if (listFiles == null || listFiles.length == 0)
			            continue;
			        for (final java.io.File child : listFiles) {
				            result += child.length();
				            if (child.isDirectory())
				                dirs.add(child);
				        }
			    }
		    return result;
		}
		private java.io.File file;
		{
	}
	
	
	public void _formatBytes(final String _bytes, final TextView _textview) {
		if (Double.parseDouble(_bytes) > 109951162777d) {
			String formatTB = String.valueOf(Double.parseDouble(_bytes) / 1024 / 1024 / 1024 / 1024);
			_textview.setText(formatTB.substring((int)(0), (int)(formatTB.lastIndexOf(".") + 3)) + " TB");
		}
		else {
			if (Double.parseDouble(_bytes) > 1073741824) {
				String formatGB = String.valueOf(Double.parseDouble(_bytes) / 1024 / 1024 / 1024);
				_textview.setText(formatGB.substring((int)(0), (int)(formatGB.lastIndexOf(".") + 3)) + " GB");
			}
			else {
				if (Double.parseDouble(_bytes) > (1024 * 1024)) {
					String formatMB = String.valueOf(Double.parseDouble(_bytes) / 1024 / 1024);
					_textview.setText(formatMB + " MB");
				}
				else {
					String formatKB = String.valueOf(Double.parseDouble(_bytes) / 1024 );
					_textview.setText(formatKB + " KB");
				}
			}
		}
	}
	
	
	public void _getMP4Thumbnail(final String _path, final ImageView _img) {
		//By Nexus Dev!
		//please give a ♥️ in Sketchub, if that i won't be able to post but project without at least getting a ♥️!
		
		android.graphics.Bitmap thumb = android.media.ThumbnailUtils.createVideoThumbnail(_path, android.provider.MediaStore.Images.Thumbnails.MINI_KIND);
		_img.setImageBitmap(thumb);
	}
	
	
	public void _comment(final String _c) {
		
	}
	
	
	public void _snackbar(final String _text, final String _dismiss) {
		com.google.android.material.snackbar.Snackbar sb = com.google.android.material.snackbar.Snackbar.make(linear1, _text, com.google.android.material.snackbar.Snackbar.LENGTH_LONG).setDuration(8000);
		
		sb.setAction(_dismiss, new View.OnClickListener(){
			@Override
			public void onClick(View v){
				
				//paste the code that you want to perform
				
			}
		});
		
		sb.show();
	}
	
	
	public void _blurTextView(final TextView _textview, final boolean _active) {
		//Code by X-Droid - This block is created by InfLps
		
		if (_active) {
				if (Build.VERSION.SDK_INT >= 11) {
						     _textview.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
				}
				float radius = _textview.getTextSize() / 3;
				BlurMaskFilter filter = new BlurMaskFilter(radius, BlurMaskFilter.Blur.NORMAL);
				_textview.getPaint().setMaskFilter(filter);
		}
		else {
				if (Build.VERSION.SDK_INT >= 11) {
						     _textview.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
				}
				float radius = _textview.getTextSize() / 1000;
				BlurMaskFilter filter = new BlurMaskFilter(radius, BlurMaskFilter.Blur.NORMAL);
				_textview.getPaint().setMaskFilter(filter);
		}
	}
	
	
	public void _Intent_filter(final String _path, final String _mime_type) {
		
		
		AIntentFilter b = new AIntentFilter(HomeActivity.this);
		  
		b.config();
		  
		  
		b.newIntentFilter(Uri.fromFile(new java.io.File(_path)), _mime_type);
		 
		
		
		// Type Examples:
		
		String type1 = "*/*"; // any types 
		String type2 = "image/*"; //
		String type3 = "audio/*"; // 
		String type4 = "txt/*"; // open file as text editor or ..
		String type5 = "archive"; // Archives such as zip / rar / jar etc
		String type6 = "application/vnd.android.package-archive"; //Application
	}
	
	
	public void _CheckIfInstalled(final String _q, final String _message1, final String _errormessage) {
		//Moreblock By Mix Studio Official
		q = _q;
		message1 = _message1;
		errormessage = _errormessage;
		boolean isAppInstalled = appInstalledOrNot(q); // mixstudio
		
		if(isAppInstalled) {
			i3.setClass(getApplicationContext(), InfoActivity.class);
			startActivity(i3);
		} else {
		}
	}
	
	private boolean appInstalledOrNot(String uri) { android.content.pm.PackageManager pm = getPackageManager(); try { pm.getPackageInfo(uri, android.content.pm.PackageManager.GET_ACTIVITIES); return true; } catch (android.content.pm.PackageManager.NameNotFoundException e) { } return false;
	}
	
	
	public void _FabProgress(final boolean _start) {
		
		if (_start) {
			
			this._fab.setImageResource(R.drawable.load);
			
			this.load_fab.setTarget(this._fab);
			
			this.load_fab.setPropertyName("rotation");
			
			this.load_fab.setFloatValues(new float[]{0.0f, 360.0f});
			
			this.load_fab.setDuration(750);
			
			this.load_fab.setRepeatCount(Animation.INFINITE);
			
			this.load_fab.setInterpolator(new LinearInterpolator());
			
			this.load_fab.start();
			
			return;
			
		}
		
		if (this.load_fab.isRunning()) {
			
			this.load_fab.cancel();
			
		}
		
		this._fab.setImageResource(R.drawable.ic_add_white);
		
		this._fab.setRotation(0.0f);
		
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.file_list, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout cust = _view.findViewById(R.id.cust);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview88 = _view.findViewById(R.id.imageview88);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView bilgi = _view.findViewById(R.id.bilgi);
			
			textview1.setText(Uri.parse(liststring.get((int)(_position))).getLastPathSegment());
			linear1.setBackgroundColor(0xFF262626);
			if (FileUtil.isDirectory(liststring.get((int)(_position)))) {
				bilgi.setText("<DIR>");
				if (textview1.getText().toString().equals("Download") || textview1.getText().toString().equals("Downloads")) {
					imageview1.setImageResource(R.drawable.downloads_folder);
					cust.setBackgroundResource(R.drawable.invisible_image);
					cust.setVisibility(View.GONE);
					imageview1.setVisibility(View.VISIBLE);
				}
				else {
					if (textview1.getText().toString().equals("Music") || textview1.getText().toString().equals("Ringtones")) {
						imageview1.setImageResource(R.drawable.music_folder);
						cust.setBackgroundResource(R.drawable.invisible_image);
						cust.setVisibility(View.GONE);
						imageview1.setVisibility(View.VISIBLE);
					}
					else {
						if (textview1.getText().toString().equals("CodeXYZ")) {
							imageview1.setImageResource(R.drawable.program);
							cust.setBackgroundResource(R.drawable.invisible_image);
							cust.setVisibility(View.GONE);
							imageview1.setVisibility(View.VISIBLE);
						}
						else {
							if (textview1.getText().toString().contains("Documents")) {
								cust.setVisibility(View.GONE);
								imageview1.setVisibility(View.VISIBLE);
								imageview1.setImageResource(R.drawable.documents_folder);
								cust.setBackgroundResource(R.drawable.invisible_image);
							}
							else {
								if (textview1.getText().toString().equals("sketchware")) {
									imageview1.setImageResource(R.drawable.extensions_folder);
									cust.setBackgroundResource(R.drawable.invisible_image);
									cust.setVisibility(View.GONE);
									imageview1.setVisibility(View.VISIBLE);
								}
								else {
									if (textview1.getText().toString().equals("Sketchub") || textview1.getText().toString().equals("Sketchub Projects")) {
										imageview1.setImageResource(R.drawable.sketchub_icon);
										cust.setBackgroundResource(R.drawable.invisible_image);
										cust.setVisibility(View.GONE);
										imageview88.setVisibility(View.GONE);
										imageview1.setVisibility(View.VISIBLE);
									}
									else {
										if (textview1.getText().toString().equals("Pictures")) {
											imageview1.setImageResource(R.drawable.pictures_folder);
											cust.setBackgroundResource(R.drawable.invisible_image);
											cust.setVisibility(View.GONE);
											imageview1.setVisibility(View.VISIBLE);
										}
										else {
											if (textview1.getText().toString().equals("Android")) {
												cust.setBackgroundResource(R.drawable.invisible_image);
												imageview1.setImageResource(R.drawable.android_folder);
												cust.setVisibility(View.GONE);
												imageview1.setVisibility(View.VISIBLE);
											}
											else {
												if (textview1.getText().toString().equals("DCIM")) {
													imageview1.setImageResource(R.drawable.dcim_folder);
													cust.setVisibility(View.GONE);
													imageview1.setVisibility(View.VISIBLE);
												}
												else {
													if (textview1.getText().toString().equals("Movies")) {
														imageview1.setImageResource(R.drawable.movies_folder);
														cust.setBackgroundResource(R.drawable.invisible_image);
														cust.setVisibility(View.GONE);
														imageview1.setVisibility(View.VISIBLE);
													}
													else {
														if (textview1.getText().toString().equals("games") || textview1.getText().toString().equals("Games")) {
															imageview1.setImageResource(R.drawable.games_folder);
															cust.setBackgroundResource(R.drawable.invisible_image);
															cust.setVisibility(View.GONE);
															imageview1.setVisibility(View.VISIBLE);
														}
														else {
															if (textview1.getText().toString().equals(".sketchware")) {
																imageview1.setImageResource(R.drawable.hiden_sketchware_folder);
																cust.setBackgroundResource(R.drawable.invisible_image);
																cust.setVisibility(View.GONE);
																imageview1.setVisibility(View.VISIBLE);
															}
															else {
																if (textview1.getText().toString().startsWith(".")) {
																	imageview1.setImageResource(R.drawable.hiden_folder);
																	cust.setBackgroundResource(R.drawable.invisible_image);
																	cust.setVisibility(View.GONE);
																	imageview1.setVisibility(View.VISIBLE);
																}
																else {
																	if (textview1.getText().toString().equals(".android")) {
																		imageview1.setImageResource(R.drawable.hiden_android_folder);
																		cust.setBackgroundResource(R.drawable.invisible_image);
																		cust.setVisibility(View.GONE);
																		imageview1.setVisibility(View.VISIBLE);
																	}
																	else {
																		cust.setBackgroundResource(R.drawable.invisible_image);
																		imageview1.setImageResource(R.drawable.folder);
																		cust.setVisibility(View.GONE);
																		imageview1.setVisibility(View.VISIBLE);
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			else {
				if (liststring.get((int)(_position)).endsWith(".zip") || (liststring.get((int)(_position)).endsWith(".7z") || liststring.get((int)(_position)).endsWith(".rar"))) {
					imageview1.setImageResource(R.drawable.archive_file);
					cust.setBackgroundResource(R.drawable.invisible_image);
					cust.setVisibility(View.GONE);
					imageview1.setVisibility(View.VISIBLE);
					info = liststring.get((int)(_position));
					final java.io.File file1 = new java.io.File(info);
					try{
						long length = file1.length();
						length = length/1024;
						bilgi.setText("File size : " + length +" KB");
					}catch(Exception e){
						showMessage("File not found : " + e.getMessage() + e);
					}
				}
				else {
					if (liststring.get((int)(_position)).endsWith(".swb")) {
						imageview1.setImageResource(R.drawable.sh_file);
						cust.setBackgroundResource(R.drawable.invisible_image);
						cust.setVisibility(View.GONE);
						imageview1.setVisibility(View.VISIBLE);
						info = liststring.get((int)(_position));
						final java.io.File file1 = new java.io.File(info);
						try{
							long length = file1.length();
							length = length/1024;
							bilgi.setText("File size : " + length +" KB");
						}catch(Exception e){
							showMessage("File not found : " + e.getMessage() + e);
						}
					}
					else {
						if (liststring.get((int)(_position)).endsWith(".ttf") || (liststring.get((int)(_position)).endsWith(".otf") || liststring.get((int)(_position)).endsWith(".woff"))) {
							imageview1.setImageResource(R.drawable.font_file);
							cust.setBackgroundResource(R.drawable.invisible_image);
							cust.setVisibility(View.GONE);
							imageview1.setVisibility(View.VISIBLE);
							info = liststring.get((int)(_position));
							final java.io.File file1 = new java.io.File(info);
							try{
								long length = file1.length();
								length = length/1024;
								bilgi.setText("File size : " + length +" KB");
							}catch(Exception e){
								showMessage("File not found : " + e.getMessage() + e);
							}
						}
						else {
							if (liststring.get((int)(_position)).endsWith(".pdf")) {
								imageview1.setImageResource(R.drawable.pdf);
								cust.setBackgroundResource(R.drawable.invisible_image);
								cust.setVisibility(View.GONE);
								imageview1.setVisibility(View.VISIBLE);
								info = liststring.get((int)(_position));
								final java.io.File file1 = new java.io.File(info);
								try{
									long length = file1.length();
									length = length/1024;
									bilgi.setText("File size : " + length +" KB");
								}catch(Exception e){
									showMessage("File not found : " + e.getMessage() + e);
								}
							}
							else {
								if (liststring.get((int)(_position)).endsWith(".png") || (liststring.get((int)(_position)).endsWith(".jpg") || (liststring.get((int)(_position)).endsWith(".jpeg") || (liststring.get((int)(_position)).endsWith(".svg") || liststring.get((int)(_position)).endsWith(".btmp"))))) {
									cust.setBackgroundResource(R.drawable.image_file);
									imageview1.setImageResource(R.drawable.image_file_ex);
									if (settings.getString("preview", "").equals("t")) {
										_setImageFromFile(imageview88, liststring.get((int)(_position)));
										cust.setVisibility(View.VISIBLE);
										imageview1.setVisibility(View.GONE);
									}
									else {
										cust.setVisibility(View.GONE);
										imageview1.setVisibility(View.VISIBLE);
									}
									info = liststring.get((int)(_position));
									final java.io.File file1 = new java.io.File(info);
									try{
										long length = file1.length();
										length = length/1024;
										bilgi.setText("File size : " + length +" KB");
									}catch(Exception e){
										showMessage("File not found : " + e.getMessage() + e);
									}
								}
								else {
									if (liststring.get((int)(_position)).endsWith(".bin")) {
										cust.setBackgroundResource(R.drawable.invisible_image);
										imageview1.setImageResource(R.drawable.bin_file);
										cust.setVisibility(View.GONE);
										imageview1.setVisibility(View.VISIBLE);
										info = liststring.get((int)(_position));
										final java.io.File file1 = new java.io.File(info);
										try{
											long length = file1.length();
											length = length/1024;
											bilgi.setText("File size : " + length +" KB");
										}catch(Exception e){
											showMessage("File not found : " + e.getMessage() + e);
										}
									}
									else {
										if (liststring.get((int)(_position)).endsWith(".java") || liststring.get((int)(_position)).endsWith(".jar")) {
											imageview1.setImageResource(R.drawable.java_file);
											cust.setBackgroundResource(R.drawable.invisible_image);
											cust.setVisibility(View.GONE);
											imageview1.setVisibility(View.VISIBLE);
											info = liststring.get((int)(_position));
											final java.io.File file1 = new java.io.File(info);
											try{
												long length = file1.length();
												length = length/1024;
												bilgi.setText("File size : " + length +" KB");
											}catch(Exception e){
												showMessage("File not found : " + e.getMessage() + e);
											}
										}
										else {
											if (liststring.get((int)(_position)).endsWith(".gif")) {
												cust.setBackgroundResource(R.drawable.gif_f);
												imageview1.setImageResource(R.drawable.gif_file);
												if (settings.getString("preview", "").equals("t")) {
													_setImageFromFile(imageview88, liststring.get((int)(_position)));
													cust.setVisibility(View.VISIBLE);
													imageview1.setVisibility(View.GONE);
												}
												else {
													cust.setVisibility(View.GONE);
													imageview1.setVisibility(View.VISIBLE);
												}
												info = liststring.get((int)(_position));
												final java.io.File file1 = new java.io.File(info);
												try{
													long length = file1.length();
													length = length/1024;
													bilgi.setText("File size : " + length +" KB");
												}catch(Exception e){
													showMessage("File not found : " + e.getMessage() + e);
												}
											}
											else {
												if (liststring.get((int)(_position)).endsWith(".json")) {
													cust.setBackgroundResource(R.drawable.invisible_image);
													imageview1.setImageResource(R.drawable.json_file);
													cust.setVisibility(View.GONE);
													imageview1.setVisibility(View.VISIBLE);
													info = liststring.get((int)(_position));
													final java.io.File file1 = new java.io.File(info);
													try{
														long length = file1.length();
														length = length/1024;
														bilgi.setText("File size : " + length +" KB");
													}catch(Exception e){
														showMessage("File not found : " + e.getMessage() + e);
													}
												}
												else {
													if (liststring.get((int)(_position)).endsWith(".xml")) {
														cust.setBackgroundResource(R.drawable.invisible_image);
														imageview1.setImageResource(R.drawable.code_file);
														cust.setVisibility(View.GONE);
														imageview1.setVisibility(View.VISIBLE);
														info = liststring.get((int)(_position));
														final java.io.File file1 = new java.io.File(info);
														try{
															long length = file1.length();
															length = length/1024;
															bilgi.setText("File size : " + length +" KB");
														}catch(Exception e){
															showMessage("File not found : " + e.getMessage() + e);
														}
													}
													else {
														if (liststring.get((int)(_position)).endsWith(".mp4") || (liststring.get((int)(_position)).endsWith(".avc") || liststring.get((int)(_position)).endsWith(".mp2"))) {
															cust.setBackgroundResource(R.drawable.video_file);
															imageview1.setImageResource(R.drawable.movie_file);
															if (settings.getString("preview", "").equals("t")) {
																_getMP4Thumbnail(liststring.get((int)(_position)), imageview88);
																cust.setVisibility(View.VISIBLE);
																imageview1.setVisibility(View.GONE);
															}
															else {
																cust.setVisibility(View.GONE);
																imageview1.setVisibility(View.VISIBLE);
															}
															info = liststring.get((int)(_position));
															final java.io.File file1 = new java.io.File(info);
															try{
																long length = file1.length();
																length = length/1024;
																bilgi.setText("File size : " + length +" KB");
															}catch(Exception e){
																showMessage("File not found : " + e.getMessage() + e);
															}
														}
														else {
															if (liststring.get((int)(_position)).endsWith(".mp3") || (liststring.get((int)(_position)).endsWith(".wav") || (liststring.get((int)(_position)).endsWith(".ogg") || (liststring.get((int)(_position)).endsWith(".org") || (liststring.get((int)(_position)).endsWith(".m4a") || liststring.get((int)(_position)).endsWith(".WAV")))))) {
																cust.setBackgroundResource(R.drawable.invisible_image);
																imageview1.setImageResource(R.drawable.music_file);
																info = liststring.get((int)(_position));
																cust.setVisibility(View.GONE);
																imageview1.setVisibility(View.VISIBLE);
																final java.io.File file1 = new java.io.File(info);
																try{
																	long length = file1.length();
																	length = length/1024;
																	bilgi.setText("File size : " + length +" KB");
																}catch(Exception e){
																	showMessage("File not found : " + e.getMessage() + e);
																}
															}
															else {
																if (liststring.get((int)(_position)).endsWith(".txt") || (liststring.get((int)(_position)).endsWith(".note") || (liststring.get((int)(_position)).endsWith(".stxt") || liststring.get((int)(_position)).endsWith(".sdoc")))) {
																	cust.setBackgroundResource(R.drawable.invisible_image);
																	imageview1.setImageResource(R.drawable.document);
																	cust.setVisibility(View.GONE);
																	imageview1.setVisibility(View.VISIBLE);
																	info = liststring.get((int)(_position));
																	final java.io.File file1 = new java.io.File(info);
																	try{
																		long length = file1.length();
																		length = length/1024;
																		bilgi.setText("File size : " + length +" KB");
																	}catch(Exception e){
																		showMessage("File not found : " + e.getMessage() + e);
																	}
																}
																else {
																	if (liststring.get((int)(_position)).endsWith(".doc") || liststring.get((int)(_position)).endsWith(".docx")) {
																		cust.setBackgroundResource(R.drawable.invisible_image);
																		imageview1.setImageResource(R.drawable.word);
																		info = liststring.get((int)(_position));
																		final java.io.File file1 = new java.io.File(info);
																		try{
																			long length = file1.length();
																			length = length/1024;
																			bilgi.setText("File size : " + length +" KB");
																		}catch(Exception e){
																			showMessage("File not found : " + e.getMessage() + e);
																		}
																	}
																	else {
																		if (liststring.get((int)(_position)).endsWith(".cog") || liststring.get((int)(_position)).endsWith(".properties")) {
																			cust.setBackgroundResource(R.drawable.invisible_image);
																			imageview1.setImageResource(R.drawable.project_setup);
																			cust.setVisibility(View.GONE);
																			imageview1.setVisibility(View.VISIBLE);
																			info = liststring.get((int)(_position));
																			final java.io.File file1 = new java.io.File(info);
																			try{
																				long length = file1.length();
																				length = length/1024;
																				bilgi.setText("File size : " + length +" KB");
																			}catch(Exception e){
																				showMessage("File not found : " + e.getMessage() + e);
																			}
																		}
																		else {
																			if (liststring.get((int)(_position)).endsWith(".") || liststring.get((int)(_position)).endsWith(".sfk")) {
																				cust.setBackgroundResource(R.drawable.invisible_image);
																				imageview1.setImageResource(R.drawable.hot_article);
																				cust.setVisibility(View.GONE);
																				imageview1.setVisibility(View.VISIBLE);
																				info = liststring.get((int)(_position));
																				final java.io.File file1 = new java.io.File(info);
																				try{
																					long length = file1.length();
																					length = length/1024;
																					bilgi.setText("File size : " + length +" KB");
																				}catch(Exception e){
																					showMessage("File not found : " + e.getMessage() + e);
																				}
																			}
																			else {
																				if (liststring.get((int)(_position)).endsWith(".py")) {
																					cust.setBackgroundResource(R.drawable.invisible_image);
																					imageview1.setImageResource(R.drawable.phyton_file);
																					cust.setVisibility(View.GONE);
																					imageview1.setVisibility(View.VISIBLE);
																					info = liststring.get((int)(_position));
																					final java.io.File file1 = new java.io.File(info);
																					try{
																						long length = file1.length();
																						length = length/1024;
																						bilgi.setText("File size : " + length +" KB");
																					}catch(Exception e){
																						showMessage("File not found : " + e.getMessage() + e);
																					}
																				}
																				else {
																					if (liststring.get((int)(_position)).endsWith(".xls") || liststring.get((int)(_position)).endsWith(".xlsm")) {
																						cust.setBackgroundResource(R.drawable.invisible_image);
																						imageview1.setImageResource(R.drawable.excel);
																						cust.setVisibility(View.GONE);
																						imageview1.setVisibility(View.VISIBLE);
																						info = liststring.get((int)(_position));
																						final java.io.File file1 = new java.io.File(info);
																						try{
																							long length = file1.length();
																							length = length/1024;
																							bilgi.setText("File size : " + length +" KB");
																						}catch(Exception e){
																							showMessage("File not found : " + e.getMessage() + e);
																						}
																					}
																					else {
																						if (liststring.get((int)(_position)).endsWith(".ppt") || liststring.get((int)(_position)).endsWith(".pptx")) {
																							cust.setBackgroundResource(R.drawable.invisible_image);
																							imageview1.setImageResource(R.drawable.powerpoint);
																							cust.setVisibility(View.GONE);
																							imageview1.setVisibility(View.VISIBLE);
																							info = liststring.get((int)(_position));
																							final java.io.File file1 = new java.io.File(info);
																							try{
																								long length = file1.length();
																								length = length/1024;
																								bilgi.setText("File size : " + length +" KB");
																							}catch(Exception e){
																								showMessage("File not found : " + e.getMessage() + e);
																							}
																						}
																						else {
																							if (liststring.get((int)(_position)).endsWith(".kt") || liststring.get((int)(_position)).endsWith(".ktx")) {
																								cust.setBackgroundResource(R.drawable.invisible_image);
																								imageview1.setImageResource(R.drawable.kotlin_file);
																								cust.setVisibility(View.GONE);
																								imageview1.setVisibility(View.VISIBLE);
																								info = liststring.get((int)(_position));
																								final java.io.File file1 = new java.io.File(info);
																								try{
																									long length = file1.length();
																									length = length/1024;
																									bilgi.setText("File size : " + length +" KB");
																								}catch(Exception e){
																									showMessage("File not found : " + e.getMessage() + e);
																								}
																							}
																							else {
																								if (liststring.get((int)(_position)).endsWith(".c")) {
																									cust.setBackgroundResource(R.drawable.invisible_image);
																									imageview1.setImageResource(R.drawable.c_file);
																									cust.setVisibility(View.GONE);
																									imageview1.setVisibility(View.VISIBLE);
																									info = liststring.get((int)(_position));
																									final java.io.File file1 = new java.io.File(info);
																									try{
																										long length = file1.length();
																										length = length/1024;
																										bilgi.setText("File size : " + length +" KB");
																									}catch(Exception e){
																										showMessage("File not found : " + e.getMessage() + e);
																									}
																								}
																								else {
																									if (liststring.get((int)(_position)).endsWith(".o")) {
																										cust.setBackgroundResource(R.drawable.invisible_image);
																										imageview1.setImageResource(R.drawable.c_cpp_object_file);
																										cust.setVisibility(View.GONE);
																										imageview1.setVisibility(View.VISIBLE);
																										info = liststring.get((int)(_position));
																										final java.io.File file1 = new java.io.File(info);
																										try{
																											long length = file1.length();
																											length = length/1024;
																											bilgi.setText("File size : " + length +" KB");
																										}catch(Exception e){
																											showMessage("File not found : " + e.getMessage() + e);
																										}
																									}
																									else {
																										if (liststring.get((int)(_position)).endsWith(".html") || liststring.get((int)(_position)).endsWith(".HTML")) {
																											cust.setBackgroundResource(R.drawable.invisible_image);
																											imageview1.setImageResource(R.drawable.html5_file);
																											cust.setVisibility(View.GONE);
																											imageview1.setVisibility(View.VISIBLE);
																											info = liststring.get((int)(_position));
																										}
																										else {
																											if (liststring.get((int)(_position)).endsWith(".cpp") || liststring.get((int)(_position)).endsWith(".cc")) {
																												cust.setBackgroundResource(R.drawable.invisible_image);
																												imageview1.setImageResource(R.drawable.c_plus_plus_file);
																												cust.setVisibility(View.GONE);
																												imageview1.setVisibility(View.VISIBLE);
																												info = liststring.get((int)(_position));
																												final java.io.File file1 = new java.io.File(info);
																												try{
																													long length = file1.length();
																													length = length/1024;
																													bilgi.setText("File size : " + length +" KB");
																												}catch(Exception e){
																													showMessage("File not found : " + e.getMessage() + e);
																												}
																											}
																											else {
																												if (liststring.get((int)(_position)).endsWith(".cs")) {
																													cust.setBackgroundResource(R.drawable.invisible_image);
																													imageview1.setImageResource(R.drawable.c_sharp_file);
																													cust.setVisibility(View.GONE);
																													imageview1.setVisibility(View.VISIBLE);
																													info = liststring.get((int)(_position));
																													final java.io.File file1 = new java.io.File(info);
																													try{
																														long length = file1.length();
																														length = length/1024;
																														bilgi.setText("File size : " + length +" KB");
																													}catch(Exception e){
																														showMessage("File not found : " + e.getMessage() + e);
																													}
																												}
																												else {
																													if (liststring.get((int)(_position)).endsWith(".css")) {
																														cust.setBackgroundResource(R.drawable.invisible_image);
																														imageview1.setImageResource(R.drawable.css_file);
																														cust.setVisibility(View.GONE);
																														imageview1.setVisibility(View.VISIBLE);
																														info = liststring.get((int)(_position));
																														final java.io.File file1 = new java.io.File(info);
																														try{
																															long length = file1.length();
																															length = length/1024;
																															bilgi.setText("File size : " + length +" KB");
																														}catch(Exception e){
																															showMessage("File not found : " + e.getMessage() + e);
																														}
																													}
																													else {
																														if (liststring.get((int)(_position)).endsWith(".tpz") || (liststring.get((int)(_position)).endsWith(".mart") || (liststring.get((int)(_position)).endsWith(".apnx") || (liststring.get((int)(_position)).endsWith(".ea") || (liststring.get((int)(_position)).endsWith(".mobi") || liststring.get((int)(_position)).endsWith(".epub")))))) {
																															cust.setBackgroundResource(R.drawable.invisible_image);
																															imageview1.setImageResource(R.drawable.ebook);
																															cust.setVisibility(View.GONE);
																															imageview1.setVisibility(View.VISIBLE);
																															info = liststring.get((int)(_position));
																															final java.io.File file1 = new java.io.File(info);
																															try{
																																long length = file1.length();
																																length = length/1024;
																																bilgi.setText("File size : " + length +" KB");
																															}catch(Exception e){
																																showMessage("File not found : " + e.getMessage() + e);
																															}
																														}
																														else {
																															if (liststring.get((int)(_position)).endsWith(".invisible")) {
																																cust.setVisibility(View.GONE);
																																imageview1.setVisibility(View.VISIBLE);
																																cust.setBackgroundResource(R.drawable.invisible_image);
																																imageview1.setImageResource(R.drawable.line);
																																textview1.setText("");
																																bilgi.setText("");
																															}
																															else {
																																if (liststring.get((int)(_position)).endsWith(".db") || (liststring.get((int)(_position)).endsWith(".sqlitedb") || (liststring.get((int)(_position)).endsWith(".teacher") || (liststring.get((int)(_position)).endsWith(".ibd") || (liststring.get((int)(_position)).endsWith(".ddl") || liststring.get((int)(_position)).endsWith(".pdb")))))) {
																																	cust.setBackgroundResource(R.drawable.invisible_image);
																																	imageview1.setImageResource(R.drawable.database);
																																	cust.setVisibility(View.GONE);
																																	imageview1.setVisibility(View.VISIBLE);
																																	info = liststring.get((int)(_position));
																																	final java.io.File file1 = new java.io.File(info);
																																	try{
																																		long length = file1.length();
																																		length = length/1024;
																																		bilgi.setText("File size : " + length +" KB");
																																	}catch(Exception e){
																																		showMessage("File not found : " + e.getMessage() + e);
																																	}
																																}
																																else {
																																	if (liststring.get((int)(_position)).endsWith(".inf4u")) {
																																		cust.setBackgroundResource(R.drawable.invisible_image);
																																		imageview1.setImageResource(R.drawable.ic_close_white);
																																		cust.setVisibility(View.GONE);
																																		imageview1.setVisibility(View.VISIBLE);
																																		textview1.setText("ERR");
																																		bilgi.setText("");
																																	}
																																	else {
																																		if (liststring.get((int)(_position)).endsWith(".apk")) {
																																			cust.setBackgroundResource(R.drawable.executable_file_available);
																																			imageview1.setImageResource(R.drawable.executable_file);
																																			if (settings.getString("preview", "").equals("t")) {
																																				_getApkIcon(liststring.get((int)(_position)), imageview88);
																																				cust.setVisibility(View.VISIBLE);
																																				imageview1.setVisibility(View.GONE);
																																			}
																																			else {
																																				cust.setVisibility(View.GONE);
																																				imageview1.setVisibility(View.VISIBLE);
																																			}
																																			info = liststring.get((int)(_position));
																																			final java.io.File file1 = new java.io.File(info);
																																			try{
																																				long length = file1.length();
																																				length = length/1024;
																																				bilgi.setText("File size : " + length +" KB");
																																			}catch(Exception e){
																																				showMessage("File not found : " + e.getMessage() + e);
																																			}
																																		}
																																		else {
																																			if (liststring.get((int)(_position)).endsWith(".sh")) {
																																				cust.setBackgroundResource(R.drawable.invisible_image);
																																				imageview1.setImageResource(R.drawable.sh_file_);
																																				cust.setVisibility(View.GONE);
																																				imageview1.setVisibility(View.VISIBLE);
																																				info = liststring.get((int)(_position));
																																				final java.io.File file1 = new java.io.File(info);
																																				try{
																																					long length = file1.length();
																																					length = length/1024;
																																					bilgi.setText("File size : " + length +" KB");
																																				}catch(Exception e){
																																					showMessage("File not found : " + e.getMessage() + e);
																																				}
																																			}
																																			else {
																																				if (liststring.get((int)(_position)).endsWith(".exe") || (liststring.get((int)(_position)).endsWith(".dmg") || (liststring.get((int)(_position)).endsWith("ipa") || (liststring.get((int)(_position)).endsWith(".iso") || liststring.get((int)(_position)).endsWith(".xapk"))))) {
																																					cust.setBackgroundResource(R.drawable.invisible_image);
																																					imageview1.setImageResource(R.drawable.executable_file);
																																					cust.setVisibility(View.GONE);
																																					imageview1.setVisibility(View.VISIBLE);
																																					info = liststring.get((int)(_position));
																																					final java.io.File file1 = new java.io.File(info);
																																					try{
																																						long length = file1.length();
																																						length = length/1024;
																																						bilgi.setText("File size : " + length +" KB");
																																					}catch(Exception e){
																																						showMessage("File not found : " + e.getMessage() + e);
																																					}
																																				}
																																				else {
																																					cust.setBackgroundResource(R.drawable.invisible_image);
																																					imageview1.setImageResource(R.drawable.file);
																																					cust.setVisibility(View.GONE);
																																					imageview1.setVisibility(View.VISIBLE);
																																					info = liststring.get((int)(_position));
																																					final java.io.File file1 = new java.io.File(info);
																																					try{
																																						long length = file1.length();
																																						length = length/1024;
																																						bilgi.setText("File size : " + length +" KB");
																																					}catch(Exception e){
																																						showMessage("File not found : " + e.getMessage() + e);
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																											cust.setBackgroundResource(R.drawable.invisible_image);
																											imageview1.setImageResource(R.drawable.file);
																											info = liststring.get((int)(_position));
																											final java.io.File file1 = new java.io.File(info);
																											try{
																												long length = file1.length();
																												length = length/1024;
																												bilgi.setText("File size : " + length +" KB");
																											}catch(Exception e){
																												showMessage("File not found : " + e.getMessage() + e);
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}