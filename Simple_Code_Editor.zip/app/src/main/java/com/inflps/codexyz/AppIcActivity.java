package com.inflps.codexyz;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import com.google.android.material.appbar.AppBarLayout;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class AppIcActivity extends AppCompatActivity {
	
	public final int REQ_CD_PIC = 101;
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private String path = "";
	private double number = 0;
	private double n = 0;
	
	private ArrayList<String> copy_list = new ArrayList<>();
	private ArrayList<String> list_icon = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ListView listview1;
	private Button button1;
	
	private Intent pic = new Intent(Intent.ACTION_GET_CONTENT);
	private AlertDialog.Builder alert;
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.app_ic);
		initialize(_savedInstanceState);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		listview1 = findViewById(R.id.listview1);
		button1 = findViewById(R.id.button1);
		pic.setType("*/*");
		pic.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		alert = new AlertDialog.Builder(this);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				i.putExtra("icon", listmap.get((int)_position).get("icon").toString());
				i.setClass(getApplicationContext(), ImagePreviewActivity.class);
				startActivity(i);
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				alert.setTitle("Hold on!");
				alert.setIcon(R.drawable.error_file);
				alert.setMessage("The app may crash, depends on how many icons are on that extracted app!\n\nWe only extract to the xhdpi-v4 directory!\n\nIf you continue this and then chose file with .apk extension, you have to wait some time. I repeat, only files with the .apk extension!\n\nUnfortunately we can't show app processes while extracting icons, it just freezes for a while.\n\nIf the icon extraction does not work, do not hesitate to contact us!");
				alert.setPositiveButton("Continue ", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/extract_icons"));
						startActivityForResult(pic, REQ_CD_PIC);
					}
				});
				alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				_CustomDialogMaterial(alert, true);
			}
		});
	}
	
	private void initializeLogic() {
		setTitle("Icon Extractor ");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_PIC:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				path = _filePath.get((int)(0));
				if (path.endsWith(".apk")) {
					FileUtil.copyFile(path, FileUtil.getExternalStorageDir().concat("/extractor/file.zip"));
					if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/extractor/file.zip"))) {
						_UnZip(FileUtil.getExternalStorageDir().concat("/extractor/file.zip"), FileUtil.getExternalStorageDir().concat("/extractor/"));
						_Copy(FileUtil.getExternalStorageDir().concat("/extractor/res/drawable-xhdpi-v4"), FileUtil.getExternalStorageDir().concat("/extract_icons"));
						FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/extractor"));
						FileUtil.listDir(FileUtil.getExternalStorageDir().concat("/extract_icons"), list_icon);
						n = 0;
						for(int _repeat184 = 0; _repeat184 < (int)(list_icon.size()); _repeat184++) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("icon", list_icon.get((int)(n)));
								listmap.add(_item);
							}
							
							n++;
							listview1.setAdapter(new Listview1Adapter(listmap));
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
							_GridView(listmap);
						}
						SketchwareUtil.showMessage(getApplicationContext(), "Icon extraction was successful ");
					}
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "This is not an apk file");
				}
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (listmap.size() == 0) {
			finish();
		}
		else {
			alert.setTitle("Alert ");
			alert.setIcon(R.drawable.error_file);
			alert.setMessage("To understand, if you close this activity, the whole process is deleted and cannot be recovered! It also deletes used caches (extracted icons).");
			alert.setPositiveButton("Continue ", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/extract_icons"));
					finish();
				}
			});
			alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					
				}
			});
			_CustomDialogMaterial(alert, true);
		}
	}
	public void _UnZip(final String _fileZip, final String _destDir) {
		try
		{
			java.io.File outdir = new java.io.File(_destDir);
			java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(_fileZip));
			java.util.zip.ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null)
			{
				name = entry.getName();
				if(entry.isDirectory())
				{
					mkdirs(outdir, name);
					continue;
				}
				
				/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
				
				dir = dirpart(name);
				if(dir != null)
				mkdirs(outdir, dir);
				
				extractFile(zin, outdir, name);
			}
			zin.close();
		}
		catch (java.io.IOException e)
		{
			e.printStackTrace();
		}
	}
	private static void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
	{
		byte[] buffer = new byte[4096];
		java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
		out.write(buffer, 0, count);
		out.close();
	}
	
	private static void mkdirs(java.io.File outdir, String path)
	{
		java.io.File d = new java.io.File(outdir, path);
		if(!d.exists())
		d.mkdirs();
	}
	
	private static String dirpart(String name)
	{
		int s = name.lastIndexOf(java.io.File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}
	
	
	public void _GridView(final ArrayList<HashMap<String, Object>> _ListMap) {
		GridView gridView = new GridView(this);
		gridView.setLayoutParams(new GridView.LayoutParams(GridLayout.LayoutParams.MATCH_PARENT, GridLayout.LayoutParams.WRAP_CONTENT));
		
		///gridView.setBackgroundColor(Color.WHITE);
		
		gridView.setNumColumns(4);
		gridView.setColumnWidth(GridView.AUTO_FIT);
		
		gridView.setVerticalSpacing(22);
		
		gridView.setHorizontalSpacing(22);
		gridView.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
		
		gridView.setAdapter(new Listview1Adapter(_ListMap));
		
		((BaseAdapter)gridView.getAdapter()).notifyDataSetChanged();
		linear1.removeAllViews();
		linear1.addView(gridView);
		
		
		gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
						  @Override
						  public void onItemClick(AdapterView parent, View view, int pos, long id) {
								
				int position= pos;
				
				
				
			}});
	}
	
	
	public void _Copy(final String _F, final String _T) {
		copy_list.clear();
		FileUtil.listDir(_F.concat("/"), copy_list);
		number = 0;
		for(int _repeat11 = 0; _repeat11 < (int)(copy_list.size()); _repeat11++) {
			if (FileUtil.isFile(copy_list.get((int)(number)))) {
				FileUtil.copyFile(copy_list.get((int)(number)), _T.concat("/".concat(Uri.parse(copy_list.get((int)(number))).getLastPathSegment())));
			}
			number++;
		}
	}
	
	
	public void _CustomDialogMaterial(final AlertDialog.Builder _dial, final boolean _booleann) {
		
		setTheme(android.R.style.Theme_Material);
		_dial.setCancelable(_booleann);
		AlertDialog alert = _dial.show();
		alert.getWindow().getDecorView().setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, Color.parseColor("#252525")));
			alert.getWindow().getDecorView().setPadding(8,8,8,8);
		alert.show();
		
		alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#ff0000"));
			alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#ff0000"));
			alert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.parseColor("#ff0000"));
		alert.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
		alert.getWindow().getDecorView().setTranslationY(-20);
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.cus, null);
			}
			
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			imageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(_data.get((int)_position).get("icon").toString(), 1024, 1024));
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.putExtra("icon", listmap.get((int)_position).get("icon").toString());
					i.setClass(getApplicationContext(), ImagePreviewActivity.class);
					startActivity(i);
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}