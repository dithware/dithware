package com.inflps.codexyz;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.arsenax.intentFilter.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ImageView imageview1;
	private LinearLayout linear3;
	private TextView textview1;
	
	private Intent i = new Intent();
	private TimerTask t;
	private Intent intent = new Intent();
	private SharedPreferences ws;
	private TimerTask ac;
	private SharedPreferences sp;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		imageview1 = findViewById(R.id.imageview1);
		linear3 = findViewById(R.id.linear3);
		textview1 = findViewById(R.id.textview1);
		ws = getSharedPreferences("ws", Activity.MODE_PRIVATE);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
	}
	
	private void initializeLogic() {
		// For permission for storage 
		FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("Android/data/user/0/com.inflps.codexyz"));
		if (sp.getString("sp", "").equals("")) {
			textview1.setVisibility(View.VISIBLE);
			t = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							i.setClass(getApplicationContext(), WelcomeActivity.class);
							startActivity(i);
							overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
						}
					});
				}
			};
			_timer.schedule(t, (int)(1500));
		}
		else {
			if (sp.getString("sp", "").equals("t")) {
				textview1.setVisibility(View.GONE);
				_DynamicShortcuts();
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								i.setClass(getApplicationContext(), HomeActivity.class);
								startActivity(i);
								overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
								finish();
							}
						});
					}
				};
				_timer.schedule(t, (int)(750));
			}
		}
	}
	
	public void _DynamicShortcuts() {
		android.content.pm.ShortcutManager shortcutManager = null;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
			shortcutManager = getSystemService(android.content.pm.ShortcutManager.class);
		}
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			if (shortcutManager != null) {
				android.content.pm.ShortcutInfo shortcut_1 = new android.content.pm.ShortcutInfo.Builder(MainActivity.this, "new")
									.setShortLabel("Create a file")
									.setLongLabel("Create a file")
									.setRank(0)
									.setIntent(new android.content.Intent(android.content.Intent.ACTION_VIEW, null, MainActivity.this, CreateDialogActivity.class))
									.setIcon(android.graphics.drawable.Icon.createWithResource(MainActivity.this, R.drawable.add_file))
									.build();
				android.content.pm.ShortcutInfo shortcut_2 = new android.content.pm.ShortcutInfo.Builder(MainActivity.this, "Tools")
									.setShortLabel("More tools")
									.setLongLabel("More tools")
									.setRank(1)
									.setIntent(new android.content.Intent(android.content.Intent.ACTION_VIEW, null, MainActivity.this, MoreToolsActivity.class))
									.setIcon(android.graphics.drawable.Icon.createWithResource(MainActivity.this, R.drawable.more_tools))
									.build();
				android.content.pm.ShortcutInfo shortcut_3 = new android.content.pm.ShortcutInfo.Builder(MainActivity.this, "About")
									.setShortLabel("About app")
									.setLongLabel("About app")
									.setRank(2)
									.setIntent(new android.content.Intent(android.content.Intent.ACTION_VIEW, null, MainActivity.this, AboutActivity.class))
									.setIcon(android.graphics.drawable.Icon.createWithResource(MainActivity.this, R.drawable.about_app))
									.build();
				shortcutManager.setDynamicShortcuts(java.util.Arrays.asList(shortcut_1, shortcut_2, shortcut_3));
			}
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "Dynamic shortcuts aren't supported on this device!");
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}